@echo off
setlocal
cd /d "%~dp0"
title Slotly
echo.
echo  === Slotly: starting ===
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed. Install the LTS version from https://nodejs.org and run this again.
  pause & exit /b 1
)
docker info >nul 2>nul
if errorlevel 1 (
  echo  Docker is not running. Open Docker Desktop, wait until it says "Engine running", then run this again.
  pause & exit /b 1
)

echo  [1/4] Preparing settings...
node scripts\init-env.mjs
if errorlevel 1 ( echo  Could not create the .env file. & pause & exit /b 1 )

echo  [2/4] Starting the database...
docker compose up -d --wait db
if errorlevel 1 ( echo  The database did not start. Is Docker Desktop fully started? & pause & exit /b 1 )

echo  [3/4] Installing (the first time takes a few minutes)...
if not exist node_modules (
  call npm install
  if errorlevel 1 ( echo  npm install failed. Check your internet and run this again. & pause & exit /b 1 )
)
call npx prisma db push --skip-generate
if errorlevel 1 ( echo  Could not create the database tables. & pause & exit /b 1 )

echo  [4/4] Starting Slotly. Your browser will open in a few seconds.
echo        Keep this window open. Close it to stop Slotly.
start "" cmd /c "timeout /t 8 >nul & start http://localhost:3000"
call npm run dev
pause
