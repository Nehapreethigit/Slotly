# Put Slotly on the Google Play Store

Slotly is an installable web app (PWA). Google Play accepts a PWA wrapped as an Android app
(a "Trusted Web Activity"). It is the same website shown full screen with its own icon and no
browser bar, so every time you update the website, the app updates too.

## Before you start (all required)
1. Slotly is **deployed on Vercel** with a working HTTPS address (see README).
2. `NEXT_PUBLIC_CONTACT_EMAIL` is set, and `/privacy` and `/terms` open on your live site.
3. A **Google Play developer account**: https://play.google.com/console/signup
   - One-time fee of 25 US dollars, plus identity verification (can take a few days).
   - Personal accounts created recently must usually run a **closed test with about 12 testers for
     14 days** before they may publish publicly. Check the current rule in Play Console, as Google changes it.

## Step 1: Check the installable app
Open your live site in Chrome on an Android phone, log in, and look for the **Install Slotly** card
on the dashboard. Install it. If it installs and opens full screen, the Play Store version will work.

## Step 2: Build the Android file (no coding)
1. Go to **https://www.pwabuilder.com**, paste your live address, click **Start**.
2. When the report finishes, click **Package for stores**, then **Android**.
3. Choose **Google Play**. Fill in:
   - Package ID: something unique like `com.yourname.slotly` (cannot be changed later, write it down)
   - App name: `Slotly`
   - Version: `1` and version code `1`
   - Signing key: choose **New** (PWABuilder generates one)
4. Click **Download**. You get a zip with an `.aab` file (this is what Play wants), your **signing key**
   and a `signing-key-info.txt`. **Keep the key and its password safe forever**. Back it up somewhere other than this computer.

## Step 3: Create the app in Play Console
1. Play Console > **Create app**. Name `Slotly`, language English, type **App**, **Free**.
2. **Store listing** (use the pictures in the `store-assets` folder of this project):
   - App icon: `app-icon-512.png`
   - Feature graphic: `feature-graphic-1024x500.png`
   - Phone screenshots: the three `phone-screenshot-*.png` files
   - Short description (80 characters): `Booking links that check your real calendar.`
   - Full description: copy the paragraph from the top of README.md
3. **Privacy policy**: paste `https://YOUR-SITE/privacy`.
4. Fill in **App content**: content rating questionnaire (answer honestly, there is no violence or similar),
   target audience (18 and over is simplest), **Data safety** (you collect name, email and booking details
   so the app works; data is encrypted in transit), ads (none).

## Step 4: Upload and test
1. **Testing > Closed testing > Create track** (or Internal testing first), then **Create release**.
2. Upload the `.aab`. Keep **Play App Signing** on.
3. Add testers (email addresses) and roll the release out.

## Step 5: Remove the address bar (important)
Play re-signs your app with its own key, and the website must trust that key.
1. Play Console > **Setup > App signing** and copy the **SHA-256 certificate fingerprint** of the
   *App signing key*. Also copy the one for the *Upload key*.
2. In Vercel > Settings > Environment Variables add:
   - `ANDROID_PACKAGE_NAME` = your package ID
   - `ANDROID_SHA256_FINGERPRINTS` = the fingerprints separated by commas (no spaces)
3. Redeploy, then open `https://YOUR-SITE/.well-known/assetlinks.json`. It must show your package and fingerprints.
4. Install the test version from the Play link. If a browser bar shows at the top, the fingerprint does not match yet.

## Step 6: Go public
After the test period, in Play Console choose **Production > Create release** with the same `.aab`
(or a newer one), then **Send for review**. First reviews usually take a few days.

## Good to know
- Google sign-in works because Android opens it in Chrome. Email and password and the demo always work.
- Updates to the website show up in the app instantly. You only rebuild the `.aab` if you change the
  icon, name or package, and then you must raise the version code.
- A Play Store app is a good extra for a portfolio, but it must give real value, so keep the live demo on.
