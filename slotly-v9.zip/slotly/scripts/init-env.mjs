// Creates .env from .env.example and fills in a random NEXTAUTH_SECRET. Safe to run again.
import { randomBytes } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";

if (!existsSync(".env")) {
  writeFileSync(".env", readFileSync(".env.example", "utf8"));
  console.log("Created .env");
}
let env = readFileSync(".env", "utf8");
if (/^NEXTAUTH_SECRET=("")?\s*$/m.test(env)) {
  env = env.replace(/^NEXTAUTH_SECRET=("")?\s*$/m, `NEXTAUTH_SECRET="${randomBytes(24).toString("hex")}"`);
  writeFileSync(".env", env);
  console.log("Generated a secret key");
}
