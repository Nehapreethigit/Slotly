/**
 * Sample data for demos and screenshots.
 *
 *   npm run db:seed                                   -> creates a public demo host at /demo
 *   npm run db:seed -- --email you@gmail.com          -> also fills YOUR dashboard with sample bookings
 *   npm run db:seed -- --clean                        -> removes everything this script created
 *
 * Safe to run repeatedly. Sample guests all use the reserved domain @demo.slotly.invalid, so cleanup
 * only ever touches data this script made and never real bookings.
 */
import { PrismaClient } from "@prisma/client";
import { DEMO_HOST_EMAIL, ensureDemoHost, fillDemoBookings, removeDemoBookings } from "../src/lib/demo-seed";

const prisma = new PrismaClient();

function flag(name: string): string | undefined {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

async function fillBookings(user: { id: string; timezone: string }, label: string) {
  const { added, removed } = await fillDemoBookings(prisma, user);
  if (added === 0) return console.log(`  ${label}: has no event types yet, so there is nothing to book. Skipped.`);
  console.log(`  ${label}: added ${added} sample bookings${removed ? ` (replaced ${removed} older sample ones)` : ""}.`);
}

async function main() {
  if (process.argv.includes("--clean")) {
    const removed = await removeDemoBookings(prisma);
    const host = await prisma.user.findUnique({ where: { email: DEMO_HOST_EMAIL } });
    if (host) await prisma.user.delete({ where: { id: host.id } }); // its event types and hours cascade
    console.log(`Cleaned: ${removed} sample bookings${host ? " and the demo host" : ""} removed.`);
    return;
  }

  console.log("Seeding sample data...");
  const demo = await ensureDemoHost(prisma);
  console.log(`  Demo host ready: /${demo.username}`);
  await fillBookings(demo, `/${demo.username}`);

  const email = flag("--email") ?? process.env.SEED_EMAIL;
  if (email) {
    const me = await prisma.user.findUnique({ where: { email } });
    if (!me) {
      console.error(`\nNo account found for ${email}. Sign in to Slotly once with that Google account, then run this again.`);
      process.exitCode = 1;
      return;
    }
    await fillBookings(me, `your account (${email})`);
  }
  console.log("Done.");
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
