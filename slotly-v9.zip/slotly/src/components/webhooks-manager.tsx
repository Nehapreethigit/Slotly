"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Eye, EyeOff, Loader2, Mail, Plus, Trash2, Webhook, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFeedback } from "@/components/ui/feedback";
import { LocalTime } from "@/components/local-time";

const EVENTS = [
  { value: "booking.created", label: "Booking created" },
  { value: "booking.rescheduled", label: "Booking rescheduled" },
  { value: "booking.cancelled", label: "Booking cancelled" },
];

type Delivery = {
  id: string;
  event: string;
  success: boolean;
  statusCode: number | null;
  attempts: number;
  error: string | null;
  durationMs: number | null;
  at: string;
};
type Hook = { id: string; url: string; secret: string; secretHint: string; events: string[]; active: boolean; deliveries: Delivery[] };

const VERIFY_SNIPPET = `// Node.js receiver: verify the signature before trusting the payload
import { createHmac, timingSafeEqual } from "node:crypto";

app.post("/slotly", express.raw({ type: "application/json" }), (req, res) => {
  const timestamp = req.header("Slotly-Timestamp");
  const signature = req.header("Slotly-Signature");
  const body = req.body.toString("utf8");

  const expected = "sha256=" + createHmac("sha256", process.env.SLOTLY_SECRET)
    .update(timestamp + "." + body).digest("hex");

  const ok = signature && expected.length === signature.length &&
    timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  if (!ok || Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) return res.sendStatus(401);

  const { event, data } = JSON.parse(body);   // event: "booking.created" ...
  res.sendStatus(200);
});`;

export function WebhooksManager({ hooks, emailOn }: { hooks: Hook[]; emailOn: boolean }) {
  const router = useRouter();
  const { toast, confirm } = useFeedback();
  const [adding, setAdding] = useState(false);
  const [url, setUrl] = useState("");
  const [events, setEvents] = useState<string[]>(EVENTS.map((e) => e.value));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [revealed, setRevealed] = useState<string | null>(null);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const res = await fetch("/api/webhooks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, events }),
    });
    setSaving(false);
    if (!res.ok) return setError((await res.json()).error ?? "Could not create webhook");
    setAdding(false);
    setUrl("");
    toast("Webhook added. Make a test booking to see it fire.");
    router.refresh();
  }

  async function toggle(h: Hook) {
    await fetch(`/api/webhooks/${h.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !h.active }),
    });
    router.refresh();
  }

  async function remove(h: Hook) {
    const ok = await confirm({
      title: "Delete this webhook?",
      body: "Its delivery history is deleted too, and your endpoint stops receiving events.",
      confirmLabel: "Delete webhook",
      tone: "danger",
    });
    if (!ok) return;
    await fetch(`/api/webhooks/${h.id}`, { method: "DELETE" });
    toast("Webhook deleted");
    router.refresh();
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Integrations</h1>
          <p className="mt-1 text-sm text-slate-500">Send booking events to your own systems, and email confirmations.</p>
        </div>
        <button onClick={() => setAdding(true)} className="btn-primary">
          <Plus className="h-4 w-4" /> Add webhook
        </button>
      </div>

      <div className="card mt-8 flex items-start gap-3 p-5">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-400">
          <Mail className="h-5 w-5" />
        </span>
        <div className="text-sm">
          <p className="font-semibold">Email confirmations {emailOn ? "are on" : "are off"}</p>
          <p className="mt-0.5 text-slate-600">
            {emailOn
              ? "Guests and you get a branded email with an .ics attachment for every booking, reschedule and cancellation."
              : "Set RESEND_API_KEY to turn them on. Google Calendar invites are still sent either way."}
          </p>
        </div>
      </div>

      {adding && (
        <form onSubmit={create} className="card mt-6 space-y-4 p-6">
          <div>
            <label className="label">Endpoint URL</label>
            <input
              required
              type="url"
              className="input"
              placeholder="https://example.com/hooks/slotly"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
            <p className="mt-1 text-xs text-slate-500">Must be public https. Private and internal addresses are blocked.</p>
          </div>
          <fieldset>
            <legend className="label">Events</legend>
            <div className="flex flex-wrap gap-2">
              {EVENTS.map((ev) => {
                const on = events.includes(ev.value);
                return (
                  <button
                    type="button"
                    key={ev.value}
                    onClick={() => setEvents((cur) => (on ? cur.filter((x) => x !== ev.value) : [...cur, ev.value]))}
                    aria-pressed={on}
                    className={cn(
                      "rounded-full border px-3 py-1.5 text-sm font-medium",
                      on ? "border-brand-600 bg-brand-50 text-brand-300" : "border-slate-200 text-slate-500",
                    )}
                  >
                    {ev.label}
                  </button>
                );
              })}
            </div>
          </fieldset>
          {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
          <div className="flex gap-2">
            <button type="submit" disabled={saving || events.length === 0} className="btn-primary">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />} Create webhook
            </button>
            <button type="button" onClick={() => setAdding(false)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="mt-6 space-y-4">
        {hooks.length === 0 && !adding && (
          <div className="card flex flex-col items-center px-6 py-12 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-slate-100 text-slate-400">
              <Webhook className="h-6 w-6" />
            </span>
            <p className="mt-4 font-semibold">No webhooks yet</p>
            <p className="mt-1 text-sm text-slate-500">Add one to push bookings into Slack, Zapier, your CRM, or your own backend.</p>
          </div>
        )}

        {hooks.map((h) => (
          <div key={h.id} className={cn("card p-5", !h.active && "opacity-60")}>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate font-mono text-sm font-medium">{h.url}</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {h.events.map((ev) => (
                    <span key={ev} className="badge">
                      {ev}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button onClick={() => toggle(h)} className="btn-ghost !px-3 !py-1.5 text-xs">
                  {h.active ? "Pause" : "Resume"}
                </button>
                <button onClick={() => remove(h)} className="btn-ghost !px-2.5 !py-1.5 hover:!bg-red-500/100/10 hover:!text-red-400" aria-label="Delete webhook">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-xs">
              <span className="font-medium text-slate-500">Signing secret</span>
              <code className="flex-1 truncate font-mono">{revealed === h.id ? h.secret : h.secretHint}</code>
              <button
                onClick={() => setRevealed(revealed === h.id ? null : h.id)}
                className="rounded p-1 text-slate-500 hover:bg-slate-200"
                aria-label={revealed === h.id ? "Hide secret" : "Reveal secret"}
              >
                {revealed === h.id ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>

            <div className="mt-4">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Recent deliveries</p>
              {h.deliveries.length === 0 ? (
                <p className="text-sm text-slate-500">Nothing sent yet. The next booking will show up here.</p>
              ) : (
                <ul className="divide-y divide-slate-100 text-sm">
                  {h.deliveries.map((d) => (
                    <li key={d.id} className="flex items-center gap-3 py-2">
                      {d.success ? (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" aria-label="Delivered" />
                      ) : (
                        <XCircle className="h-4 w-4 shrink-0 text-red-400" aria-label="Failed" />
                      )}
                      <span className="font-mono text-xs">{d.event}</span>
                      <span className="text-slate-500">
                        {d.success ? `HTTP ${d.statusCode}` : (d.error ?? "Failed")}
                        {d.attempts > 1 && ` after ${d.attempts} tries`}
                      </span>
                      <span className="ml-auto text-xs text-slate-400">
                        {d.durationMs != null && `${d.durationMs}ms - `}
                        <LocalTime iso={d.at} />
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        ))}
      </div>

      <details className="card mt-8 p-5">
        <summary className="cursor-pointer text-sm font-semibold">How to verify a webhook on your server</summary>
        <p className="mt-3 text-sm text-slate-600">
          Every request carries <code className="rounded bg-slate-100 px-1">Slotly-Signature</code> and{" "}
          <code className="rounded bg-slate-100 px-1">Slotly-Timestamp</code>. Recompute the HMAC and reject mismatches or old timestamps.
        </p>
        <pre className="mt-3 overflow-x-auto rounded-lg border border-slate-200 bg-black/40 p-4 text-xs leading-relaxed text-slate-800">{VERIFY_SNIPPET}</pre>
      </details>
    </div>
  );
}
