import Link from "next/link";
import { LogoMark } from "@/components/logo";
import { CONTACT_EMAIL, SITE_NAME } from "@/lib/site";

export function LegalPage({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  return (
    <main id="main" className="mx-auto max-w-2xl px-5 py-10 sm:py-14">
      <Link href="/" className="inline-flex items-center gap-2 font-display text-lg font-bold text-slate-900">
        <LogoMark className="h-7 w-7" /> {SITE_NAME}
      </Link>
      <h1 className="mt-10 font-display text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{title}</h1>
      <p className="mt-2 text-sm text-slate-600">Last updated {updated}</p>
      <div className="mt-8 space-y-4 leading-relaxed text-slate-700 [&_h2]:mt-10 [&_h2]:font-display [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:text-slate-900 [&_li]:ml-5 [&_li]:list-disc [&_a]:text-brand-600 [&_a]:underline">
        {children}
        <h2>Contact</h2>
        <p>
          {CONTACT_EMAIL ? (
            <>
              Questions? Email <a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>.
            </>
          ) : (
            <>Questions? Contact the person who runs this site.</>
          )}
        </p>
      </div>
      <p className="mt-12 text-sm">
        <Link href="/" className="text-brand-600 underline">Back to home</Link>
      </p>
    </main>
  );
}
