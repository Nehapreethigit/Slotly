"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Clock, Copy, ExternalLink, Link2, Loader2, MapPin, Pencil, Plus, Trash2, X } from "lucide-react";
import { LOCATIONS, locationLabel } from "@/lib/constants";
import { cn, slugify } from "@/lib/utils";
import { useFeedback } from "@/components/ui/feedback";
import { QuestionsEditor } from "@/components/questions-editor";
import type { Question } from "@/lib/questions";

export type EventTypeDTO = {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  duration: number;
  color: string;
  bufferBefore: number;
  bufferAfter: number;
  minNotice: number;
  maxDaysAhead: number;
  slotInterval: number | null;
  location: string;
  locationDetail: string | null;
  active: boolean;
  bookingCount: number;
  questions: Question[];
};

type FormState = Omit<EventTypeDTO, "id" | "bookingCount" | "active" | "description" | "locationDetail" | "slotInterval"> & {
  description: string;
  locationDetail: string;
  slotInterval: string;
};

const COLORS = ["#7A56FF", "#22D3EE", "#F472B6", "#A3E635", "#FBBF24", "#FB7185", "#60A5FA"];

const emptyForm: FormState = {
  title: "",
  slug: "",
  description: "",
  duration: 30,
  color: COLORS[0],
  bufferBefore: 0,
  bufferAfter: 0,
  minNotice: 240,
  maxDaysAhead: 60,
  slotInterval: "",
  location: "GOOGLE_MEET",
  locationDetail: "",
  questions: [],
};

function formFrom(e: EventTypeDTO): FormState {
  return {
    title: e.title,
    slug: e.slug,
    description: e.description ?? "",
    duration: e.duration,
    color: e.color,
    bufferBefore: e.bufferBefore,
    bufferAfter: e.bufferAfter,
    minNotice: e.minNotice,
    maxDaysAhead: e.maxDaysAhead,
    slotInterval: e.slotInterval ? String(e.slotInterval) : "",
    location: e.location,
    locationDetail: e.locationDetail ?? "",
    questions: e.questions,
  };
}

export function EventTypesManager({ initial, username }: { initial: EventTypeDTO[]; username: string }) {
  const router = useRouter();
  const { toast, confirm } = useFeedback();
  const [editing, setEditing] = useState<EventTypeDTO | "new" | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const link = (slug: string) => `${typeof window === "undefined" ? "" : window.location.origin}/${username}/${slug}`;

  async function copy(slug: string, id: string) {
    await navigator.clipboard.writeText(link(slug));
    setCopied(id);
    toast("Booking link copied");
    setTimeout(() => setCopied(null), 1500);
  }

  async function toggle(e: EventTypeDTO) {
    setBusyId(e.id);
    await fetch(`/api/event-types/${e.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !e.active }),
    });
    setBusyId(null);
    toast(e.active ? `${e.title} is now hidden from your page` : `${e.title} is bookable again`, "info");
    router.refresh();
  }

  async function remove(e: EventTypeDTO) {
    const ok = await confirm({
      title: `Delete "${e.title}"?`,
      body: "Its booking link stops working right away. This can't be undone.",
      confirmLabel: "Delete event type",
      tone: "danger",
    });
    if (!ok) return;
    setError(null);
    setBusyId(e.id);
    const res = await fetch(`/api/event-types/${e.id}`, { method: "DELETE" });
    setBusyId(null);
    if (!res.ok) toast((await res.json()).error ?? "Could not delete this event type", "error");
    else {
      toast("Event type deleted");
      router.refresh();
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Event types</h1>
          <p className="mt-1 text-sm text-slate-500">Create the kinds of meetings people can book with you.</p>
        </div>
        <div className="flex gap-2">
          {username && (
            <a href={`/${username}`} target="_blank" className="btn-secondary">
              <ExternalLink className="h-4 w-4" /> Preview page
            </a>
          )}
          <button onClick={() => setEditing("new")} className="btn-primary">
            <Plus className="h-4 w-4" /> New event type
          </button>
        </div>
      </div>

      {error && <p className="mt-4 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}

      {initial.length === 0 ? (
        <div className="card mt-8 p-12 text-center">
          <p className="font-semibold">No event types yet</p>
          <p className="mt-1 text-sm text-slate-500">Create your first one to get a booking link.</p>
        </div>
      ) : (
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {initial.map((e) => (
            <div
              key={e.id}
              className={cn("card relative overflow-hidden transition", !e.active && "opacity-60")}
            >
              <span className="absolute inset-y-0 left-0 w-1.5" style={{ background: e.color }} />
              <div className="p-5 pl-7">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="truncate font-semibold">{e.title}</h2>
                    <p className="mt-0.5 truncate text-xs text-slate-500">
                      /{username}/{e.slug}
                    </p>
                  </div>
                  <button
                    onClick={() => toggle(e)}
                    disabled={busyId === e.id}
                    role="switch"
                    aria-checked={e.active}
                    aria-label={e.active ? "Turn off" : "Turn on"}
                    className={cn(
                      "relative h-6 w-11 shrink-0 rounded-full transition",
                      e.active ? "bg-brand-600" : "bg-slate-300",
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-5 w-5 rounded-full bg-surface shadow transition-all",
                        e.active ? "left-[22px]" : "left-0.5",
                      )}
                    />
                  </button>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="badge">
                    <Clock className="h-3 w-3" /> {e.duration} min
                  </span>
                  <span className="badge">
                    <MapPin className="h-3 w-3" /> {locationLabel(e.location, e.locationDetail)}
                  </span>
                  {e.bookingCount > 0 && <span className="badge">{e.bookingCount} booked</span>}
                </div>

                <div className="mt-4 flex items-center gap-1.5 border-t border-slate-100 pt-3">
                  <button onClick={() => copy(e.slug, e.id)} className="btn-ghost !px-3 !py-1.5">
                    {copied === e.id ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                    {copied === e.id ? "Copied" : "Copy link"}
                  </button>
                  <a href={`/${username}/${e.slug}`} target="_blank" className="btn-ghost !px-3 !py-1.5">
                    <Link2 className="h-4 w-4" /> Open
                  </a>
                  <span className="flex-1" />
                  <button onClick={() => setEditing(e)} className="btn-ghost !px-2.5 !py-1.5" aria-label="Edit">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => remove(e)}
                    disabled={busyId === e.id}
                    className="btn-ghost !px-2.5 !py-1.5 hover:!bg-red-500/100/10 hover:!text-red-400"
                    aria-label="Delete"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <EventTypeDialog
          existing={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            toast(editing === "new" ? "Event type created" : "Changes saved");
            setEditing(null);
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

function EventTypeDialog({
  existing,
  onClose,
  onSaved,
}: {
  existing: EventTypeDTO | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<FormState>(existing ? formFrom(existing) : emptyForm);
  const [slugTouched, setSlugTouched] = useState(!!existing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [advanced, setAdvanced] = useState(false);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((f) => ({ ...f, [key]: value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const body = {
      title: form.title,
      slug: form.slug,
      description: form.description || null,
      duration: Number(form.duration),
      color: form.color,
      bufferBefore: Number(form.bufferBefore),
      bufferAfter: Number(form.bufferAfter),
      minNotice: Number(form.minNotice),
      maxDaysAhead: Number(form.maxDaysAhead),
      slotInterval: form.slotInterval ? Number(form.slotInterval) : null,
      location: form.location,
      locationDetail: form.location === "GOOGLE_MEET" ? null : form.locationDetail || null,
      questions: form.questions.map((q) => ({
        id: q.id,
        label: q.label.trim(),
        type: q.type,
        required: q.required,
        ...(q.type === "select" ? { options: (q.options ?? []).map((o) => o.trim()).filter(Boolean) } : {}),
      })),
    };

    const res = await fetch(existing ? `/api/event-types/${existing.id}` : "/api/event-types", {
      method: existing ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    setSaving(false);
    if (res.ok) return onSaved();
    setError((await res.json()).error ?? "Something went wrong");
  }

  const num = (key: keyof FormState, label: string, hint?: string) => (
    <div>
      <label className="label">{label}</label>
      <input
        type="number"
        min={0}
        className="input"
        value={form[key] as number}
        onChange={(e) => set(key, e.target.value as never)}
      />
      {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <form
        onSubmit={submit}
        className="card flex max-h-[92vh] w-full max-w-lg flex-col overflow-hidden rounded-b-none shadow-pop sm:rounded-b-2xl"
      >
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <h2 className="text-lg font-semibold">{existing ? "Edit event type" : "New event type"}</h2>
          <button type="button" onClick={onClose} className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4 overflow-y-auto px-6 py-5">
          <div>
            <label className="label">Title</label>
            <input
              required
              autoFocus
              className="input"
              placeholder="e.g. Intro call"
              value={form.title}
              onChange={(e) => {
                set("title", e.target.value);
                if (!slugTouched) set("slug", slugify(e.target.value));
              }}
            />
          </div>

          <div>
            <label className="label">URL</label>
            <div className="flex items-center rounded-lg border border-slate-200 bg-surface focus-within:border-brand-500">
              <span className="pl-3 text-sm text-slate-400">/you/</span>
              <input
                required
                className="w-full rounded-lg bg-transparent px-1.5 py-2.5 text-sm outline-none focus-visible:ring-0"
                value={form.slug}
                onChange={(e) => {
                  setSlugTouched(true);
                  set("slug", slugify(e.target.value));
                }}
              />
            </div>
          </div>

          <div>
            <label className="label">Description</label>
            <textarea
              rows={2}
              className="input resize-none"
              placeholder="What is this meeting about?"
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Duration (min)</label>
              <input
                type="number"
                min={5}
                max={480}
                required
                className="input"
                value={form.duration}
                onChange={(e) => set("duration", e.target.value as never)}
              />
              <div className="mt-2 flex flex-wrap gap-1.5">
                {[15, 30, 45, 60].map((d) => (
                  <button
                    type="button"
                    key={d}
                    onClick={() => set("duration", d)}
                    className={cn(
                      "rounded-full px-2.5 py-1 text-xs font-medium",
                      Number(form.duration) === d ? "bg-brand-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                    )}
                  >
                    {d}m
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="label">Location</label>
              <select className="input" value={form.location} onChange={(e) => set("location", e.target.value)}>
                {LOCATIONS.map((l) => (
                  <option key={l.value} value={l.value}>
                    {l.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {form.location !== "GOOGLE_MEET" && (
            <div>
              <label className="label">{form.location === "IN_PERSON" ? "Address" : "Link or phone number"}</label>
              <input
                className="input"
                value={form.locationDetail}
                onChange={(e) => set("locationDetail", e.target.value)}
                placeholder={form.location === "IN_PERSON" ? "123 MG Road, Bengaluru" : "https://zoom.us/j/..."}
              />
            </div>
          )}

          <div>
            <label className="label">Color</label>
            <div className="flex gap-2">
              {COLORS.map((c) => (
                <button
                  type="button"
                  key={c}
                  onClick={() => set("color", c)}
                  aria-label={c}
                  className={cn("h-7 w-7 rounded-full ring-offset-2 transition", form.color === c && "ring-2 ring-slate-900")}
                  style={{ background: c }}
                />
              ))}
            </div>
          </div>

          <QuestionsEditor value={form.questions} onChange={(questions) => set("questions", questions)} />

          <button type="button" onClick={() => setAdvanced((v) => !v)} className="text-sm font-medium text-brand-400 hover:underline">
            {advanced ? "Hide" : "Show"} advanced settings
          </button>

          {advanced && (
            <div className="grid grid-cols-2 gap-4 rounded-xl bg-slate-50 p-4">
              {num("bufferBefore", "Buffer before (min)", "Free time before each meeting")}
              {num("bufferAfter", "Buffer after (min)", "Free time after each meeting")}
              {num("minNotice", "Minimum notice (min)", "240 = 4 hours")}
              {num("maxDaysAhead", "Book up to (days ahead)")}
              <div className="col-span-2">
                <label className="label">Slot interval (min)</label>
                <input
                  type="number"
                  min={5}
                  className="input"
                  placeholder="Same as duration"
                  value={form.slotInterval}
                  onChange={(e) => set("slotInterval", e.target.value)}
                />
                <p className="mt-1 text-xs text-slate-500">How often a new start time is offered. Leave empty to use the duration.</p>
              </div>
            </div>
          )}

          {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
        </div>

        <div className="flex justify-end gap-2 border-t border-slate-100 bg-slate-50/60 px-6 py-4">
          <button type="button" onClick={onClose} className="btn-secondary">
            Cancel
          </button>
          <button type="submit" disabled={saving} className="btn-primary">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {existing ? "Save changes" : "Create"}
          </button>
        </div>
      </form>
    </div>
  );
}
