"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CalendarOff, Check, Globe, Loader2, Plus, X } from "lucide-react";
import { WEEKDAYS, WEEKDAY_ORDER } from "@/lib/constants";
import { cn, minutesToTime, timeToMinutes } from "@/lib/utils";
import { useFeedback } from "@/components/ui/feedback";

type Rule = { weekday: number; startMin: number; endMin: number };
type DayState = { enabled: boolean; intervals: { start: string; end: string }[] };

function toDayState(rules: Rule[]): Record<number, DayState> {
  const state: Record<number, DayState> = {};
  for (let d = 0; d < 7; d++) {
    const intervals = rules
      .filter((r) => r.weekday === d)
      .map((r) => ({ start: minutesToTime(r.startMin), end: minutesToTime(r.endMin) }));
    state[d] = { enabled: intervals.length > 0, intervals };
  }
  return state;
}

export function AvailabilityEditor({
  initialWeekly,
  initialBlocked,
  timezone,
}: {
  initialWeekly: Rule[];
  initialBlocked: string[];
  timezone: string;
}) {
  const router = useRouter();
  const { toast } = useFeedback();
  const [days, setDays] = useState(() => toDayState(initialWeekly));
  const [blocked, setBlocked] = useState<string[]>(initialBlocked);
  const [newBlocked, setNewBlocked] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  function update(day: number, fn: (d: DayState) => DayState) {
    setSaved(false);
    setDays((s) => ({ ...s, [day]: fn(s[day]) }));
  }

  function toggleDay(day: number) {
    update(day, (d) =>
      d.enabled
        ? { ...d, enabled: false }
        : { enabled: true, intervals: d.intervals.length ? d.intervals : [{ start: "09:00", end: "17:00" }] },
    );
  }

  function addInterval(day: number) {
    update(day, (d) => {
      const lastEnd = d.intervals.at(-1)?.end ?? "09:00";
      const startMin = Math.min(timeToMinutes(lastEnd) + 60, 22 * 60);
      return {
        ...d,
        intervals: [...d.intervals, { start: minutesToTime(startMin), end: minutesToTime(Math.min(startMin + 120, 1439)) }],
      };
    });
  }

  function copyToWeekdays(from: number) {
    setSaved(false);
    setDays((s) => {
      const next = { ...s };
      for (const d of [1, 2, 3, 4, 5]) next[d] = { enabled: s[from].enabled, intervals: s[from].intervals.map((i) => ({ ...i })) };
      return next;
    });
  }

  async function save() {
    setError(null);
    const weekly: Rule[] = [];
    for (const day of WEEKDAY_ORDER) {
      if (!days[day].enabled) continue;
      for (const { start, end } of days[day].intervals) {
        const startMin = timeToMinutes(start);
        const endMin = timeToMinutes(end);
        if (Number.isNaN(startMin) || Number.isNaN(endMin) || endMin <= startMin) {
          setError(`${WEEKDAYS[day]}: end time must be after start time.`);
          return;
        }
        weekly.push({ weekday: day, startMin, endMin });
      }
    }

    setSaving(true);
    const res = await fetch("/api/availability", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ weekly, blockedDates: blocked }),
    });
    setSaving(false);
    if (!res.ok) return setError((await res.json()).error ?? "Could not save");
    setSaved(true);
    toast("Availability saved. New bookings follow these hours.");
    router.refresh();
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Availability</h1>
          <p className="mt-1 flex items-start gap-1.5 text-sm text-slate-500">
            <Globe className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              Times are in <strong className="font-medium text-slate-700">{timezone}</strong>.{" "}
              <Link href="/dashboard/settings" className="font-medium text-brand-400 hover:underline">
                Change timezone
              </Link>
            </span>
          </p>
        </div>
        <button onClick={save} disabled={saving} className="btn-primary min-w-[120px]">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <Check className="h-4 w-4" /> : null}
          {saved ? "Saved" : "Save changes"}
        </button>
      </div>

      {error && <p className="mt-4 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}

      <div className="card mt-8 divide-y divide-slate-100">
        {WEEKDAY_ORDER.map((day) => {
          const d = days[day];
          return (
            <div key={day} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-start sm:p-5">
              <div className="flex w-44 shrink-0 items-center gap-3 pt-1.5">
                <button
                  onClick={() => toggleDay(day)}
                  role="switch"
                  aria-checked={d.enabled}
                  aria-label={`Toggle ${WEEKDAYS[day]}`}
                  className={cn("relative h-6 w-11 shrink-0 rounded-full transition", d.enabled ? "bg-brand-600" : "bg-slate-300")}
                >
                  <span
                    className={cn(
                      "absolute top-0.5 h-5 w-5 rounded-full bg-surface shadow transition-all",
                      d.enabled ? "left-[22px]" : "left-0.5",
                    )}
                  />
                </button>
                <span className={cn("text-sm font-medium", !d.enabled && "text-slate-400")}>{WEEKDAYS[day]}</span>
              </div>

              <div className="flex-1 space-y-2">
                {!d.enabled && <p className="pt-1.5 text-sm text-slate-400">Unavailable</p>}
                {d.enabled &&
                  d.intervals.map((iv, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <input
                        type="time"
                        aria-label={`${WEEKDAYS[day]} start time`}
                        value={iv.start}
                        onChange={(e) =>
                          update(day, (s) => ({
                            ...s,
                            intervals: s.intervals.map((x, j) => (j === i ? { ...x, start: e.target.value } : x)),
                          }))
                        }
                        className="input !w-32"
                      />
                      <span className="text-slate-400">-</span>
                      <input
                        type="time"
                        aria-label={`${WEEKDAYS[day]} end time`}
                        value={iv.end}
                        onChange={(e) =>
                          update(day, (s) => ({
                            ...s,
                            intervals: s.intervals.map((x, j) => (j === i ? { ...x, end: e.target.value } : x)),
                          }))
                        }
                        className="input !w-32"
                      />
                      <button
                        onClick={() =>
                          update(day, (s) => {
                            const intervals = s.intervals.filter((_, j) => j !== i);
                            return { enabled: intervals.length > 0, intervals };
                          })
                        }
                        className="rounded-md p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                        aria-label="Remove interval"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
              </div>

              {d.enabled && (
                <div className="flex gap-1 sm:pt-0.5">
                  <button onClick={() => addInterval(day)} className="btn-ghost !px-2.5 !py-1.5 text-xs" title="Add another time range">
                    <Plus className="h-4 w-4" />
                  </button>
                  <button onClick={() => copyToWeekdays(day)} className="btn-ghost !px-2.5 !py-1.5 text-xs" title="Copy to Mon-Fri">
                    Copy to weekdays
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="card mt-8 p-5 sm:p-6">
        <div className="flex items-center gap-2">
          <CalendarOff className="h-5 w-5 text-slate-500" />
          <h2 className="font-semibold">Days off</h2>
        </div>
        <p className="mt-1 text-sm text-slate-500">Block whole dates (holidays, leave) even if they fall in your weekly hours.</p>

        <div className="mt-4 flex gap-2">
          <input type="date" aria-label="Date to block" min={today} value={newBlocked} onChange={(e) => setNewBlocked(e.target.value)} className="input !w-48" />
          <button
            onClick={() => {
              if (!newBlocked || blocked.includes(newBlocked)) return;
              setBlocked((b) => [...b, newBlocked].sort());
              setNewBlocked("");
              setSaved(false);
            }}
            className="btn-secondary"
          >
            <Plus className="h-4 w-4" /> Add
          </button>
        </div>

        {blocked.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {blocked.map((date) => (
              <span key={date} className="badge !bg-amber-400/10 !text-amber-200 ring-1 ring-amber-400/30">
                {new Date(`${date}T00:00:00Z`).toLocaleDateString("en-GB", {
                  weekday: "short",
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                  timeZone: "UTC",
                })}
                <button
                  onClick={() => {
                    setBlocked((b) => b.filter((x) => x !== date));
                    setSaved(false);
                  }}
                  aria-label={`Remove ${date}`}
                  className="rounded-full p-0.5 hover:bg-amber-400/15"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
