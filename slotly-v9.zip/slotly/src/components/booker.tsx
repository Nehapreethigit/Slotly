"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { formatInTimeZone } from "date-fns-tz";
import { ArrowLeft, CalendarDays, ChevronLeft, ChevronRight, Clock, Globe, Loader2, MapPin, Sparkles, Video, Zap } from "lucide-react";
import { locationLabel } from "@/lib/constants";
import { cn, initials } from "@/lib/utils";
import type { Question } from "@/lib/questions";
import { pickHighlights, verdict, type SlotVerdict } from "@/lib/slot-intel";

type Props = {
  host: { name: string; username: string; image: string | null };
  eventType: {
    title: string;
    slug: string;
    description: string | null;
    duration: number;
    color: string;
    location: string;
    locationDetail: string | null;
    maxDaysAhead: number;
    questions?: Question[];
  };
  reschedule?: { uid: string; name: string; email: string; answers?: Record<string, string> };
};

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const pad = (n: number) => String(n).padStart(2, "0");
const key = (y: number, m: number, d: number) => `${y}-${pad(m + 1)}-${pad(d)}`;

export function Booker({ host, eventType, reschedule }: Props) {
  const router = useRouter();

  // Browser-dependent state is set after mount to avoid server/client hydration mismatches.
  const [tz, setTz] = useState("UTC");
  const [mounted, setMounted] = useState(false);
  const [hour12, setHour12] = useState(true);

  const [cursor, setCursor] = useState<{ y: number; m: number }>(() => {
    const now = new Date();
    return { y: now.getUTCFullYear(), m: now.getUTCMonth() };
  });
  const [slots, setSlots] = useState<string[]>([]);
  const [packed, setPacked] = useState<Set<string>>(new Set());
  const [hostTz, setHostTz] = useState("UTC");
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const [name, setName] = useState(reschedule?.name ?? "");
  const [email, setEmail] = useState(reschedule?.email ?? "");
  const [notes, setNotes] = useState("");
  const questions = eventType.questions ?? [];
  const [answers, setAnswers] = useState<Record<string, string>>(reschedule?.answers ?? {});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    const detected = Intl.DateTimeFormat().resolvedOptions().timeZone;
    setTz(detected);
    const now = new Date();
    setCursor({ y: Number(formatInTimeZone(now, detected, "yyyy")), m: Number(formatInTimeZone(now, detected, "M")) - 1 });
    setMounted(true);
  }, []);

  // Fetch availability for the visible month. The window is padded by a day each side so
  // dates near the edges are complete whatever timezone the guest is in.
  useEffect(() => {
    if (!mounted) return;
    const controller = new AbortController();
    setLoading(true);
    setLoadError(false);

    const start = new Date(Date.UTC(cursor.y, cursor.m, 1) - 24 * 3600_000);
    const end = new Date(Date.UTC(cursor.y, cursor.m + 1, 1) + 24 * 3600_000);
    const params = new URLSearchParams({
      username: host.username,
      slug: eventType.slug,
      start: start.toISOString(),
      end: end.toISOString(),
    });
    if (reschedule) params.set("exclude", reschedule.uid);

    fetch(`/api/slots?${params}`, { signal: controller.signal })
      .then((r) => (r.ok ? r.json() : Promise.reject(r)))
      .then((data: { slots: string[]; packed?: string[]; hostTimezone?: string }) => {
        setSlots(data.slots);
        setPacked(new Set(data.packed ?? []));
        if (data.hostTimezone) setHostTz(data.hostTimezone);
        setLoading(false);
      })
      .catch((err) => {
        if (err?.name === "AbortError") return;
        setLoadError(true);
        setLoading(false);
      });

    return () => controller.abort();
  }, [mounted, cursor, host.username, eventType.slug, reschedule, reloadKey]);

  const byDate = useMemo(() => {
    const map: Record<string, string[]> = {};
    for (const iso of slots) (map[formatInTimeZone(iso, tz, "yyyy-MM-dd")] ??= []).push(iso);
    return map;
  }, [slots, tz]);

  const timezones = useMemo(() => {
    const all = Intl.supportedValuesOf("timeZone");
    return all.includes(tz) ? all : [tz, ...all];
  }, [tz]);

  // Calendar grid for the visible month
  const firstWeekday = new Date(Date.UTC(cursor.y, cursor.m, 1)).getUTCDay();
  const daysInMonth = new Date(Date.UTC(cursor.y, cursor.m + 1, 0)).getUTCDate();
  const todayKey = mounted ? formatInTimeZone(new Date(), tz, "yyyy-MM-dd") : "";
  const horizonKey = mounted ? formatInTimeZone(new Date(Date.now() + eventType.maxDaysAhead * 86400_000), tz, "yyyy-MM-dd") : "";
  const monthStartKey = key(cursor.y, cursor.m, 1);
  const monthEndKey = key(cursor.y, cursor.m, daysInMonth);
  const canGoPrev = mounted && monthStartKey > todayKey.slice(0, 8) + "01";
  const canGoNext = mounted && monthEndKey < horizonKey;

  function shiftMonth(delta: number) {
    setSelectedDate(null);
    setSelectedSlot(null);
    setCursor(({ y, m }) => {
      const d = new Date(Date.UTC(y, m + delta, 1));
      return { y: d.getUTCFullYear(), m: d.getUTCMonth() };
    });
  }

  const fmtTime = (iso: string) => formatInTimeZone(iso, tz, hour12 ? "h:mm a" : "HH:mm");
  const timesForSelected = selectedDate ? (byDate[selectedDate] ?? []) : [];
  const verdicts = useMemo(() => {
    const out: Record<string, SlotVerdict> = {};
    for (const iso of timesForSelected) out[iso] = verdict(iso, eventType.duration, tz, hostTz);
    return out;
  }, [timesForSelected, tz, hostTz, eventType.duration]);
  const highlights = useMemo(() => pickHighlights(timesForSelected, packed, verdicts), [timesForSelected, packed, verdicts]);
  const firstOpenDate = Object.keys(byDate).filter((k) => k >= monthStartKey && k <= monthEndKey).sort()[0];

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedSlot) return;
    setSubmitting(true);
    setFormError(null);

    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: host.username,
          slug: eventType.slug,
          start: selectedSlot,
          name,
          email,
          notes: notes || undefined,
          answers: questions.length ? answers : undefined,
          timezone: tz,
          rescheduleUid: reschedule?.uid,
        }),
      });
      const data = await res.json();
      if (res.ok) return router.push(`/booking/${data.uid}`);

      setFormError(data.error ?? "Something went wrong. Please try again.");
      if (res.status === 409) {
        // Slot got taken - go back to the time list with fresh availability.
        setSelectedSlot(null);
        setReloadKey((k) => k + 1);
      }
    } catch {
      setFormError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  const isMeet = eventType.location === "GOOGLE_MEET";

  return (
    <div className="card mx-auto grid max-w-4xl animate-fade-up overflow-hidden md:grid-cols-[280px_1fr]">
      {/* Left: who and what */}
      <aside className="border-b border-slate-100 bg-slate-50/60 p-6 md:border-b-0 md:border-r">
        <div className="flex items-center gap-3">
          {host.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={host.image} alt="" className="h-11 w-11 rounded-full" referrerPolicy="no-referrer" />
          ) : (
            <span className="grid h-11 w-11 place-items-center rounded-full bg-brand-100 font-semibold text-brand-300">
              {initials(host.name)}
            </span>
          )}
          <p className="text-sm font-medium text-slate-500">{host.name}</p>
        </div>

        <h1 className="mt-5 text-xl font-bold leading-snug tracking-tight">
          {reschedule ? "Reschedule: " : ""}
          {eventType.title}
        </h1>

        <ul className="mt-4 space-y-2.5 text-sm text-slate-600">
          <li className="flex items-center gap-2.5">
            <Clock className="h-4 w-4 shrink-0 text-slate-400" /> {eventType.duration} minutes
          </li>
          <li className="flex items-center gap-2.5">
            {isMeet ? <Video className="h-4 w-4 shrink-0 text-slate-400" /> : <MapPin className="h-4 w-4 shrink-0 text-slate-400" />}
            {locationLabel(eventType.location, eventType.locationDetail)}
          </li>
          {selectedSlot && (
            <li className="flex items-start gap-2.5 font-medium text-slate-900">
              <CalendarDays className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
              <span>
                {formatInTimeZone(selectedSlot, tz, "EEEE, d MMMM yyyy")}
                <br />
                {fmtTime(selectedSlot)} - {fmtTime(new Date(new Date(selectedSlot).getTime() + eventType.duration * 60_000).toISOString())}
              </span>
            </li>
          )}
          <li className="flex items-center gap-2.5">
            <Globe className="h-4 w-4 shrink-0 text-slate-400" /> {tz.replace(/_/g, " ")}
          </li>
        </ul>

        {eventType.description && <p className="mt-5 text-sm leading-relaxed text-slate-600">{eventType.description}</p>}
      </aside>

      {/* Right: calendar + times, or the form */}
      <section className="p-6 md:p-8">
        {selectedSlot ? (
          <form onSubmit={submit} className="mx-auto max-w-md animate-fade-up">
            <button
              type="button"
              onClick={() => setSelectedSlot(null)}
              className="mb-5 inline-flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-800"
            >
              <ArrowLeft className="h-4 w-4" /> Back
            </button>
            <h2 className="text-lg font-semibold">Enter your details</h2>

            <div className="mt-5 space-y-4">
              <div>
                <label className="label" htmlFor="name">
                  Your name
                </label>
                <input id="name" required className="input" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
              </div>
              <div>
                <label className="label" htmlFor="email">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  className="input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  placeholder="you@example.com"
                />
                <p className="mt-1 text-xs text-slate-500">The calendar invite is sent here.</p>
              </div>
              {questions.map((q) => {
                const id = `q-${q.id}`;
                const value = answers[q.id] ?? "";
                const set = (v: string) => setAnswers((cur) => ({ ...cur, [q.id]: v }));
                return (
                  <div key={q.id}>
                    <label className="label" htmlFor={id}>
                      {q.label} {!q.required && <span className="font-normal text-slate-400">(optional)</span>}
                    </label>
                    {q.type === "textarea" ? (
                      <textarea id={id} rows={3} maxLength={1000} required={q.required} className="input resize-none" value={value} onChange={(e) => set(e.target.value)} />
                    ) : q.type === "select" ? (
                      <select id={id} required={q.required} className="input" value={value} onChange={(e) => set(e.target.value)}>
                        <option value="">Choose one</option>
                        {q.options?.map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input id={id} type="text" maxLength={200} required={q.required} className="input" value={value} onChange={(e) => set(e.target.value)} />
                    )}
                  </div>
                );
              })}
              <div>
                <label className="label" htmlFor="notes">
                  Anything to share beforehand? <span className="font-normal text-slate-400">(optional)</span>
                </label>
                <textarea id="notes" rows={3} maxLength={1000} className="input resize-none" value={notes} onChange={(e) => setNotes(e.target.value)} />
              </div>

              {formError && <p className="rounded-lg bg-red-500/10 px-3 py-2.5 text-sm text-red-300">{formError}</p>}

              <button type="submit" disabled={submitting} className="btn-primary w-full !py-3">
                {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                {reschedule ? "Confirm new time" : "Confirm booking"}
              </button>
            </div>
          </form>
        ) : (
          <div className="grid gap-8 lg:grid-cols-[1fr_190px]">
            {/* Calendar */}
            <div>
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-base font-semibold">
                  {MONTHS[cursor.m]} <span className="font-normal text-slate-400">{cursor.y}</span>
                </h2>
                <div className="flex gap-1">
                  <button onClick={() => shiftMonth(-1)} disabled={!canGoPrev} className="btn-ghost !p-2" aria-label="Previous month">
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  <button onClick={() => shiftMonth(1)} disabled={!canGoNext} className="btn-ghost !p-2" aria-label="Next month">
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {!loading && !loadError && !selectedDate && (
                firstOpenDate ? (
                  <button
                    onClick={() => setSelectedDate(firstOpenDate)}
                    className="mb-3 inline-flex items-center gap-2 rounded-lg bg-slot-100 px-3 py-2 text-sm font-semibold text-slate-900 transition hover:bg-slot-200"
                  >
                    <Zap className="h-4 w-4" />
                    Next available: {formatInTimeZone(`${firstOpenDate}T12:00:00Z`, "UTC", "EEE d MMM")}
                  </button>
                ) : (
                  canGoNext && (
                    <button onClick={() => shiftMonth(1)} className="mb-3 inline-flex items-center gap-2 rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold hover:border-slate-900">
                      Nothing left this month. Check next month
                    </button>
                  )
                )
              )}

              <div className="grid grid-cols-7 gap-1 text-center">
                {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => (
                  <span key={d} className="pb-2 text-xs font-medium text-slate-400">
                    {d}
                  </span>
                ))}
                {Array.from({ length: firstWeekday }).map((_, i) => (
                  <span key={`blank-${i}`} />
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const d = i + 1;
                  const k = key(cursor.y, cursor.m, d);
                  const available = !!byDate[k]?.length;
                  const selected = selectedDate === k;
                  return (
                    <button
                      key={k}
                      disabled={!available}
                      onClick={() => setSelectedDate(k)}
                      title={available ? `${byDate[k].length} times` : undefined}
                      aria-pressed={selected}
                      className={cn(
                        "relative aspect-square rounded-xl text-sm transition",
                        loading && "animate-pulse",
                        selected
                          ? "bg-brand-600 font-bold text-white"
                          : available
                            ? "bg-slot-100 font-semibold text-slate-900 hover:bg-slot-200"
                            : "cursor-default text-slate-300",
                      )}
                    >
                      {d}
                      {k === todayKey && (
                        <span className={cn("absolute bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full", selected ? "bg-surface" : "bg-brand-600")} />
                      )}
                    </button>
                  );
                })}
              </div>

              {loadError && (
                <p className="mt-4 rounded-lg bg-red-500/10 px-3 py-2.5 text-sm text-red-300">
                  Could not load availability.{" "}
                  <button className="font-semibold underline" onClick={() => setReloadKey((k) => k + 1)}>
                    Try again
                  </button>
                </p>
              )}


              <div className="mt-5">
                <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-slate-500" htmlFor="tz">
                  <Globe className="h-3.5 w-3.5" /> Timezone
                </label>
                <select
                  id="tz"
                  value={tz}
                  onChange={(e) => {
                    setTz(e.target.value);
                    setSelectedDate(null);
                  }}
                  className="input !py-2 text-xs"
                >
                  {timezones.map((z) => (
                    <option key={z} value={z}>
                      {z.replace(/_/g, " ")}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Times */}
            <div className="min-h-[120px]">
              {selectedDate ? (
                <div className="animate-fade-up">
                  <div className="mb-3 flex items-center justify-between">
                    <h3 className="text-sm font-semibold">{formatInTimeZone(`${selectedDate}T12:00:00Z`, "UTC", "EEE d")}</h3>
                    <div className="inline-flex rounded-md bg-slate-100 p-0.5 text-xs font-medium">
                      {[true, false].map((is12) => (
                        <button
                          key={String(is12)}
                          onClick={() => setHour12(is12)}
                          className={cn("rounded px-2 py-1", hour12 === is12 ? "bg-surface shadow-sm" : "text-slate-500")}
                        >
                          {is12 ? "12h" : "24h"}
                        </button>
                      ))}
                    </div>
                  </div>
                  {highlights.length > 0 && timesForSelected.length > 3 && (
                    <div className="mb-3 flex flex-wrap gap-1.5" aria-label="Suggested times">
                      {highlights.map((h) => (
                        <button
                          key={h.label}
                          onClick={() => setSelectedSlot(h.iso)}
                          className="inline-flex items-center gap-1.5 rounded-full border border-brand-500/40 bg-brand-500/10 px-2.5 py-1 text-xs font-semibold text-brand-300 transition hover:bg-brand-500/20"
                        >
                          <Sparkles className="h-3 w-3" aria-hidden />
                          {h.label} <span className="tabular-nums text-slate-700">{fmtTime(h.iso)}</span>
                        </button>
                      ))}
                    </div>
                  )}
                  <div className="flex max-h-[360px] flex-col gap-2 overflow-y-auto pr-1">
                    {timesForSelected.map((iso) => {
                      const v = verdicts[iso];
                      const note = v?.guest !== "good" ? (v.guest === "night" ? "Very late/early for you" : "A stretch for you") : v?.host !== "good" ? `A stretch for ${host.name.split(" ")[0]}` : null;
                      return (
                        <button
                          key={iso}
                          onClick={() => setSelectedSlot(iso)}
                          className="rounded-lg border border-slate-200 bg-surface px-3 py-2 text-left text-sm font-semibold tabular-nums text-slate-900 transition hover:border-brand-600 hover:text-brand-300"
                        >
                          <span className="whitespace-nowrap">{fmtTime(iso)}</span>
                          <span className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] font-medium empty:hidden">
                            {packed.has(iso) && <span className="text-slot-300">Best fit</span>}
                            {v?.both ? (
                              <span className="text-slate-600">Fair for both</span>
                            ) : (
                              note && <span className="text-amber-300">{note}</span>
                            )}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  <p className="mt-3 text-[11px] leading-relaxed text-slate-600">
                    <span className="text-slot-300">Best fit</span> keeps {host.name.split(" ")[0]}&apos;s day tidy. <span>Fair for both</span> means a
                    sensible hour in both your timezones.
                  </p>
                </div>
              ) : (
                <p className="pt-10 text-center text-sm text-slate-400 lg:pt-12">
                  {loading ? "Loading times..." : "Select a highlighted date to see times."}
                </p>
              )}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
