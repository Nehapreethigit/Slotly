"use client";

import { useEffect, useState } from "react";
import { CalendarCheck, Check, ChevronLeft, ChevronRight, Clock, EyeOff, Video } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Interactive, fully client-side demo of the booking page, used as the landing hero.
 * Sample data only: nothing is sent anywhere. Availability is generated from the date so it looks real
 * (weekends off, some days fully busy, some half-hours hidden because "Aarav" has a meeting).
 */

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const DAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
const BASE_TIMES = Array.from({ length: 16 }, (_, i) => {
  const mins = 9 * 60 + i * 30;
  return `${String(Math.floor(mins / 60)).padStart(2, "0")}:${String(mins % 60).padStart(2, "0")}`;
});

function dayData(d: Date, today: Date): { open: string[]; hidden: number } | null {
  const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  if (d <= startOfToday) return null; // past and today
  if (d.getDay() === 0 || d.getDay() === 6) return null; // weekend
  const seed = d.getDate() * 31 + d.getMonth() * 7;
  if (seed % 7 === 0) return null; // a fully booked day
  const open: string[] = [];
  let hidden = 0;
  BASE_TIMES.forEach((t, i) => {
    if ((seed + i * 5) % 4 === 0) hidden += 1;
    else open.push(t);
  });
  return { open: open.slice(0, 8), hidden };
}

const fmtDay = (d: Date) => d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });

export function LiveDemo() {
  const [today, setToday] = useState<Date | null>(null);
  const [cursor, setCursor] = useState({ y: 0, m: 0 });
  const [pickedDate, setPickedDate] = useState<Date | null>(null);
  const [pickedTime, setPickedTime] = useState<string | null>(null);
  const [booked, setBooked] = useState(false);

  // Set after mount so the server and first client render match (no hydration mismatch).
  useEffect(() => {
    const now = new Date();
    setToday(now);
    setCursor({ y: now.getFullYear(), m: now.getMonth() });
  }, []);

  if (!today) {
    return <div className="card h-[560px] animate-pulse bg-slate-100" aria-hidden />;
  }

  const first = new Date(cursor.y, cursor.m, 1).getDay();
  const count = new Date(cursor.y, cursor.m + 1, 0).getDate();
  const canPrev = cursor.y * 12 + cursor.m > today.getFullYear() * 12 + today.getMonth();
  const shift = (n: number) => {
    const d = new Date(cursor.y, cursor.m + n, 1);
    setCursor({ y: d.getFullYear(), m: d.getMonth() });
    setPickedDate(null);
    setPickedTime(null);
  };
  const picked = pickedDate ? dayData(pickedDate, today) : null;

  function reset() {
    setBooked(false);
    setPickedDate(null);
    setPickedTime(null);
  }

  return (
    <div className="card overflow-hidden shadow-lift" role="group" aria-label="Interactive booking demo with sample data">
      <div className="flex items-center gap-3 border-b border-slate-200 bg-surface px-5 py-4">
        <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand-600 to-[#C04BFF] font-display text-sm font-bold text-white">AR</span>
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold leading-tight">Aarav Rao</p>
          <p className="mt-0.5 flex items-center gap-3 text-xs text-slate-500">
            <span className="inline-flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" /> 30 min
            </span>
            <span className="inline-flex items-center gap-1">
              <Video className="h-3.5 w-3.5" /> Google Meet
            </span>
          </p>
        </div>
        <span className="rounded-md bg-slot-100 px-2 py-1 text-xs font-semibold text-slot-700">Try it</span>
      </div>

      {booked && pickedDate && pickedTime ? (
        <div className="animate-pop-in px-6 py-8">
          <span className="grid h-12 w-12 place-items-center rounded-full bg-brand-600 text-white">
            <Check className="h-6 w-6" />
          </span>
          <h3 className="mt-4 text-xl font-bold">Booked for {fmtDay(pickedDate)}, {pickedTime}</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-slate-700">
            <li className="flex items-center gap-2.5">
              <Video className="h-4 w-4 text-brand-400" /> A Google Meet link was created
            </li>
            <li className="flex items-center gap-2.5">
              <CalendarCheck className="h-4 w-4 text-brand-400" /> The event is on both calendars
            </li>
            <li className="flex items-center gap-2.5">
              <EyeOff className="h-4 w-4 text-brand-400" /> {pickedTime} is now hidden from everyone else
            </li>
          </ul>
          <button onClick={reset} className="btn-secondary mt-6">
            Try another time
          </button>
        </div>
      ) : (
        <div className="px-5 pb-5 pt-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="font-display text-lg font-bold">
              {MONTHS[cursor.m]} <span className="font-medium text-slate-400">{cursor.y}</span>
            </p>
            <div className="flex">
              <button onClick={() => shift(-1)} disabled={!canPrev} className="btn-ghost !p-2" aria-label="Previous month">
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button onClick={() => shift(1)} className="btn-ghost !p-2" aria-label="Next month">
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1 text-center">
            {DAYS.map((d) => (
              <span key={d} className="pb-1 text-xs font-medium text-slate-400">
                {d}
              </span>
            ))}
            {Array.from({ length: first }).map((_, i) => (
              <span key={`b${i}`} />
            ))}
            {Array.from({ length: count }).map((_, i) => {
              const date = new Date(cursor.y, cursor.m, i + 1);
              const open = !!dayData(date, today);
              const sel = pickedDate?.getTime() === date.getTime();
              return (
                <button
                  key={i}
                  disabled={!open}
                  onClick={() => {
                    setPickedDate(date);
                    setPickedTime(null);
                  }}
                  aria-pressed={sel}
                  className={cn(
                    "aspect-square rounded-lg text-sm tabular-nums transition",
                    sel ? "bg-brand-600 font-bold text-white" : open ? "bg-slot-100 font-semibold text-slate-900 hover:bg-slot-200" : "cursor-default text-slate-300",
                  )}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>

          <div className="mt-4 min-h-[148px] border-t border-slate-200 pt-4">
            {picked && pickedDate ? (
              <div key={pickedDate.getTime()} className="animate-fade-up">
                <p className="text-sm font-semibold">{fmtDay(pickedDate)}</p>
                <div className="mt-2.5 grid grid-cols-4 gap-2">
                  {picked.open.map((t) => (
                    <button
                      key={t}
                      onClick={() => setPickedTime(t)}
                      aria-pressed={pickedTime === t}
                      className={cn(
                        "rounded-lg border py-2 text-sm font-semibold tabular-nums transition",
                        pickedTime === t ? "border-brand-600 bg-brand-600 text-white shadow-glow" : "border-slate-200 hover:border-brand-600 hover:text-brand-300",
                      )}
                    >
                      {t}
                    </button>
                  ))}
                </div>
                <p className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
                  <EyeOff className="h-3.5 w-3.5" />
                  {picked.hidden} times hidden because Aarav is busy in Google Calendar
                </p>
                {pickedTime && (
                  <button onClick={() => setBooked(true)} className="btn-primary mt-4 w-full animate-fade-up">
                    Book {pickedTime} on {fmtDay(pickedDate)}
                  </button>
                )}
              </div>
            ) : (
              <p className="pt-6 text-center text-sm text-slate-500">Pick a highlighted day to see the times that are really free.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
