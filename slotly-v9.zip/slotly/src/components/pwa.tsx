"use client";

import { useEffect, useState } from "react";
import { Download, Share, X } from "lucide-react";

type InstallEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

/** Registers the service worker once. Renders nothing. */
export function RegisterServiceWorker() {
  useEffect(() => {
    if (!("serviceWorker" in navigator) || process.env.NODE_ENV !== "production") return;
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);
  return null;
}

/** "Install Slotly" card: one tap on Android/desktop Chrome, a short hint on iPhone. */
export function InstallApp() {
  const [event, setEvent] = useState<InstallEvent | null>(null);
  const [ios, setIos] = useState(false);
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone;
    let dismissed = false;
    try {
      dismissed = localStorage.getItem("slotly-install-dismissed") === "1";
    } catch {}
    if (standalone || dismissed) return;

    const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
    if (isIos) {
      setIos(true);
      setHidden(false);
    }
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvent(e as InstallEvent);
      setHidden(false);
    };
    const onInstalled = () => setHidden(true);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  function dismiss() {
    setHidden(true);
    try {
      localStorage.setItem("slotly-install-dismissed", "1");
    } catch {}
  }

  async function install() {
    if (!event) return;
    await event.prompt();
    await event.userChoice.catch(() => null);
    setEvent(null);
    setHidden(true);
  }

  if (hidden || (!event && !ios)) return null;

  return (
    <div className="card mb-6 flex items-center gap-3 p-4" role="region" aria-label="Install the app">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-500/15 text-brand-300">
        <Download className="h-5 w-5" aria-hidden />
      </div>
      <div className="min-w-0 flex-1 text-sm">
        <p className="font-semibold text-slate-900">Install Slotly on your phone</p>
        <p className="text-slate-600">
          {ios ? (
            <>
              Tap <Share className="inline h-3.5 w-3.5" aria-hidden /> Share, then &quot;Add to Home Screen&quot;.
            </>
          ) : (
            "Opens like a normal app, with its own icon and no browser bar."
          )}
        </p>
      </div>
      {event && (
        <button onClick={install} className="btn-primary shrink-0 px-4 py-2 text-sm">
          Install
        </button>
      )}
      <button onClick={dismiss} aria-label="Dismiss" className="shrink-0 rounded-lg p-2 text-slate-600 hover:bg-slate-100">
        <X className="h-4 w-4" aria-hidden />
      </button>
    </div>
  );
}
