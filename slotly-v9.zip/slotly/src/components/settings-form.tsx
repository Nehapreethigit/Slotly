"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { AlertTriangle, CheckCircle2, Loader2 } from "lucide-react";
import { useOrigin } from "@/lib/use-origin";

type Props = {
  email: string;
  initial: { name: string; username: string; bio: string; timezone: string };
  calendar: { connected: boolean; canWrite: boolean; hasRefreshToken: boolean };
};

export function SettingsForm({ email, initial, calendar }: Props) {
  const router = useRouter();
  const { host } = useOrigin();
  const [form, setForm] = useState(initial);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  const timezones = useMemo(() => {
    const all = Intl.supportedValuesOf("timeZone");
    return all.includes(initial.timezone) ? all : [initial.timezone, ...all];
  }, [initial.timezone]);

  const healthy = calendar.connected && calendar.canWrite && calendar.hasRefreshToken;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, bio: form.bio || null }),
    });
    setSaving(false);
    if (res.ok) {
      setMessage({ type: "ok", text: "Saved." });
      router.refresh();
    } else {
      setMessage({ type: "error", text: (await res.json()).error ?? "Could not save" });
    }
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
      <p className="mt-1 text-sm text-slate-500">Your public profile and calendar connection.</p>

      <form onSubmit={save} className="card mt-8 space-y-5 p-6">
        <div>
          <label htmlFor="s-name" className="label">Name</label>
          <input id="s-name" className="input" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>

        <div>
          <label htmlFor="s-username" className="label">Username</label>
          <div className="flex items-center rounded-lg border border-slate-200 bg-surface focus-within:border-brand-500">
            <span className="whitespace-nowrap pl-3 text-sm text-slate-400">
              {host || "slotly"}/
            </span>
            <input
              id="s-username"
              required
              className="w-full rounded-lg bg-transparent px-1.5 py-2.5 text-sm outline-none focus-visible:ring-0"
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "") })}
            />
          </div>
          <p className="mt-1 text-xs text-slate-500">Changing this changes all your booking links.</p>
        </div>

        <div>
          <label htmlFor="s-bio" className="label">Bio</label>
          <textarea
            id="s-bio"
            rows={3}
            maxLength={300}
            className="input resize-none"
            placeholder="A line or two shown on your booking page"
            value={form.bio}
            onChange={(e) => setForm({ ...form, bio: e.target.value })}
          />
        </div>

        <div>
          <label htmlFor="s-tz" className="label">Timezone</label>
          <select id="s-tz" className="input" value={form.timezone} onChange={(e) => setForm({ ...form, timezone: e.target.value })}>
            {timezones.map((tz) => (
              <option key={tz} value={tz}>
                {tz.replace(/_/g, " ")}
              </option>
            ))}
          </select>
          <p className="mt-1 text-xs text-slate-500">Your availability hours are interpreted in this timezone.</p>
        </div>

        <div className="flex items-center gap-3 pt-1">
          <button type="submit" disabled={saving} className="btn-primary">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            Save changes
          </button>
          {message && (
            <span className={message.type === "ok" ? "text-sm text-emerald-400" : "text-sm text-red-400"}>{message.text}</span>
          )}
        </div>
      </form>

      <div className="card mt-6 p-6">
        <h2 className="font-semibold">Google Calendar</h2>
        <div
          className={
            healthy
              ? "mt-3 flex items-start gap-3 rounded-xl bg-emerald-400/10 p-4 text-sm text-emerald-200"
              : "mt-3 flex items-start gap-3 rounded-xl bg-amber-400/10 p-4 text-sm text-amber-200"
          }
        >
          {healthy ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" /> : <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />}
          <p>
            {healthy ? (
              <>
                Connected as <strong>{email}</strong>. Slotly checks your busy times and creates events with Google Meet links.
              </>
            ) : (
              <>
                Calendar access is incomplete. Reconnect and tick every permission box on Google&apos;s consent screen so Slotly can
                check your busy times and create events.
              </>
            )}
          </p>
        </div>
        <button onClick={() => signIn("google", { callbackUrl: "/dashboard/settings" })} className="btn-secondary mt-4">
          {healthy ? "Reconnect Google" : "Connect Google Calendar"}
        </button>
      </div>
    </div>
  );
}
