"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { ArrowLeft, Loader2 } from "lucide-react";
import { SignInButton } from "@/components/sign-in-button";

type Step = "email" | "password" | "create" | "google-only";

/** POST JSON with a time limit, so a stuck server shows an error instead of an endless spinner. */
async function post(url: string, body: unknown, timeoutMs = 20_000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal });
    const data = await res.json().catch(() => ({}) as Record<string, string>);
    return { res, data };
  } finally {
    clearTimeout(timer);
  }
}

function networkMessage(err: unknown) {
  const name = (err as { name?: string })?.name;
  return name === "AbortError" || name === "TimeoutError"
    ? "This is taking too long. The server may still be starting up, so wait a few seconds and try again."
    : "Could not reach the server. Check your connection and try again.";
}

/** Two steps like Google: first the email, then either "enter your password" or "create your account". */
export function AuthForm({ google, canReset }: { google: boolean; canReset: boolean }) {
  const router = useRouter();
  const [step, setStep] = useState<Step>("email");
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function next(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { res, data } = await post("/api/auth-lookup", { email });
      if (!res.ok) return setError(data.error ?? "Something went wrong. Try again.");
      setFirstName(data.name ?? null);
      setPassword("");
      setStep(!data.exists ? "create" : data.hasPassword ? "password" : "google-only");
    } catch (err) {
      setError(networkMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function finish(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (step === "create") {
        const { res, data } = await post("/api/signup", { name, email, password }, 30_000);
        if (!res.ok) return setError(data.error ?? "Could not create your account. Please try again.");
      }

      // signIn can hang if the server is slow, so it gets the same time limit as everything else.
      const result = await Promise.race([
        signIn("credentials", { email, password, redirect: false }),
        new Promise<never>((_, reject) => setTimeout(() => reject(new DOMException("timeout", "TimeoutError")), 30_000)),
      ]);
      if (result?.error) return setError(result.error === "CredentialsSignin" ? "Wrong password. Try again." : result.error);
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setError(networkMessage(err));
    } finally {
      setBusy(false);
    }
  }

  function back() {
    setStep("email");
    setError(null);
    setPassword("");
  }

  const heading = {
    email: ["Log in or sign up", "Enter your email to continue."],
    password: [firstName ? `Welcome back, ${firstName}` : "Welcome back", "Enter your password to log in."],
    create: ["Create your account", "New here. Add your name and a password to get your booking link."],
    "google-only": ["Use Google to continue", "This account was created with Google, so it has no password."],
  }[step];

  return (
    <div className="card w-full max-w-md p-7 sm:p-8">
      <h1 className="text-2xl font-bold">{heading[0]}</h1>
      <p className="mt-1 text-sm text-slate-500">{heading[1]}</p>

      {step !== "email" && (
        <button
          type="button"
          onClick={back}
          className="mt-5 inline-flex max-w-full items-center gap-2 rounded-full border border-slate-200 px-3 py-1.5 text-sm text-slate-700 hover:border-slate-400"
        >
          <ArrowLeft className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">{email}</span>
        </button>
      )}

      {step === "email" && (
        <form onSubmit={next} className="mt-6 space-y-4">
          <div>
            <label className="label" htmlFor="email">Email</label>
            <input id="email" type="email" required autoFocus autoComplete="username" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          {error && <p role="alert" className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} Next
          </button>
        </form>
      )}

      {(step === "password" || step === "create") && (
        <form onSubmit={finish} className="mt-6 space-y-4">
          {step === "create" && (
            <div>
              <label className="label" htmlFor="name">Your name</label>
              <input id="name" required autoFocus autoComplete="name" className="input" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
          )}
          <div>
            <label className="label" htmlFor="password">{step === "create" ? "Choose a password" : "Password"}</label>
            <input
              id="password"
              type="password"
              required
              autoFocus={step === "password"}
              minLength={step === "create" ? 8 : undefined}
              autoComplete={step === "create" ? "new-password" : "current-password"}
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {step === "create" && <p className="mt-1 text-xs text-slate-500">At least 8 characters.</p>}
            {step === "password" && canReset && (
              <p className="mt-2 text-sm">
                <Link href={`/forgot-password?email=${encodeURIComponent(email)}`} className="text-brand-300 underline">Forgot password?</Link>
              </p>
            )}
          </div>
          {error && <p role="alert" className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} {step === "create" ? "Create account" : "Log in"}
          </button>
        </form>
      )}

      {step === "google-only" && (
        <div className="mt-6">
          {google ? (
            <SignInButton className="w-full" />
          ) : (
            <p className="rounded-lg bg-slot-100 px-3 py-2 text-sm text-slate-700">Google sign-in is not turned on for this site yet.</p>
          )}
        </div>
      )}

      {step === "email" && google && (
        <>
          <div className="my-6 flex items-center gap-3 text-xs uppercase tracking-wide text-slate-400">
            <span className="h-px flex-1 bg-slate-200" /> or <span className="h-px flex-1 bg-slate-200" />
          </div>
          <div className="flex flex-col gap-3">
            <SignInButton className="w-full" />
          </div>
        </>
      )}
    </div>
  );
}
