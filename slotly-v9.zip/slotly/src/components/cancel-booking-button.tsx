"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, X } from "lucide-react";
import { useFeedback } from "@/components/ui/feedback";

export function CancelBookingButton({ uid, compact = false }: { uid: string; compact?: boolean }) {
  const router = useRouter();
  const { toast, confirm } = useFeedback();
  const [loading, setLoading] = useState(false);

  async function cancel() {
    const ok = await confirm({
      title: "Cancel this booking?",
      body: "The calendar event is removed and the other person is notified. This can't be undone.",
      confirmLabel: "Cancel booking",
      tone: "danger",
    });
    if (!ok) return;

    setLoading(true);
    const res = await fetch(`/api/bookings/${uid}`, { method: "DELETE" });
    setLoading(false);
    if (res.ok) {
      toast("Booking cancelled");
      router.refresh();
    } else {
      toast("Couldn't cancel the booking. Check your connection and try again.", "error");
    }
  }

  return (
    <button onClick={cancel} disabled={loading} className={compact ? "btn-danger !px-3 !py-2" : "btn-danger"}>
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <X className="h-4 w-4" />}
      Cancel booking
    </button>
  );
}
