"use client";

import { useEffect, useState } from "react";

/**
 * Shows an instant in the VIEWER's own timezone and locale.
 *
 * The server cannot know the viewer's timezone, so formatting during render gives the server and the
 * browser different text, and React reports a hydration error (#425). Formatting in an effect means the
 * first render is identical on both sides and the local time appears right after.
 */
export function LocalTime({ iso, className }: { iso: string; className?: string }) {
  const [text, setText] = useState<string | null>(null);

  useEffect(() => {
    setText(
      new Date(iso).toLocaleString(undefined, {
        day: "numeric",
        month: "short",
        hour: "numeric",
        minute: "2-digit",
      }),
    );
  }, [iso]);

  return (
    <time dateTime={iso} className={className}>
      {text ?? " "}
    </time>
  );
}
