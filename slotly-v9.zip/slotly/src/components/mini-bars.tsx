/** Tiny dependency-free bar chart. Server-renderable SVG; the last bar (today) is highlighted. */
export function MiniBars({ values, labels, height = 72 }: { values: number[]; labels?: string[]; height?: number }) {
  const max = Math.max(1, ...values);
  const gap = 3;
  const barW = 100 / values.length;
  const summary = `Bookings per day over the last ${values.length} days, ${values.reduce((a, b) => a + b, 0)} in total`;

  return (
    <svg viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" role="img" aria-label={summary} className="w-full" style={{ height }}>
      {values.map((v, i) => {
        const h = v === 0 ? 2 : Math.max(4, (v / max) * (height - 4));
        const isLast = i === values.length - 1;
        return (
          <rect
            key={i}
            x={i * barW + gap / 6}
            y={height - h}
            width={barW - gap / 3}
            height={h}
            rx={0.6}
            className={isLast ? "fill-slot-300 [filter:drop-shadow(0_0_3px_rgba(34,211,238,0.9))]" : v === 0 ? "fill-slate-200" : "fill-brand-500/70"}
          >
            {labels?.[i] && <title>{`${labels[i]}: ${v}`}</title>}
          </rect>
        );
      })}
    </svg>
  );
}
