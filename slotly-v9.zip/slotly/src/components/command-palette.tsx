"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { signOut } from "next-auth/react";
import { BarChart3, CalendarClock, CornerDownLeft, ExternalLink, Home, LayoutGrid, Link2, LogOut, Plug, Search, Settings, Timer } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useFeedback } from "@/components/ui/feedback";
import { useOrigin } from "@/lib/use-origin";
import { cn } from "@/lib/utils";

const OPEN_EVENT = "slotly:palette";

type Item = { id: string; label: string; hint: string; icon: LucideIcon; keywords?: string; run: () => void };

/** Ctrl/Cmd+K jump menu: go to any page, copy your booking link, sign out. */
export function CommandPalette({ username }: { username: string | null }) {
  const router = useRouter();
  const { toast } = useFeedback();
  const { origin } = useOrigin();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const returnFocus = useRef<HTMLElement | null>(null);

  const close = useCallback(() => {
    setOpen(false);
    setQuery("");
    setActive(0);
    returnFocus.current?.focus();
  }, []);

  const items = useMemo<Item[]>(() => {
    const go = (href: string) => () => router.push(href);
    const list: Item[] = [
      { id: "overview", label: "Overview", hint: "Go to", icon: Home, keywords: "home dashboard stats", run: go("/dashboard") },
      { id: "types", label: "Event types", hint: "Go to", icon: LayoutGrid, keywords: "meetings questions", run: go("/dashboard/event-types") },
      { id: "avail", label: "Availability", hint: "Go to", icon: Timer, keywords: "hours schedule days off", run: go("/dashboard/availability") },
      { id: "bookings", label: "Bookings", hint: "Go to", icon: CalendarClock, keywords: "upcoming past cancelled", run: go("/dashboard/bookings") },
      { id: "insights", label: "Insights", hint: "Go to", icon: BarChart3, keywords: "analytics heatmap", run: go("/dashboard/insights") },
      { id: "integrations", label: "Integrations", hint: "Go to", icon: Plug, keywords: "webhooks email", run: go("/dashboard/integrations") },
      { id: "settings", label: "Settings", hint: "Go to", icon: Settings, keywords: "profile username timezone google", run: go("/dashboard/settings") },
    ];
    if (username) {
      list.push(
        {
          id: "copy",
          label: "Copy your booking link",
          hint: "Action",
          icon: Link2,
          keywords: "share url",
          run: () => {
            navigator.clipboard?.writeText(`${origin}/${username}`).then(
              () => toast("Booking link copied"),
              () => toast("Could not copy. Copy it from the top of Overview."),
            );
          },
        },
        { id: "public", label: "Open your public page", hint: "Action", icon: ExternalLink, keywords: "preview", run: () => window.open(`/${username}`, "_blank") },
      );
    }
    list.push({ id: "signout", label: "Sign out", hint: "Action", icon: LogOut, keywords: "log out", run: () => signOut({ callbackUrl: "/" }) });
    return list;
  }, [router, username, origin, toast]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? items.filter((i) => `${i.label} ${i.keywords ?? ""}`.toLowerCase().includes(q)) : items;
  }, [items, query]);

  const run = (item: Item | undefined) => {
    if (!item) return;
    close();
    item.run();
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((o) => {
          if (!o) returnFocus.current = document.activeElement as HTMLElement | null;
          return !o;
        });
      }
    };
    const onOpen = () => {
      returnFocus.current = document.activeElement as HTMLElement | null;
      setOpen(true);
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener(OPEN_EVENT, onOpen);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener(OPEN_EVENT, onOpen);
    };
  }, []);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => setActive(0), [query]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center bg-black/60 px-4 pt-[15vh] backdrop-blur-sm" onMouseDown={close}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Jump to"
        className="card w-full max-w-lg overflow-hidden shadow-pop"
        onMouseDown={(e) => e.stopPropagation()}
        onKeyDown={(e) => {
          if (e.key === "Escape") return close();
          if (e.key === "ArrowDown") (e.preventDefault(), setActive((a) => Math.min(a + 1, shown.length - 1)));
          if (e.key === "ArrowUp") (e.preventDefault(), setActive((a) => Math.max(a - 1, 0)));
          if (e.key === "Enter") (e.preventDefault(), run(shown[active]));
        }}
      >
        <div className="flex items-center gap-3 border-b border-slate-100 px-4">
          <Search className="h-4 w-4 shrink-0 text-slate-400" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Jump to a page or action..."
            className="w-full bg-transparent py-4 text-sm outline-none placeholder:text-slate-400"
            role="combobox"
            aria-expanded="true"
            aria-controls="palette-list"
            aria-activedescendant={shown[active] ? `palette-${shown[active].id}` : undefined}
          />
          <kbd className="rounded border border-slate-200 px-1.5 py-0.5 text-[10px] font-semibold text-slate-400">ESC</kbd>
        </div>

        <ul id="palette-list" role="listbox" className="max-h-80 overflow-y-auto p-2">
          {shown.length === 0 && <li className="px-3 py-8 text-center text-sm text-slate-500">Nothing matches &ldquo;{query}&rdquo;</li>}
          {shown.map((item, i) => (
            <li
              key={item.id}
              id={`palette-${item.id}`}
              role="option"
              aria-selected={i === active}
              onMouseMove={() => setActive(i)}
              onClick={() => run(item)}
              className={cn("flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5 text-sm", i === active ? "bg-slate-100" : "")}
            >
              <item.icon className="h-4 w-4 text-slate-500" />
              <span className="flex-1 font-medium">{item.label}</span>
              <span className="text-xs text-slate-400">{item.hint}</span>
              {i === active && <CornerDownLeft className="h-3.5 w-3.5 text-slate-400" />}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/** The "Search" button in the sidebar. It only fires an event, so it needs no props. */
export function CommandPaletteTrigger({ className }: { className?: string }) {
  const [mac, setMac] = useState(false);
  useEffect(() => setMac(/mac|iphone|ipad/i.test(navigator.platform)), []);
  return (
    <button
      type="button"
      onClick={() => window.dispatchEvent(new Event(OPEN_EVENT))}
      className={cn(
        "flex w-full items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-500 transition hover:border-slate-300 hover:bg-surface",
        className,
      )}
    >
      <Search className="h-4 w-4" />
      <span className="flex-1 text-left">Jump to...</span>
      <kbd className="rounded border border-slate-200 bg-surface px-1.5 py-0.5 text-[10px] font-semibold text-slate-400">{mac ? "⌘ K" : "Ctrl K"}</kbd>
    </button>
  );
}
