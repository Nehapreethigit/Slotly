"use client";

import { useState } from "react";
import { BarChart3, Table2 } from "lucide-react";
import type { Insights } from "@/lib/insights";
import { WEEKDAYS, WEEKDAY_ORDER } from "@/lib/constants";
import { cn } from "@/lib/utils";

// One hue (cobalt), light -> dark, for magnitude. Zero stays neutral.
const RAMP = ["#1D1A45", "#3A2D8C", "#6A4BF2", "#B15BF5", "#F472B6"];
const BAR = "#8B6CFF";

function hourLabel(h: number) {
  const suffix = h >= 12 ? "pm" : "am";
  return `${h % 12 === 0 ? 12 : h % 12}${suffix}`;
}

function Stat({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return (
    <div className="card p-5">
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <p className="mt-1.5 text-3xl font-bold tracking-tight tabular-nums">{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
    </div>
  );
}

function PerDayChart({ data }: { data: Insights["perDay"] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.count));
  const W = 640;
  const H = 170;
  const padL = 28;
  const padB = 22;
  const plotW = W - padL;
  const plotH = H - padB - 8;
  const slot = plotW / data.length;
  const barW = Math.max(4, slot - 6);
  const fmt = (iso: string) => new Date(`${iso}T00:00:00Z`).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" });

  const active = hover !== null ? data[hover] : null;
  const total = data.reduce((a, d) => a + d.count, 0);

  return (
    <div>
      <p className="h-5 text-sm text-slate-600" aria-live="polite">
        {active ? (
          <>
            <strong className="font-semibold text-slate-900">{fmt(active.date)}</strong>: {active.count} {active.count === 1 ? "booking" : "bookings"}
          </>
        ) : (
          `${total} ${total === 1 ? "booking" : "bookings"} in the last ${data.length} days`
        )}
      </p>
      <div className="overflow-x-auto">
      <svg viewBox={`0 0 ${W} ${H}`} className="mt-2 w-full min-w-[560px]" role="img" aria-label={`Bookings per day for the last ${data.length} days. ${total} in total.`}>
        {[0, max].map((v) => {
          const y = 8 + plotH - (v / max) * plotH;
          return (
            <g key={v}>
              <line x1={padL} x2={W} y1={y} y2={y} stroke="#262647" strokeWidth={1} />
              <text x={padL - 6} y={y + 4} textAnchor="end" fontSize={11} fill="#9193BD">
                {v}
              </text>
            </g>
          );
        })}
        {data.map((d, i) => {
          const h = (d.count / max) * plotH;
          const x = padL + i * slot + (slot - barW) / 2;
          const y = 8 + plotH - h;
          return (
            <g key={d.date} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              {/* full-height hit target, bigger than the mark */}
              <rect x={padL + i * slot} y={0} width={slot} height={H - padB} fill="transparent" />
              {d.count > 0 && <rect x={x} y={y} width={barW} height={h} rx={3} fill={BAR} opacity={hover === null || hover === i ? 1 : 0.45} />}
              {d.count === 0 && <rect x={x} y={8 + plotH - 2} width={barW} height={2} fill="#34345C" />}
            </g>
          );
        })}
        {[0, Math.floor(data.length / 2), data.length - 1].map((i) => (
          <text key={i} x={padL + i * slot + slot / 2} y={H - 5} textAnchor={i === 0 ? "start" : i === data.length - 1 ? "end" : "middle"} fontSize={11} fill="#636B60">
            {new Date(`${data[i].date}T00:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" })}
          </text>
        ))}
      </svg>
      </div>
    </div>
  );
}

function Heatmap({ insights }: { insights: Insights }) {
  const { heatmap, heatmapMax } = insights;
  // Show business-ish hours by default, widen if there is data outside them.
  let from = 8;
  let to = 19;
  heatmap.forEach((row) =>
    row.forEach((c, h) => {
      if (c > 0) {
        from = Math.min(from, h);
        to = Math.max(to, h);
      }
    }),
  );
  const hours = Array.from({ length: to - from + 1 }, (_, i) => from + i);
  const step = (c: number) => (c === 0 ? -1 : Math.min(4, Math.ceil((c / Math.max(1, heatmapMax)) * 4)));

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[520px] border-separate text-xs" style={{ borderSpacing: 2 }}>
        <thead>
          <tr>
            <th className="w-10"><span className="sr-only">Day</span></th>
            {hours.map((h) => (
              <th key={h} className="pb-1 text-center font-medium text-slate-500">
                {hourLabel(h)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {WEEKDAY_ORDER.map((wd) => (
            <tr key={wd}>
              <th className="pr-2 text-left font-medium text-slate-500">{WEEKDAYS[wd].slice(0, 3)}</th>
              {hours.map((h) => {
                const c = heatmap[wd][h];
                const s = step(c);
                return (
                  <td
                    key={h}
                    title={`${WEEKDAYS[wd]} ${hourLabel(h)}: ${c} ${c === 1 ? "booking" : "bookings"}`}
                    className="h-8 rounded-md text-center font-semibold tabular-nums"
                    style={{ background: s < 0 ? "#14142A" : RAMP[s], color: s >= 3 ? "#fff" : "#C9CBE8" }}
                  >
                    {c > 0 ? c : ""}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function InsightsView({ insights, timezone }: { insights: Insights; timezone: string }) {
  const [asTable, setAsTable] = useState(false);
  const maxType = Math.max(1, ...insights.byEventType.map((t) => t.count));
  const empty = insights.totalConfirmed + insights.cancelled === 0;
  const tied = insights.heatmap.flat().filter((c) => c === insights.heatmapMax && c > 0).length;

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Insights</h1>
          <p className="mt-1 text-sm text-slate-500">
            How people book you. Times are in <strong className="font-medium text-slate-700">{timezone}</strong>.
          </p>
        </div>
        <button onClick={() => setAsTable((v) => !v)} className="btn-secondary" aria-pressed={asTable}>
          {asTable ? <BarChart3 className="h-4 w-4" /> : <Table2 className="h-4 w-4" />}
          {asTable ? "Show charts" : "Show as table"}
        </button>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="Upcoming" value={insights.upcoming} hint="confirmed, still to happen" />
        <Stat label="This month" value={insights.thisMonth} />
        <Stat label="All time" value={insights.totalConfirmed} hint="confirmed bookings" />
        <Stat label="Cancellation rate" value={`${Math.round(insights.cancellationRate * 100)}%`} hint={`${insights.cancelled} cancelled`} />
      </div>

      {empty ? (
        <div className="card mt-6 px-6 py-14 text-center">
          <p className="font-semibold">No data yet</p>
          <p className="mt-1 text-sm text-slate-500">Charts appear here after your first booking.</p>
        </div>
      ) : asTable ? (
        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="card overflow-hidden">
            <h2 className="border-b border-slate-100 px-5 py-3 text-sm font-semibold">Bookings per day (last 30)</h2>
            <table className="w-full text-sm">
              <tbody>
                {[...insights.perDay].reverse().map((d) => (
                  <tr key={d.date} className="border-b border-slate-50 last:border-0">
                    <td className="px-5 py-1.5 text-slate-600">{d.date}</td>
                    <td className="px-5 py-1.5 text-right tabular-nums">{d.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="card overflow-hidden self-start">
            <h2 className="border-b border-slate-100 px-5 py-3 text-sm font-semibold">By event type</h2>
            <table className="w-full text-sm">
              <tbody>
                {insights.byEventType.map((t) => (
                  <tr key={t.id} className="border-b border-slate-50 last:border-0">
                    <td className="px-5 py-1.5">{t.title}</td>
                    <td className="px-5 py-1.5 text-right tabular-nums">{t.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="mt-6 space-y-6">
          <section className="card p-5 sm:p-6">
            <h2 className="font-semibold">Bookings per day</h2>
            <div className="mt-3">
              <PerDayChart data={insights.perDay} />
            </div>
          </section>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1.6fr_1fr]">
            <section className="card min-w-0 p-5 sm:p-6">
              <h2 className="font-semibold">Busiest times</h2>
              <p className="mt-0.5 text-sm text-slate-500">
                {insights.busiest
                  ? tied > 1
                    ? `${tied} slots tie for busiest, with ${insights.busiest.count} bookings each (darkest cells).`
                    : `${WEEKDAYS[insights.busiest.weekday]}s around ${hourLabel(insights.busiest.hour)} are your busiest slot (${insights.busiest.count} bookings).`
                  : "Confirmed bookings by weekday and start hour."}
              </p>
              <div className="mt-4">
                <Heatmap insights={insights} />
              </div>
            </section>

            <section className="card self-start p-5 sm:p-6">
              <h2 className="font-semibold">By event type</h2>
              <ul className="mt-4 space-y-3">
                {insights.byEventType.map((t) => (
                  <li key={t.id}>
                    <div className="flex items-baseline justify-between gap-3 text-sm">
                      <span className="truncate">{t.title}</span>
                      <span className="font-semibold tabular-nums">{t.count}</span>
                    </div>
                    <div className="mt-1 h-2 rounded-full bg-slate-100">
                      <div className={cn("h-2 rounded-full")} style={{ width: `${(t.count / maxType) * 100}%`, background: BAR }} />
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </div>
      )}
    </div>
  );
}
