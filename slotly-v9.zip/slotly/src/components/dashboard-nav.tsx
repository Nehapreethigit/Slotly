"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { BarChart3, CalendarClock, ExternalLink, Home, LayoutGrid, LogOut, Plug, Settings, Timer } from "lucide-react";
import { Logo } from "@/components/logo";
import { CommandPalette, CommandPaletteTrigger } from "@/components/command-palette";
import { cn, initials } from "@/lib/utils";

const links = [
  { href: "/dashboard", label: "Overview", icon: Home },
  { href: "/dashboard/event-types", label: "Event types", icon: LayoutGrid },
  { href: "/dashboard/availability", label: "Availability", icon: Timer },
  { href: "/dashboard/bookings", label: "Bookings", icon: CalendarClock },
  { href: "/dashboard/insights", label: "Insights", icon: BarChart3 },
  { href: "/dashboard/integrations", label: "Integrations", icon: Plug },
  { href: "/dashboard/settings", label: "Settings", icon: Settings },
];

type Props = { name: string | null; email: string; image: string | null; username: string | null };

export function DashboardNav({ name, email, image, username }: Props) {
  const pathname = usePathname();
  const isActive = (href: string) => (href === "/dashboard" ? pathname === href : pathname.startsWith(href));

  return (
    <>
      <CommandPalette username={username} />
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-64 flex-col border-r border-slate-200 bg-surface lg:flex">
        <Link href="/dashboard" className="px-5 py-5" aria-label="Slotly dashboard">
          <Logo />
        </Link>

        <div className="px-3 pb-3">
          <CommandPaletteTrigger />
        </div>

        <nav className="flex-1 space-y-0.5 px-3" aria-label="Main">
          {links.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              aria-current={isActive(href) ? "page" : undefined}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition",
                isActive(href)
                  ? "bg-brand-600/20 text-slate-900 shadow-[0_0_20px_-8px_rgba(138,92,255,0.9)] ring-1 ring-inset ring-brand-600/50"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
              )}
            >
              <Icon className="h-[18px] w-[18px]" />
              {label}
            </Link>
          ))}
          {username && (
            <Link
              href={`/${username}`}
              target="_blank"
              className="mt-3 flex items-center gap-3 rounded-lg border border-dashed border-slate-300 px-3 py-2.5 text-sm font-semibold text-slate-600 transition hover:border-slate-900 hover:text-slate-900"
            >
              <ExternalLink className="h-[18px] w-[18px]" />
              View your public page
            </Link>
          )}
        </nav>

        <div className="border-t border-slate-200 p-3">
          <div className="flex items-center gap-3 rounded-lg px-2 py-2">
            {image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={image} alt="" className="h-9 w-9 rounded-full" referrerPolicy="no-referrer" />
            ) : (
              <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-brand-600 to-[#C04BFF] text-sm font-bold text-white">{initials(name)}</span>
            )}
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{name ?? "You"}</p>
              <p className="truncate text-xs text-slate-500">{email}</p>
            </div>
            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="rounded-md p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              aria-label="Sign out"
              title="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-slate-50/80 backdrop-blur lg:hidden">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/dashboard" aria-label="Slotly dashboard">
            <Logo className="text-lg [&>svg]:h-7 [&>svg]:w-7" />
          </Link>
          <button onClick={() => signOut({ callbackUrl: "/" })} className="rounded-md p-2 text-slate-500 hover:bg-slate-100" aria-label="Sign out">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-2.5" aria-label="Main">
          {links.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              aria-current={isActive(href) ? "page" : undefined}
              className={cn(
                "whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-semibold",
                isActive(href) ? "bg-brand-600/25 text-slate-900 ring-1 ring-inset ring-brand-600/50" : "text-slate-600 hover:bg-slate-100",
              )}
            >
              {label}
            </Link>
          ))}
        </nav>
      </header>
    </>
  );
}
