"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

// On first visit, store the browser's timezone as the host's timezone (they can change it in Settings).
export function TimezoneSync({ needsSync }: { needsSync: boolean }) {
  const router = useRouter();

  useEffect(() => {
    if (!needsSync) return;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ timezone }),
    }).then((res) => res.ok && router.refresh());
  }, [needsSync, router]);

  return null;
}
