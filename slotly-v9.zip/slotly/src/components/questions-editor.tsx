"use client";

import { ArrowDown, ArrowUp, Plus, Trash2 } from "lucide-react";
import { MAX_QUESTIONS, newQuestionId, type Question, type QuestionType } from "@/lib/questions";

const TYPE_LABELS: Record<QuestionType, string> = { text: "Short answer", textarea: "Long answer", select: "Dropdown" };

/** The host's list of extra questions shown on the booking form. Controlled: the parent owns the array. */
export function QuestionsEditor({ value, onChange }: { value: Question[]; onChange: (next: Question[]) => void }) {
  const update = (i: number, patch: Partial<Question>) => onChange(value.map((q, idx) => (idx === i ? { ...q, ...patch } : q)));
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= value.length) return;
    const next = [...value];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  return (
    <div>
      <div className="flex items-end justify-between gap-3">
        <div>
          <label className="label !mb-0">Booking questions</label>
          <p className="mt-0.5 text-xs text-slate-500">Extra fields guests fill in. Answers show up in your bookings, emails and webhooks.</p>
        </div>
      </div>

      <ul className="mt-3 space-y-3">
        {value.map((q, i) => (
          <li key={q.id} className="rounded-xl border border-slate-200 bg-slate-50/60 p-3">
            <div className="flex gap-2">
              <input
                className="input"
                placeholder="e.g. What would you like to cover?"
                value={q.label}
                maxLength={120}
                onChange={(e) => update(i, { label: e.target.value })}
                aria-label={`Question ${i + 1}`}
              />
              <button type="button" onClick={() => move(i, -1)} disabled={i === 0} className="btn-ghost !px-2" aria-label="Move up">
                <ArrowUp className="h-4 w-4" />
              </button>
              <button type="button" onClick={() => move(i, 1)} disabled={i === value.length - 1} className="btn-ghost !px-2" aria-label="Move down">
                <ArrowDown className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => onChange(value.filter((_, idx) => idx !== i))}
                className="btn-ghost !px-2 hover:!bg-red-500/100/10 hover:!text-red-400"
                aria-label="Remove question"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-3">
              <select
                className="input !w-auto !py-1.5"
                value={q.type}
                onChange={(e) => update(i, { type: e.target.value as QuestionType, options: e.target.value === "select" ? (q.options?.length ? q.options : ["", ""]) : undefined })}
                aria-label="Answer type"
              >
                {(Object.keys(TYPE_LABELS) as QuestionType[]).map((t) => (
                  <option key={t} value={t}>
                    {TYPE_LABELS[t]}
                  </option>
                ))}
              </select>
              <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-700">
                <input type="checkbox" className="h-4 w-4 accent-brand-600" checked={q.required} onChange={(e) => update(i, { required: e.target.checked })} />
                Required
              </label>
            </div>

            {q.type === "select" && (
              <div className="mt-2">
                <textarea
                  rows={3}
                  className="input resize-none"
                  placeholder={"One option per line\nStartup\nEnterprise"}
                  value={(q.options ?? []).join("\n")}
                  onChange={(e) => update(i, { options: e.target.value.split("\n").slice(0, 20) })}
                  aria-label="Dropdown options"
                />
              </div>
            )}
          </li>
        ))}
      </ul>

      <button
        type="button"
        disabled={value.length >= MAX_QUESTIONS}
        onClick={() => onChange([...value, { id: newQuestionId(), label: "", type: "text", required: false }])}
        className="btn-secondary mt-3 !py-2"
      >
        <Plus className="h-4 w-4" /> Add a question
      </button>
    </div>
  );
}
