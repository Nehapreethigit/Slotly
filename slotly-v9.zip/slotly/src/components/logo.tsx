import { cn } from "@/lib/utils";

/** Three stacked time blocks; the highlighted middle one is the open slot. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("h-8 w-8", className)} aria-hidden>
      <defs>
        <linearGradient id="slotly-g" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7A56FF" />
          <stop offset="1" stopColor="#C04BFF" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="8" fill="url(#slotly-g)" />
      <rect x="8" y="8" width="10" height="4" rx="2" fill="#fff" opacity=".55" />
      <rect x="8" y="14" width="16" height="5" rx="2.5" fill="#22D3EE" />
      <rect x="8" y="21" width="12" height="4" rx="2" fill="#fff" opacity=".55" />
    </svg>
  );
}

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5 font-display text-xl font-bold tracking-tight", className)}>
      <LogoMark />
      Slotly
    </span>
  );
}
