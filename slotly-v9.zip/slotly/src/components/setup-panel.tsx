"use client";

import { useState } from "react";
import Link from "next/link";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFeedback } from "@/components/ui/feedback";
import { useOrigin } from "@/lib/use-origin";

export type SetupState = { googleConnected: boolean; hasAvailability: boolean; hasBooking: boolean };

/**
 * Top of the dashboard: the host's public link with a copy button, and, until they are done,
 * the three things that make the link actually work.
 */
export function SetupPanel({ username, setup }: { username: string; setup: SetupState }) {
  const { toast } = useFeedback();
  const { origin, host } = useOrigin();
  const [copied, setCopied] = useState(false);

  const steps = [
    {
      done: setup.googleConnected,
      title: "Connect Google Calendar (optional)",
      body: "So busy times are hidden and bookings land on your calendar with a Meet link.",
      href: "/dashboard/settings",
      cta: "Open settings",
    },
    {
      done: setup.hasAvailability,
      title: "Set your weekly hours",
      body: "Choose the days and times people can book you.",
      href: "/dashboard/availability",
      cta: "Set hours",
    },
    {
      done: setup.hasBooking,
      title: "Get your first booking",
      body: "Open your page in a private window and book yourself as a test.",
      href: `/${username}`,
      cta: "Open your page",
    },
  ];
  const remaining = steps.filter((s) => !s.done).length;

  async function copy() {
    const url = `${origin}/${username}`;
    await navigator.clipboard.writeText(url);
    setCopied(true);
    toast("Your booking page link is copied");
    setTimeout(() => setCopied(false), 1600);
  }

  return (
    <section aria-label="Your booking page" className="mb-10">
      <div className="flex flex-col gap-3 rounded-2xl border border-brand-600/40 bg-gradient-to-br from-[#1B1450] via-[#2A1466] to-[#0E3A55] p-5 text-white shadow-glow sm:flex-row sm:items-center sm:justify-between sm:p-6">
        <div className="min-w-0">
          <p className="text-sm text-white/70">Your booking page</p>
          <p className="mt-1 truncate font-display text-xl font-bold sm:text-2xl">
            {host || "slotly"}/{username}
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <button onClick={copy} className="btn bg-slot-300 text-[#07070F] hover:bg-slot-200">
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copied" : "Copy link"}
          </button>
          <Link href={`/${username}`} target="_blank" className="btn border border-white/30 text-white hover:bg-white/10">
            Open
          </Link>
        </div>
      </div>

      {remaining > 0 && (
        <div className="card mt-4 overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5">
            <h2 className="text-base font-bold">Finish setting up</h2>
            <span className="text-sm text-slate-500">
              {steps.length - remaining} of {steps.length} done
            </span>
          </div>
          <ul className="divide-y divide-slate-100">
            {steps.map((s) => (
              <li key={s.title} className="flex items-start gap-4 px-5 py-4">
                <span
                  className={cn(
                    "mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2",
                    s.done ? "border-brand-600 bg-brand-600 text-white" : "border-slate-300",
                  )}
                >
                  <span className="sr-only">{s.done ? "Done" : "Not done"}</span>
                  {s.done && <Check className="h-3.5 w-3.5" strokeWidth={3} aria-hidden />}
                </span>
                <div className="min-w-0 flex-1">
                  <p className={cn("font-semibold", s.done && "text-slate-400 line-through decoration-slate-300")}>{s.title}</p>
                  {!s.done && <p className="mt-0.5 text-sm text-slate-600">{s.body}</p>}
                </div>
                {!s.done && (
                  <Link href={s.href} className="btn-secondary shrink-0 !px-3 !py-1.5">
                    {s.cta}
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
