"use client";

import Link from "next/link";
import { useState } from "react";
import { Loader2 } from "lucide-react";

async function post(url: string, body: unknown) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 20_000);
  try {
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal });
    return { res, data: (await res.json().catch(() => ({}))) as { error?: string } };
  } catch {
    return { res: null, data: { error: "Could not reach the server. Check your connection and try again." } };
  } finally {
    clearTimeout(timer);
  }
}

export function ForgotForm({ enabled, initialEmail = "" }: { enabled: boolean; initialEmail?: string }) {
  const [email, setEmail] = useState(initialEmail);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { res, data } = await post("/api/password/forgot", { email });
    setBusy(false);
    if (res?.ok) setSent(true);
    else setError(data.error ?? "Something went wrong. Please try again.");
  }

  if (!enabled) {
    return <p className="mt-6 rounded-lg bg-amber-500/10 px-3 py-2 text-sm text-amber-300">Password reset by email is not set up on this site yet. Please contact the site owner.</p>;
  }
  if (sent) {
    return (
      <div className="mt-6 space-y-4 text-sm text-slate-700" role="status">
        <p className="rounded-lg bg-slot-100 px-3 py-2">If an account with a password exists for <strong>{email}</strong>, a reset link is on its way. It works for one hour.</p>
        <p>Nothing arrived? Check your spam folder.</p>
      </div>
    );
  }
  return (
    <form onSubmit={submit} className="mt-6 space-y-4">
      <div>
        <label className="label" htmlFor="email">Email</label>
        <input id="email" type="email" required autoFocus autoComplete="username" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      {error && <p role="alert" className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
      <button type="submit" disabled={busy} className="btn-primary w-full">
        {busy && <Loader2 className="h-4 w-4 animate-spin" />} Send reset link
      </button>
    </form>
  );
}

export function ResetForm({ token, email }: { token: string; email: string }) {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { res, data } = await post("/api/password/reset", { token, email, password });
    setBusy(false);
    if (res?.ok) setDone(true);
    else setError(data.error ?? "Something went wrong. Please try again.");
  }

  if (!token || !email) {
    return <p className="mt-6 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">This reset link is incomplete. Open the link from your email again.</p>;
  }
  if (done) {
    return (
      <div className="mt-6 space-y-4 text-sm" role="status">
        <p className="rounded-lg bg-slot-100 px-3 py-2 text-slate-700">Your password was changed.</p>
        <Link href="/login" className="btn-primary w-full">Log in</Link>
      </div>
    );
  }
  return (
    <form onSubmit={submit} className="mt-6 space-y-4">
      <p className="text-sm text-slate-600">Resetting the password for <strong>{email}</strong>.</p>
      <div>
        <label className="label" htmlFor="new-password">New password</label>
        <input id="new-password" type="password" required minLength={8} maxLength={72} autoFocus autoComplete="new-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} />
        <p className="mt-1 text-xs text-slate-500">At least 8 characters.</p>
      </div>
      {error && <p role="alert" className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
      <button type="submit" disabled={busy} className="btn-primary w-full">
        {busy && <Loader2 className="h-4 w-4 animate-spin" />} Change password
      </button>
    </form>
  );
}
