export const SITE_NAME = "Slotly";
export const SITE_TAGLINE = "Booking links that check your real calendar";
export const SITE_DESCRIPTION =
  "Share one link. People pick a time that is actually free, in their own timezone, and the meeting lands on both calendars. Free, open source scheduling.";

/** Public origin of the site, used for canonical links, sitemap and social previews. */
export function siteUrl(): string {
  const explicit = process.env.NEXTAUTH_URL ?? process.env.NEXT_PUBLIC_SITE_URL;
  const vercel = process.env.VERCEL_PROJECT_PRODUCTION_URL ?? process.env.VERCEL_URL;
  const raw = explicit || (vercel ? `https://${vercel}` : "http://localhost:3000");
  return raw.replace(/\/$/, "");
}

/** Shown on the privacy and terms pages. Set NEXT_PUBLIC_CONTACT_EMAIL so people can reach you. */
export const CONTACT_EMAIL = process.env.NEXT_PUBLIC_CONTACT_EMAIL ?? "";
