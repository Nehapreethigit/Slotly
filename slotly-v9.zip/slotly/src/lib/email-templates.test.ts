import { describe, expect, it } from "vitest";
import { escapeHtml, renderBookingEmail, type BookingEmailData } from "./email-templates";

const base: BookingEmailData = {
  kind: "confirmed",
  audience: "guest",
  hostName: "Aarav Rao",
  guestName: "Neha",
  title: "30 min meeting",
  start: new Date("2026-10-12T09:00:00Z"),
  end: new Date("2026-10-12T09:30:00Z"),
  timezone: "Asia/Kolkata",
  where: "https://meet.google.com/abc-defg-hij",
  manageUrl: "https://slotly.example/booking/uid-1",
};

describe("escapeHtml", () => {
  it("escapes the dangerous characters", () => {
    expect(escapeHtml(`<script>alert("x")</script> & 'y'`)).toBe("&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt; &amp; &#39;y&#39;");
  });
});

describe("renderBookingEmail", () => {
  it("renders times in the requested timezone", () => {
    const { html, text } = renderBookingEmail(base);
    // 09:00Z = 14:30 IST
    expect(html).toContain("2:30 PM - 3:00 PM");
    expect(text).toContain("Asia/Kolkata");
  });

  it("uses different headlines for guest vs host", () => {
    expect(renderBookingEmail(base).subject).toBe("Confirmed: 30 min meeting with Aarav Rao");
    const host = renderBookingEmail({ ...base, audience: "host" });
    expect(host.subject).toBe("New booking: 30 min meeting with Neha");
    expect(host.html).toContain("New booking from Neha");
  });

  it("cancellation emails have no manage button", () => {
    const { html, subject } = renderBookingEmail({ ...base, kind: "cancelled" });
    expect(subject.startsWith("Cancelled:")).toBe(true);
    expect(html).not.toContain("View, reschedule or cancel");
  });

  it("escapes guest-controlled fields (name, notes) to prevent HTML injection", () => {
    const { html } = renderBookingEmail({
      ...base,
      guestName: '<img src=x onerror="alert(1)">',
      notes: "<b>hi</b>",
      audience: "host",
    });
    expect(html).not.toContain("<img src=x");
    expect(html).not.toContain("<b>hi</b>");
    expect(html).toContain("&lt;b&gt;hi&lt;/b&gt;");
  });
});
