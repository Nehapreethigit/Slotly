import { describe, expect, it } from "vitest";
import { formatInTimeZone } from "date-fns-tz";
import { createRng, DEMO_EMAIL_DOMAIN, generateDemoBookings } from "./demo-data";

const now = new Date("2026-10-08T06:00:00Z");
const weekly = [1, 2, 3, 4, 5].map((weekday) => ({ weekday, startMin: 540, endMin: 1020 })); // Mon-Fri 9-17
const eventTypes = [
  { id: "t15", duration: 15 },
  { id: "t60", duration: 60 },
];
const base = { now, timezone: "Asia/Kolkata", weekly, eventTypes };

describe("createRng", () => {
  it("is deterministic and stays in [0, 1)", () => {
    const a = createRng(7);
    const b = createRng(7);
    for (let i = 0; i < 50; i++) {
      const x = a();
      expect(x).toBe(b());
      expect(x).toBeGreaterThanOrEqual(0);
      expect(x).toBeLessThan(1);
    }
  });

  it("different seeds give different sequences", () => {
    expect(createRng(1)()).not.toBe(createRng(2)());
  });
});

describe("generateDemoBookings", () => {
  it("is deterministic for the same inputs", () => {
    expect(generateDemoBookings(base)).toEqual(generateDemoBookings(base));
  });

  it("returns nothing without event types or hours", () => {
    expect(generateDemoBookings({ ...base, eventTypes: [] })).toEqual([]);
    expect(generateDemoBookings({ ...base, weekly: [] })).toEqual([]);
  });

  it("produces a healthy number of bookings, sorted by time, capped by max", () => {
    const all = generateDemoBookings(base);
    expect(all.length).toBeGreaterThan(25);
    expect(all.length).toBeLessThanOrEqual(70);
    for (let i = 1; i < all.length; i++) expect(all[i].startTime.getTime()).toBeGreaterThanOrEqual(all[i - 1].startTime.getTime());
    expect(generateDemoBookings({ ...base, max: 5 })).toHaveLength(5);
  });

  it("never overlaps two bookings", () => {
    const all = generateDemoBookings(base);
    for (let i = 0; i < all.length; i++)
      for (let j = i + 1; j < all.length; j++) {
        const overlap = all[i].startTime < all[j].endTime && all[i].endTime > all[j].startTime;
        expect(overlap, `${all[i].startTime.toISOString()} vs ${all[j].startTime.toISOString()}`).toBe(false);
      }
  });

  it("keeps every booking inside the host's weekly hours, in the host's timezone", () => {
    for (const b of generateDemoBookings({ ...base, seed: 99 })) {
      const wd = Number(formatInTimeZone(b.startTime, base.timezone, "i")) % 7;
      expect([1, 2, 3, 4, 5]).toContain(wd);
      const startMin = Number(formatInTimeZone(b.startTime, base.timezone, "H")) * 60 + Number(formatInTimeZone(b.startTime, base.timezone, "m"));
      const endMin = startMin + (b.endTime.getTime() - b.startTime.getTime()) / 60_000;
      expect(startMin).toBeGreaterThanOrEqual(540);
      expect(endMin).toBeLessThanOrEqual(1020);
    }
  });

  it("covers both past and upcoming bookings, and some cancellations", () => {
    const all = generateDemoBookings(base);
    expect(all.some((b) => b.startTime < now)).toBe(true);
    expect(all.some((b) => b.startTime >= now)).toBe(true);
    expect(all.some((b) => b.status === "CANCELLED")).toBe(true);
    expect(all.filter((b) => b.status === "CONFIRMED").length).toBeGreaterThan(all.length / 2);
  });

  it("marks every guest with the reserved demo domain so cleanup is exact", () => {
    for (const b of generateDemoBookings(base)) expect(b.attendeeEmail.endsWith(`@${DEMO_EMAIL_DOMAIN}`)).toBe(true);
  });

  it("respects a split-shift day", () => {
    const split = [{ weekday: 3, startMin: 540, endMin: 720 }, { weekday: 3, startMin: 780, endMin: 960 }];
    for (const b of generateDemoBookings({ ...base, weekly: split, seed: 5 })) {
      const m = Number(formatInTimeZone(b.startTime, base.timezone, "H")) * 60 + Number(formatInTimeZone(b.startTime, base.timezone, "m"));
      const end = m + (b.endTime.getTime() - b.startTime.getTime()) / 60_000;
      const inMorning = m >= 540 && end <= 720;
      const inAfternoon = m >= 780 && end <= 960;
      expect(inMorning || inAfternoon).toBe(true);
    }
  });
});
