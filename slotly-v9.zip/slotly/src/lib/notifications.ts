import type { Booking, EventType, User } from "@prisma/client";
import { buildIcs } from "./ics";
import { sendEmail } from "./email";
import { renderBookingEmail } from "./email-templates";
import { locationLabel } from "./constants";
import { dispatchWebhooks } from "./webhooks";
import type { WebhookEvent } from "./webhook-security";
import { parseAnswers } from "./questions";
import { siteUrl } from "./site";

type Ctx = { booking: Booking; eventType: EventType; host: User };

function baseUrl() {
  return siteUrl();
}

function webhookData({ booking, eventType, host }: Ctx) {
  return {
    uid: booking.uid,
    status: booking.status,
    eventType: { title: eventType.title, slug: eventType.slug, duration: eventType.duration },
    host: { name: host.name, email: host.email, timezone: host.timezone },
    start: booking.startTime.toISOString(),
    end: booking.endTime.toISOString(),
    attendee: { name: booking.attendeeName, email: booking.attendeeEmail, timezone: booking.attendeeTimezone },
    notes: booking.notes,
    answers: parseAnswers(booking.answers),
    meetLink: booking.meetLink,
    manageUrl: `${baseUrl()}/booking/${booking.uid}`,
  };
}

async function emails(ctx: Ctx, kind: "confirmed" | "cancelled") {
  const { booking, eventType, host } = ctx;
  const where = booking.meetLink ?? locationLabel(eventType.location, eventType.locationDetail);
  const manageUrl = `${baseUrl()}/booking/${booking.uid}`;
  const answers = parseAnswers(booking.answers);

  const ics = Buffer.from(
    buildIcs({
      uid: booking.uid,
      title: `${eventType.title} with ${host.name ?? "host"}`,
      description: [booking.meetLink ? `Join: ${booking.meetLink}` : "", ...answers.map((a) => `${a.label}: ${a.value}`)].filter(Boolean).join("\n") || undefined,
      location: where,
      start: booking.startTime,
      end: booking.endTime,
      organizer: { name: host.name ?? "Host", email: host.email },
      attendee: { name: booking.attendeeName, email: booking.attendeeEmail },
      status: kind === "cancelled" ? "CANCELLED" : "CONFIRMED",
      sequence: kind === "cancelled" ? 1 : 0,
    }),
  ).toString("base64");

  const common = { kind, hostName: host.name ?? "Host", guestName: booking.attendeeName, title: eventType.title, start: booking.startTime, end: booking.endTime, where, manageUrl, notes: booking.notes, answers };

  const guest = renderBookingEmail({ ...common, audience: "guest", timezone: booking.attendeeTimezone });
  const hostMail = renderBookingEmail({ ...common, audience: "host", timezone: host.timezone });

  await Promise.allSettled([
    sendEmail({ to: booking.attendeeEmail, ...guest, attachments: [{ filename: "booking.ics", content: ics }] }),
    sendEmail({ to: host.email, ...hostMail }),
  ]);
}

/** One call from the booking routes: emails + webhooks, all fail-safe. */
export async function notifyBooking(event: WebhookEvent, ctx: Ctx) {
  const kind = event === "booking.cancelled" ? "cancelled" : "confirmed";
  await Promise.allSettled([emails(ctx, kind), dispatchWebhooks(ctx.host.id, event, webhookData(ctx))]);
}
