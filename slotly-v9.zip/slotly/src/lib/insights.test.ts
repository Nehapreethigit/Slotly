import { describe, expect, it } from "vitest";
import { computeInsights, type InsightBooking } from "./insights";

const now = new Date("2026-10-08T06:00:00Z"); // Thu 11:30 in Asia/Kolkata

const b = (iso: string, over: Partial<InsightBooking> = {}): InsightBooking => ({
  startTime: new Date(iso),
  status: "CONFIRMED",
  eventTypeId: "t1",
  eventTypeTitle: "30 min",
  ...over,
});

describe("computeInsights", () => {
  it("handles no bookings", () => {
    const i = computeInsights([], "UTC", now);
    expect(i.totalConfirmed).toBe(0);
    expect(i.cancellationRate).toBe(0);
    expect(i.perDay).toHaveLength(30);
    expect(i.perDay.every((d) => d.count === 0)).toBe(true);
    expect(i.busiest).toBeNull();
  });

  it("counts upcoming vs past and this-month", () => {
    const i = computeInsights(
      [b("2026-10-09T10:00:00Z"), b("2026-10-02T10:00:00Z"), b("2026-09-20T10:00:00Z")],
      "UTC",
      now,
    );
    expect(i.totalConfirmed).toBe(3);
    expect(i.upcoming).toBe(1);
    expect(i.thisMonth).toBe(2);
  });

  it("computes the cancellation rate over all bookings and excludes cancelled from stats", () => {
    const i = computeInsights(
      [b("2026-10-09T10:00:00Z"), b("2026-10-10T10:00:00Z"), b("2026-10-11T10:00:00Z", { status: "CANCELLED" }), b("2026-10-12T10:00:00Z", { status: "CANCELLED" })],
      "UTC",
      now,
    );
    expect(i.cancelled).toBe(2);
    expect(i.cancellationRate).toBe(0.5);
    expect(i.upcoming).toBe(2);
    expect(i.heatmap.flat().reduce((a, c) => a + c, 0)).toBe(2);
  });

  it("buckets days in the host's timezone, not UTC", () => {
    // 20:00Z on 7 Oct is already 01:30 on 8 Oct in Kolkata
    const utc = computeInsights([b("2026-10-07T20:00:00Z")], "UTC", now);
    const ist = computeInsights([b("2026-10-07T20:00:00Z")], "Asia/Kolkata", now);
    expect(utc.perDay.find((d) => d.date === "2026-10-07")?.count).toBe(1);
    expect(ist.perDay.find((d) => d.date === "2026-10-07")?.count).toBe(0);
    expect(ist.perDay.find((d) => d.date === "2026-10-08")?.count).toBe(1);
  });

  it("zero-fills a window that ends today and is oldest-first", () => {
    const i = computeInsights([], "UTC", now, 7);
    expect(i.perDay.map((d) => d.date)).toEqual([
      "2026-10-02", "2026-10-03", "2026-10-04", "2026-10-05", "2026-10-06", "2026-10-07", "2026-10-08",
    ]);
  });

  it("builds the weekday x hour heatmap with Sunday = 0 and finds the busiest slot", () => {
    // 2026-10-11 is a Sunday; 2026-10-12 is a Monday
    const i = computeInsights(
      [b("2026-10-11T09:00:00Z"), b("2026-10-12T14:00:00Z"), b("2026-10-19T14:30:00Z")],
      "UTC",
      now,
    );
    expect(i.heatmap[0][9]).toBe(1);
    expect(i.heatmap[1][14]).toBe(2);
    expect(i.busiest).toEqual({ weekday: 1, hour: 14, count: 2 });
    expect(i.heatmapMax).toBe(2);
  });

  it("ranks event types by popularity", () => {
    const i = computeInsights(
      [b("2026-10-09T10:00:00Z"), b("2026-10-10T10:00:00Z", { eventTypeId: "t2", eventTypeTitle: "60 min" }), b("2026-10-11T10:00:00Z", { eventTypeId: "t2", eventTypeTitle: "60 min" })],
      "UTC",
      now,
    );
    expect(i.byEventType.map((t) => [t.title, t.count])).toEqual([["60 min", 2], ["30 min", 1]]);
  });
});
