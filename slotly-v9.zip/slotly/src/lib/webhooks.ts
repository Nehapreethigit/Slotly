import { randomBytes } from "node:crypto";
import { prisma } from "./prisma";
import { isSafeWebhookUrl, signPayload, type WebhookEvent } from "./webhook-security";

const TIMEOUT_MS = 5_000;
const MAX_ATTEMPTS = 2;

export function generateWebhookSecret() {
  return "whsec_" + randomBytes(24).toString("hex");
}

const allowInsecure = () => process.env.NODE_ENV !== "production";

async function deliverOnce(url: string, secret: string, event: WebhookEvent, body: string) {
  const timestamp = Math.floor(Date.now() / 1000);
  const started = Date.now();
  try {
    const res = await fetch(url, {
      method: "POST",
      redirect: "manual", // a redirect could bounce us to an internal address, so never follow
      signal: AbortSignal.timeout(TIMEOUT_MS),
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Slotly-Webhooks/1.0",
        "Slotly-Event": event,
        "Slotly-Timestamp": String(timestamp),
        "Slotly-Signature": signPayload(secret, timestamp, body),
      },
      body,
    });
    return { ok: res.ok, status: res.status, error: res.ok ? null : `HTTP ${res.status}`, ms: Date.now() - started };
  } catch (err) {
    const msg = err instanceof Error ? (err.name === "TimeoutError" ? "Timed out after 5s" : err.message) : "Request failed";
    return { ok: false, status: null as number | null, error: msg.slice(0, 200), ms: Date.now() - started };
  }
}

/**
 * Fire every active webhook of `userId` that subscribes to `event`.
 * Never throws: webhook trouble must not break a booking. Each webhook gets one retry on failure,
 * and every outcome is stored as a WebhookDelivery row so the host can see what happened.
 */
export async function dispatchWebhooks(userId: string, event: WebhookEvent, data: unknown) {
  try {
    const hooks = await prisma.webhook.findMany({ where: { userId, active: true, events: { has: event } } });
    if (hooks.length === 0) return;

    const body = JSON.stringify({ event, createdAt: new Date().toISOString(), data });

    await Promise.allSettled(
      hooks.map(async (hook) => {
        const safe = isSafeWebhookUrl(hook.url, { allowInsecure: allowInsecure() });
        if (!safe.ok) {
          await prisma.webhookDelivery.create({
            data: { webhookId: hook.id, event, success: false, attempts: 0, error: `Blocked: ${safe.reason}` },
          });
          return;
        }

        let result = await deliverOnce(hook.url, hook.secret, event, body);
        let attempts = 1;
        while (!result.ok && attempts < MAX_ATTEMPTS) {
          await new Promise((r) => setTimeout(r, 750));
          result = await deliverOnce(hook.url, hook.secret, event, body);
          attempts += 1;
        }

        await prisma.webhookDelivery.create({
          data: {
            webhookId: hook.id,
            event,
            statusCode: result.status,
            success: result.ok,
            attempts,
            error: result.error,
            durationMs: result.ms,
          },
        });
      }),
    );
  } catch (err) {
    console.error("[webhooks] dispatch failed", err);
  }
}
