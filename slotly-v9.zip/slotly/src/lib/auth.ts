import type { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { prisma } from "./prisma";
import { GOOGLE_SCOPES } from "./constants";
import { setupNewUser } from "./user-setup";
import { verifyPassword } from "./passwords";
import { rateLimit } from "./rate-limit";

export const googleEnabled = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  session: { strategy: "jwt" },
  secret: process.env.NEXTAUTH_SECRET,
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
      authorization: {
        params: {
          // offline + consent => Google returns a refresh token so we can call Calendar later
          access_type: "offline",
          prompt: "consent",
          response_type: "code",
          scope: GOOGLE_SCOPES,
        },
      },
    }),
    CredentialsProvider({
      id: "credentials",
      name: "Email and password",
      credentials: { email: {}, password: {} },
      async authorize(credentials) {
        const email = String(credentials?.email ?? "").trim().toLowerCase();
        const password = String(credentials?.password ?? "");
        if (!email || !password) return null;
        if (!rateLimit(`login:${email}`, 8, 15 * 60_000)) throw new Error("Too many attempts. Try again in a few minutes.");

        const user = await prisma.user.findUnique({ where: { email } });
        // Same answer for "no such user" and "wrong password" so emails can't be probed
        if (!user?.passwordHash || !(await verifyPassword(password, user.passwordHash))) return null;
        return { id: user.id, name: user.name, email: user.email, image: user.image };
      },
    }),
  ],
  pages: { signIn: "/login" },
  callbacks: {
    async jwt({ token, user }) {
      if (user) token.uid = user.id;
      return token;
    },
    async session({ session, token }) {
      if (session.user && token.uid) session.user.id = token.uid;
      return session;
    },
  },
  events: {
    // Runs once for brand-new users: pick a username and seed sensible defaults.
    async createUser({ user }) {
      await setupNewUser(user);
    },

    // NextAuth only stores tokens on first link, so refresh them on every sign-in
    // (this is what makes "reconnect Google" actually pick up new scopes/refresh token).
    async signIn({ account }) {
      if (account?.provider === "google" && account.access_token) {
        await prisma.account.updateMany({
          where: { provider: "google", providerAccountId: account.providerAccountId },
          data: {
            access_token: account.access_token,
            expires_at: account.expires_at,
            scope: account.scope,
            ...(account.refresh_token ? { refresh_token: account.refresh_token } : {}),
          },
        });
      }
    },
  },
};

export async function getUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions);
  return session?.user?.id ?? null;
}

export const unauthorized = () => NextResponse.json({ error: "Unauthorized" }, { status: 401 });
