export const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

// Display order in the availability editor (Monday first)
export const WEEKDAY_ORDER = [1, 2, 3, 4, 5, 6, 0];

// Would collide with real routes in src/app
export const RESERVED_USERNAMES = ["api", "dashboard", "booking", "login", "signup", "settings", "admin", "_next", "static", "slotly"];

export const LOCATIONS = [
  { value: "GOOGLE_MEET", label: "Google Meet" },
  { value: "IN_PERSON", label: "In person" },
  { value: "CUSTOM", label: "Custom link / phone" },
] as const;

export function locationLabel(location: string, detail?: string | null) {
  if (location === "GOOGLE_MEET") return "Google Meet";
  if (location === "IN_PERSON") return detail || "In person";
  return detail || "Custom location";
}

export const GOOGLE_SCOPES = [
  "openid",
  "email",
  "profile",
  "https://www.googleapis.com/auth/calendar.events",
  "https://www.googleapis.com/auth/calendar.freebusy",
].join(" ");
