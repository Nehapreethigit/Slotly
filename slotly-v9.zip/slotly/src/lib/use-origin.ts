"use client";

import { useEffect, useState } from "react";

/**
 * The site's origin/host, read in an effect so the server render and the first client render match.
 * (Reading window.location during render gives a different string on the server and causes a hydration error.)
 */
export function useOrigin() {
  const [value, setValue] = useState({ origin: "", host: "" });
  useEffect(() => setValue({ origin: window.location.origin, host: window.location.host }), []);
  return value;
}
