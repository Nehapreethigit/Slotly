import { formatInTimeZone } from "date-fns-tz";
import { nextDate } from "./slots";

/** Pure aggregation over bookings, in the HOST's timezone. No DB access, so it is unit tested. */

export type InsightBooking = {
  startTime: Date;
  status: "CONFIRMED" | "CANCELLED";
  eventTypeId: string;
  eventTypeTitle: string;
};

export type Insights = {
  upcoming: number;
  thisMonth: number;
  totalConfirmed: number;
  cancelled: number;
  cancellationRate: number; // 0..1, share of all bookings that were cancelled
  perDay: { date: string; count: number }[]; // last `days` days, oldest first, zero-filled
  heatmap: number[][]; // [weekday 0=Sun..6=Sat][hour 0..23]
  heatmapMax: number;
  byEventType: { id: string; title: string; count: number }[];
  busiest: { weekday: number; hour: number; count: number } | null;
};

export function computeInsights(bookings: InsightBooking[], timezone: string, now: Date, days = 30): Insights {
  const today = formatInTimeZone(now, timezone, "yyyy-MM-dd");
  const month = today.slice(0, 7);

  // Build the zero-filled window ending today.
  const window: string[] = [today];
  for (let i = 1; i < days; i++) {
    const [y, m, d] = window[0].split("-").map(Number);
    window.unshift(new Date(Date.UTC(y, m - 1, d - 1)).toISOString().slice(0, 10));
  }
  const perDayMap = new Map(window.map((d) => [d, 0]));

  const heatmap = Array.from({ length: 7 }, () => Array<number>(24).fill(0));
  const typeMap = new Map<string, { title: string; count: number }>();

  let upcoming = 0;
  let thisMonth = 0;
  let totalConfirmed = 0;
  let cancelled = 0;

  for (const b of bookings) {
    if (b.status === "CANCELLED") {
      cancelled += 1;
      continue;
    }
    totalConfirmed += 1;
    if (b.startTime >= now) upcoming += 1;

    const date = formatInTimeZone(b.startTime, timezone, "yyyy-MM-dd");
    if (date.slice(0, 7) === month) thisMonth += 1;
    if (perDayMap.has(date)) perDayMap.set(date, (perDayMap.get(date) ?? 0) + 1);

    const weekday = Number(formatInTimeZone(b.startTime, timezone, "i")) % 7; // ISO 1=Mon..7=Sun -> 0=Sun
    const hour = Number(formatInTimeZone(b.startTime, timezone, "H"));
    heatmap[weekday][hour] += 1;

    const t = typeMap.get(b.eventTypeId) ?? { title: b.eventTypeTitle, count: 0 };
    t.count += 1;
    typeMap.set(b.eventTypeId, t);
  }

  let heatmapMax = 0;
  let busiest: Insights["busiest"] = null;
  heatmap.forEach((row, weekday) =>
    row.forEach((count, hour) => {
      if (count > heatmapMax) {
        heatmapMax = count;
        busiest = { weekday, hour, count };
      }
    }),
  );

  const all = totalConfirmed + cancelled;
  return {
    upcoming,
    thisMonth,
    totalConfirmed,
    cancelled,
    cancellationRate: all === 0 ? 0 : cancelled / all,
    perDay: window.map((date) => ({ date, count: perDayMap.get(date) ?? 0 })),
    heatmap,
    heatmapMax,
    byEventType: [...typeMap.entries()].map(([id, v]) => ({ id, ...v })).sort((a, b) => b.count - a.count),
    busiest,
  };
}

export { nextDate };
