/**
 * Minimal RFC 5545 iCalendar generator, so a guest can add a booking to ANY calendar app
 * (Apple, Outlook, Proton...), not just Google. Pure function, unit tested.
 */

export type IcsInput = {
  uid: string;
  title: string;
  description?: string;
  location?: string;
  start: Date;
  end: Date;
  organizer?: { name: string; email?: string };
  attendee?: { name: string; email: string };
  status?: "CONFIRMED" | "CANCELLED";
  sequence?: number;
  now?: Date;
};

const fmt = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");

/** Escape TEXT values per RFC 5545 section 3.3.11. */
export function escapeIcsText(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
}

/** Lines must be <= 75 octets; longer ones are folded with CRLF + a single space. */
export function foldLine(line: string): string {
  const bytes = Buffer.from(line, "utf8");
  if (bytes.length <= 75) return line;

  const parts: string[] = [];
  let current = "";
  let currentBytes = 0;
  let limit = 75;
  for (const ch of line) {
    const size = Buffer.byteLength(ch, "utf8");
    if (currentBytes + size > limit) {
      parts.push(current);
      current = "";
      currentBytes = 0;
      limit = 74; // continuation lines start with a space, which counts toward the limit
    }
    current += ch;
    currentBytes += size;
  }
  parts.push(current);
  return parts.join("\r\n ");
}

export function buildIcs(input: IcsInput): string {
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Slotly//Scheduling//EN",
    "CALSCALE:GREGORIAN",
    `METHOD:${input.status === "CANCELLED" ? "CANCEL" : "PUBLISH"}`,
    "BEGIN:VEVENT",
    `UID:${input.uid}@slotly`,
    `DTSTAMP:${fmt(input.now ?? new Date())}`,
    `DTSTART:${fmt(input.start)}`,
    `DTEND:${fmt(input.end)}`,
    `SEQUENCE:${input.sequence ?? 0}`,
    `STATUS:${input.status ?? "CONFIRMED"}`,
    `SUMMARY:${escapeIcsText(input.title)}`,
  ];
  if (input.description) lines.push(`DESCRIPTION:${escapeIcsText(input.description)}`);
  if (input.location) lines.push(`LOCATION:${escapeIcsText(input.location)}`);
  if (input.organizer) {
    const cn = `CN=${escapeIcsText(input.organizer.name).replace(/[":]/g, "")}`;
    lines.push(input.organizer.email ? `ORGANIZER;${cn}:mailto:${input.organizer.email}` : `ORGANIZER;${cn}:mailto:noreply@slotly.invalid`);
  }
  if (input.attendee) {
    const cn = `CN=${escapeIcsText(input.attendee.name).replace(/[":]/g, "")}`;
    lines.push(`ATTENDEE;${cn};RSVP=FALSE:mailto:${input.attendee.email}`);
  }
  lines.push("END:VEVENT", "END:VCALENDAR");
  return lines.map(foldLine).join("\r\n") + "\r\n";
}
