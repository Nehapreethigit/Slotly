/**
 * Transactional email through Resend's HTTP API (plain fetch, no SDK).
 * Optional: with no RESEND_API_KEY every send is a logged no-op, so the app works without it.
 * Never throws - a mail outage must not break a booking.
 */

export const emailEnabled = () => !!process.env.RESEND_API_KEY;

export async function sendEmail(args: {
  to: string;
  subject: string;
  html: string;
  text: string;
  attachments?: { filename: string; content: string }[]; // content = base64
}): Promise<boolean> {
  const key = process.env.RESEND_API_KEY;
  if (!key) return false;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      signal: AbortSignal.timeout(8_000),
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM ?? "Slotly <onboarding@resend.dev>",
        to: [args.to],
        subject: args.subject,
        html: args.html,
        text: args.text,
        attachments: args.attachments,
      }),
    });
    if (!res.ok) console.warn("[email] Resend rejected the message", res.status, await res.text());
    return res.ok;
  } catch (err) {
    console.warn("[email] send failed", err);
    return false;
  }
}
