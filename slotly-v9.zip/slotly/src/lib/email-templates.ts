import { formatInTimeZone } from "date-fns-tz";

/** HTML-escape anything user-supplied before it goes into an email body. */
export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export type BookingEmailData = {
  kind: "confirmed" | "cancelled";
  audience: "guest" | "host";
  hostName: string;
  guestName: string;
  title: string;
  start: Date;
  end: Date;
  timezone: string; // the timezone to display times in (guest's for guests, host's for hosts)
  where: string;
  manageUrl: string;
  notes?: string | null;
  answers?: { label: string; value: string }[];
};

export function renderBookingEmail(d: BookingEmailData): { subject: string; html: string; text: string } {
  const when = `${formatInTimeZone(d.start, d.timezone, "EEEE, d MMMM yyyy, h:mm a")} - ${formatInTimeZone(d.end, d.timezone, "h:mm a")} (${d.timezone.replace(/_/g, " ")})`;
  const other = d.audience === "guest" ? d.hostName : d.guestName;

  const headline =
    d.kind === "cancelled"
      ? "This booking was cancelled"
      : d.audience === "guest"
        ? "You're booked!"
        : `New booking from ${d.guestName}`;
  const subject = `${d.kind === "cancelled" ? "Cancelled" : d.audience === "guest" ? "Confirmed" : "New booking"}: ${d.title} with ${other}`;

  const rows: [string, string][] = [
    ["What", d.title],
    ["With", other],
    ["When", when],
    ["Where", d.where],
  ];
  for (const a of d.answers ?? []) rows.push([a.label, a.value]);
  if (d.notes) rows.push(["Notes", d.notes]);

  const html = `<!doctype html><html><body style="margin:0;background:#f8fafc;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:#0f172a">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 16px">
<table role="presentation" width="100%" style="max-width:520px;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:32px">
<tr><td>
<h1 style="margin:0 0 20px;font-size:22px">${escapeHtml(headline)}</h1>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;line-height:1.5">
${rows.map(([k, v]) => `<tr><td style="padding:6px 12px 6px 0;color:#64748b;width:110px;vertical-align:top">${escapeHtml(k)}</td><td style="padding:6px 0">${escapeHtml(v)}</td></tr>`).join("\n")}
</table>
${d.kind === "confirmed" ? `<p style="margin:24px 0 0"><a href="${escapeHtml(d.manageUrl)}" style="display:inline-block;background:#2447F5;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-size:14px;font-weight:600">View, reschedule or cancel</a></p>` : ""}
</td></tr></table>
<p style="font-size:12px;color:#94a3b8;margin-top:16px">Sent by Slotly</p>
</td></tr></table></body></html>`;

  const text = [headline, "", ...rows.map(([k, v]) => `${k}: ${v}`), "", d.kind === "confirmed" ? `Manage: ${d.manageUrl}` : ""].join("\n").trim();

  return { subject, html, text };
}
