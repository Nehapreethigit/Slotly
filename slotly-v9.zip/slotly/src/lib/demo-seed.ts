import type { PrismaClient } from "@prisma/client";
import { DEMO_EMAIL_DOMAIN, generateDemoBookings } from "./demo-data";

/**
 * Database side of the demo data. Shared by `npm run db:seed` and the "Try the demo" login,
 * so the deployed site works for visitors without any Google setup.
 * The client is passed in (instead of imported) so the seed script can use its own connection.
 */

export const DEMO_HOST_EMAIL = "demo@slotly.invalid";
const DEFAULT_WEEKLY = [1, 2, 3, 4, 5].map((weekday) => ({ weekday, startMin: 540, endMin: 1020 }));

const DEMO_EVENT_TYPES = [
  { slug: "15min", title: "15 min chat", duration: 15, color: "#7A56FF", description: "A quick intro call to see if we are a fit.", location: "GOOGLE_MEET", locationDetail: null },
  { slug: "mock-interview", title: "Mock interview", duration: 60, color: "#22D3EE", description: "Full-stack interview practice with written feedback afterwards.", location: "GOOGLE_MEET", locationDetail: null },
  { slug: "coffee", title: "Coffee catch-up", duration: 45, color: "#F472B6", description: "Talk shop over coffee.", location: "IN_PERSON", locationDetail: "Third Wave Coffee, Indiranagar, Bengaluru" },
];

export async function removeDemoBookings(db: PrismaClient, hostId?: string) {
  const { count } = await db.booking.deleteMany({
    where: { attendeeEmail: { endsWith: `@${DEMO_EMAIL_DOMAIN}` }, ...(hostId ? { hostId } : {}) },
  });
  return count;
}

/** Replaces the sample bookings of one user. Returns how many were added (0 if they have no event types). */
export async function fillDemoBookings(db: PrismaClient, user: { id: string; timezone: string }) {
  const [weekly, eventTypes] = await Promise.all([
    db.availability.findMany({ where: { userId: user.id } }),
    db.eventType.findMany({ where: { userId: user.id } }),
  ]);
  if (eventTypes.length === 0) return { added: 0, removed: 0 };

  const removed = await removeDemoBookings(db, user.id);
  const rows = generateDemoBookings({
    now: new Date(),
    timezone: user.timezone,
    weekly: weekly.length > 0 ? weekly : DEFAULT_WEEKLY,
    eventTypes: eventTypes.map((e) => ({ id: e.id, duration: e.duration })),
  });
  await db.booking.createMany({ data: rows.map((r) => ({ ...r, hostId: user.id })) });
  return { added: rows.length, removed };
}

/** Creates (or finds) the public demo host with weekly hours and three meeting types. Safe to call repeatedly. */
export async function ensureDemoHost(db: PrismaClient) {
  // "demo" might already belong to a real person who signed up with demo@something.com
  const taken = await db.user.findUnique({ where: { username: "demo" }, select: { email: true } });
  const username = taken && taken.email !== DEMO_HOST_EMAIL ? "slotly-demo" : "demo";

  const host = await db.user.upsert({
    where: { email: DEMO_HOST_EMAIL },
    update: {},
    create: {
      email: DEMO_HOST_EMAIL,
      name: "Demo Host",
      username,
      bio: "This is a sample profile so you can try the booking flow. Nothing here is real.",
      timezone: "Asia/Kolkata",
      timezoneSet: true,
    },
  });

  if ((await db.availability.count({ where: { userId: host.id } })) === 0) {
    await db.availability.createMany({ data: DEFAULT_WEEKLY.map((r) => ({ ...r, userId: host.id })) });
  }
  for (const t of DEMO_EVENT_TYPES) {
    await db.eventType.upsert({
      where: { userId_slug: { userId: host.id, slug: t.slug } },
      update: {},
      create: { ...t, userId: host.id },
    });
  }
  return host;
}
