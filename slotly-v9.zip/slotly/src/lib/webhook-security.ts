import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Pure helpers for webhook signing and URL safety. No DB, no network.
 *
 * Signature scheme (same idea as Stripe/GitHub): the receiver recomputes
 *   HMAC_SHA256(secret, `${timestamp}.${rawBody}`)
 * and compares it to the `Slotly-Signature` header. The timestamp is part of the signed
 * string so a captured request can't be replayed later (receivers should reject old timestamps).
 */

export function signPayload(secret: string, timestamp: number, body: string): string {
  return "sha256=" + createHmac("sha256", secret).update(`${timestamp}.${body}`).digest("hex");
}

export function verifySignature(
  secret: string,
  timestamp: number,
  body: string,
  signature: string,
  opts: { now?: number; toleranceSec?: number } = {},
): boolean {
  const now = opts.now ?? Math.floor(Date.now() / 1000);
  const tolerance = opts.toleranceSec ?? 300;
  if (Math.abs(now - timestamp) > tolerance) return false;

  const expected = Buffer.from(signPayload(secret, timestamp, body));
  const given = Buffer.from(signature);
  return expected.length === given.length && timingSafeEqual(expected, given);
}

const BLOCKED_HOSTNAMES = new Set(["localhost", "metadata.google.internal", "metadata"]);

function isPrivateIPv4(host: string): boolean {
  const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 169 && b === 254) || // link-local, includes cloud metadata 169.254.169.254
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127) // carrier-grade NAT
  );
}

/**
 * SSRF guard: a webhook URL is user-supplied and our server will fetch it, so refuse anything
 * that points at our own machine or private network. (This checks the literal hostname only;
 * a hostile DNS record that resolves to a private IP would need a resolver-level check too.)
 */
export function isSafeWebhookUrl(raw: string, opts: { allowInsecure?: boolean } = {}): { ok: true } | { ok: false; reason: string } {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return { ok: false, reason: "Not a valid URL" };
  }

  if (url.protocol !== "https:" && !(opts.allowInsecure && url.protocol === "http:")) {
    return { ok: false, reason: "URL must start with https://" };
  }
  if (url.username || url.password) return { ok: false, reason: "URL must not contain credentials" };

  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (BLOCKED_HOSTNAMES.has(host) || host.endsWith(".localhost") || host.endsWith(".internal") || host.endsWith(".local")) {
    return { ok: false, reason: "That host is not allowed" };
  }
  if (isPrivateIPv4(host)) return { ok: false, reason: "Private network addresses are not allowed" };
  if (host.includes(":")) {
    // IPv6 literal: block loopback, unspecified, unique-local (fc00::/7), link-local (fe80::/10), v4-mapped
    if (host === "::1" || host === "::" || /^f[cd]/.test(host) || /^fe[89ab]/.test(host) || host.startsWith("::ffff:")) {
      return { ok: false, reason: "Private network addresses are not allowed" };
    }
  }
  return { ok: true };
}

export const WEBHOOK_EVENTS = ["booking.created", "booking.cancelled", "booking.rescheduled"] as const;
export type WebhookEvent = (typeof WEBHOOK_EVENTS)[number];
