import { describe, expect, it } from "vitest";
import { hashToken, isExpired, newResetToken, renderResetEmail, resetIdentifier } from "./password-reset";

describe("password reset helpers", () => {
  it("creates unique tokens and stores only the hash", () => {
    const a = newResetToken();
    const b = newResetToken();
    expect(a.token).not.toBe(b.token);
    expect(a.token).toHaveLength(64);
    expect(a.tokenHash).toBe(hashToken(a.token));
    expect(a.tokenHash).not.toBe(a.token);
  });

  it("normalises the identifier", () => {
    expect(resetIdentifier("  Neha@Example.COM ")).toBe("reset:neha@example.com");
  });

  it("detects expiry", () => {
    const now = new Date("2026-01-01T12:00:00Z");
    expect(isExpired(new Date("2026-01-01T11:59:59Z"), now)).toBe(true);
    expect(isExpired(new Date("2026-01-01T12:00:01Z"), now)).toBe(false);
  });

  it("escapes the link and name in the email", () => {
    const m = renderResetEmail('<b>Evil</b> Name', 'https://x.test/r?t=1&e="2"');
    expect(m.html).not.toContain("<b>Evil</b>");
    expect(m.html).toContain("&amp;e=&quot;2&quot;");
    expect(m.text).toContain("https://x.test/r?t=1");
  });
});
