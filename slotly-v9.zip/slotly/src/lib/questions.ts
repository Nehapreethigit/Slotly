import { z } from "zod";

/**
 * Custom booking questions: a host adds fields to an event type ("What should we cover?",
 * "Company size"), guests answer them when booking. Pure and unit tested.
 * The host's questions are the source of truth: the server only accepts answers to questions that
 * exist, enforces required ones, and snapshots the question text so old bookings stay readable
 * after the host edits or removes a question.
 */

export const QUESTION_TYPES = ["text", "textarea", "select"] as const;
export type QuestionType = (typeof QUESTION_TYPES)[number];

export const MAX_QUESTIONS = 8;
const MAX_LEN: Record<QuestionType, number> = { text: 200, textarea: 1000, select: 80 };

export const questionSchema = z
  .object({
    id: z.string().regex(/^[a-z0-9_-]{1,40}$/i, "Invalid question id"),
    label: z.string().trim().min(1, "Every question needs a label").max(120, "Question label is too long"),
    type: z.enum(QUESTION_TYPES),
    required: z.boolean(),
    options: z.array(z.string().trim().min(1).max(80)).max(20).optional(),
  })
  .refine((q) => q.type !== "select" || (q.options?.length ?? 0) >= 2, {
    message: "A dropdown question needs at least two options",
    path: ["options"],
  });

export const questionsSchema = z
  .array(questionSchema)
  .max(MAX_QUESTIONS, `At most ${MAX_QUESTIONS} questions`)
  .refine((qs) => new Set(qs.map((q) => q.id)).size === qs.length, "Duplicate question ids");

export type Question = z.infer<typeof questionSchema>;
export type Answer = { id: string; label: string; value: string };

/** Reads the Json column defensively: anything malformed becomes "no questions" instead of a crash. */
export function parseQuestions(raw: unknown): Question[] {
  const parsed = questionsSchema.safeParse(raw);
  return parsed.success ? parsed.data : [];
}

/** Same for the stored answers on a booking. */
export function parseAnswers(raw: unknown): Answer[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (a): a is Answer => !!a && typeof a.id === "string" && typeof a.label === "string" && typeof a.value === "string",
  );
}

export function newQuestionId() {
  return `q${Math.random().toString(36).slice(2, 9)}`;
}

export type ResolveResult = { ok: true; answers: Answer[] } | { ok: false; error: string };

export function resolveAnswers(questions: Question[], raw: Record<string, string> | undefined): ResolveResult {
  const answers: Answer[] = [];
  for (const q of questions) {
    const value = (raw?.[q.id] ?? "").trim();
    if (!value) {
      if (q.required) return { ok: false, error: `Please answer: ${q.label}` };
      continue;
    }
    if (value.length > MAX_LEN[q.type]) return { ok: false, error: `Your answer to "${q.label}" is too long` };
    if (q.type === "select" && !q.options?.includes(value)) return { ok: false, error: `Pick one of the options for: ${q.label}` };
    answers.push({ id: q.id, label: q.label, value });
  }
  return { ok: true, answers };
}
