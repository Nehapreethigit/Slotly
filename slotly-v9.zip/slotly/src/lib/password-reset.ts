import { createHash, randomBytes } from "node:crypto";

/** Reset links last one hour. */
export const RESET_TTL_MS = 60 * 60_000;

export const resetIdentifier = (email: string) => `reset:${email.trim().toLowerCase()}`;

/** A fresh random token. Only its hash is stored, so a database leak cannot be used to reset passwords. */
export function newResetToken(): { token: string; tokenHash: string } {
  const token = randomBytes(32).toString("hex");
  return { token, tokenHash: hashToken(token) };
}

export const hashToken = (token: string) => createHash("sha256").update(token).digest("hex");

export const isExpired = (expires: Date, now = new Date()) => expires.getTime() <= now.getTime();

export function renderResetEmail(name: string | null, link: string) {
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const hello = name ? `Hi ${name.split(" ")[0]},` : "Hi,";
  const text = `${hello}\n\nSomeone asked to reset your Slotly password. Open this link within one hour to choose a new one:\n${link}\n\nIf this was not you, ignore this email and your password stays the same.`;
  const html = `<!doctype html><html><body style="margin:0;background:#f8fafc;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:#0f172a">
<table role="presentation" width="100%"><tr><td align="center" style="padding:32px 16px">
<table role="presentation" width="100%" style="max-width:480px;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:32px"><tr><td>
<h1 style="margin:0 0 12px;font-size:22px">Reset your password</h1>
<p style="margin:0 0 20px;line-height:1.5">${esc(hello)} someone asked to reset your Slotly password. This link works for one hour.</p>
<p style="margin:0 0 20px"><a href="${esc(link)}" style="display:inline-block;background:#7A56FF;color:#fff;text-decoration:none;padding:11px 20px;border-radius:8px;font-weight:600">Choose a new password</a></p>
<p style="margin:0;font-size:13px;color:#64748b;line-height:1.5">If this was not you, ignore this email and your password stays the same.</p>
</td></tr></table></td></tr></table></body></html>`;
  return { subject: "Reset your Slotly password", html, text };
}
