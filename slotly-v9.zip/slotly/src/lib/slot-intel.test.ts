import { describe, expect, it } from "vitest";
import { comfortFor, findPackedSlots, pickHighlights, verdict } from "./slot-intel";

const d = (s: string) => new Date(s);

describe("findPackedSlots", () => {
  const busy = [{ start: d("2026-01-05T10:00:00Z"), end: d("2026-01-05T11:00:00Z") }];
  const slots = ["09:00", "09:30", "10:00", "11:00", "11:30", "13:00"].map((t) => d(`2026-01-05T${t}:00Z`));

  it("marks slots flush before and after a meeting", () => {
    const p = findPackedSlots(slots, busy, { duration: 30, bufferBefore: 0, bufferAfter: 0 });
    expect([...p].map((t) => new Date(t).toISOString().slice(11, 16)).sort()).toEqual(["09:30", "11:00"]);
  });

  it("accounts for buffers", () => {
    const p = findPackedSlots(slots, busy, { duration: 30, bufferBefore: 30, bufferAfter: 0 });
    expect(p.has(d("2026-01-05T11:30:00Z").getTime())).toBe(true);
    expect(p.has(d("2026-01-05T11:00:00Z").getTime())).toBe(false);
  });

  it("returns nothing on an empty calendar", () => {
    expect(findPackedSlots(slots, [], { duration: 30, bufferBefore: 0, bufferAfter: 0 }).size).toBe(0);
  });
});

describe("comfortFor", () => {
  it("classifies hours in the given timezone", () => {
    expect(comfortFor("2026-01-05T10:00:00Z", 30, "UTC")).toBe("good");
    expect(comfortFor("2026-01-05T07:15:00Z", 30, "UTC")).toBe("stretch");
    expect(comfortFor("2026-01-05T03:00:00Z", 30, "UTC")).toBe("night");
    expect(comfortFor("2026-01-05T20:00:00Z", 30, "UTC")).toBe("stretch");
  });

  it("uses the timezone, not the server clock", () => {
    // 10:00 UTC is 15:30 in Kolkata (good) but 02:00 in New York (night)
    expect(comfortFor("2026-01-05T10:00:00Z", 30, "Asia/Kolkata")).toBe("good");
    expect(comfortFor("2026-01-05T07:00:00Z", 30, "America/New_York")).toBe("night");
  });
});

describe("verdict + highlights", () => {
  it("is fair for both only when both are good", () => {
    expect(verdict("2026-01-05T10:00:00Z", 30, "Asia/Kolkata", "Europe/London").both).toBe(true);
    expect(verdict("2026-01-05T16:00:00Z", 30, "Asia/Kolkata", "Europe/London").both).toBe(false);
  });

  it("picks distinct highlights", () => {
    const slots = ["2026-01-05T03:00:00Z", "2026-01-05T07:30:00Z", "2026-01-05T09:00:00Z", "2026-01-05T10:00:00Z"];
    const v = Object.fromEntries(slots.map((s) => [s, verdict(s, 30, "UTC", "UTC")]));
    const h = pickHighlights(slots, new Set([slots[3]]), v);
    expect(h.map((x) => x.label)).toEqual(["Best fit", "Fair for both", "Soonest"]);
    expect(new Set(h.map((x) => x.iso)).size).toBe(h.length);
    expect(h[0].iso).toBe(slots[3]);
    expect(h[1].iso).toBe(slots[2]);
    expect(h[2].iso).toBe(slots[1]);
  });
});
