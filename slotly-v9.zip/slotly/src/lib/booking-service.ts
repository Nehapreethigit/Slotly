import { findPackedSlots } from "@/lib/slot-intel";
import { addDays, addMinutes } from "date-fns";
import type { EventType, User } from "@prisma/client";
import { prisma } from "./prisma";
import { getBusyTimes } from "./google";
import { computeSlots } from "./slots";

export async function getHostAndEventType(username: string, slug: string) {
  const user = await prisma.user.findUnique({ where: { username } });
  if (!user) return null;
  const eventType = await prisma.eventType.findFirst({ where: { userId: user.id, slug, active: true } });
  if (!eventType) return null;
  return { user, eventType };
}

/**
 * Gathers everything from the DB + Google, then hands it to the pure slot engine.
 * `excludeBookingUid` is used when rescheduling so the old booking doesn't block its own replacement.
 */
type SlotArgs = {
  user: User;
  eventType: EventType;
  rangeStart: Date;
  rangeEnd: Date;
  excludeBookingUid?: string;
};

export async function getAvailableSlots(args: SlotArgs): Promise<Date[]> {
  return (await getSlotsWithHints(args)).slots;
}

/** Same as getAvailableSlots, plus which slots sit flush against an existing meeting ("best fit"). */
export async function getSlotsWithHints(args: SlotArgs): Promise<{ slots: Date[]; packed: Date[] }> {
  const { user, eventType, rangeStart, excludeBookingUid } = args;
  const now = new Date();
  const horizon = addDays(now, eventType.maxDaysAhead);
  const rangeEnd = args.rangeEnd < horizon ? args.rangeEnd : horizon;
  if (rangeEnd <= rangeStart) return { slots: [], packed: [] };

  // Look slightly beyond the range so buffers/long events at the edges are accounted for.
  const pad = Math.max(eventType.bufferBefore, eventType.bufferAfter, eventType.duration);
  const from = addMinutes(rangeStart, -pad);
  const to = addMinutes(rangeEnd, pad);

  const [rules, blocked, bookings, oldBooking] = await Promise.all([
    prisma.availability.findMany({ where: { userId: user.id } }),
    prisma.blockedDate.findMany({ where: { userId: user.id } }),
    prisma.booking.findMany({
      where: {
        hostId: user.id,
        status: "CONFIRMED",
        ...(excludeBookingUid ? { uid: { not: excludeBookingUid } } : {}),
        startTime: { lt: to },
        endTime: { gt: from },
      },
    }),
    excludeBookingUid ? prisma.booking.findUnique({ where: { uid: excludeBookingUid } }) : Promise.resolve(null),
  ]);

  let googleBusy = await getBusyTimes(user.id, from, to);
  if (oldBooking) {
    // The booking being rescheduled still exists on Google Calendar - don't let it block itself.
    googleBusy = googleBusy.filter(
      (b) => !(b.start.getTime() === oldBooking.startTime.getTime() && b.end.getTime() === oldBooking.endTime.getTime()),
    );
  }

  const busy = [...bookings.map((b) => ({ start: b.startTime, end: b.endTime })), ...googleBusy];
  const slots = computeSlots({
    rangeStart,
    rangeEnd,
    timezone: user.timezone,
    weekly: rules,
    blockedDates: blocked.map((b) => b.date),
    duration: eventType.duration,
    interval: eventType.slotInterval ?? eventType.duration,
    bufferBefore: eventType.bufferBefore,
    bufferAfter: eventType.bufferAfter,
    minNotice: eventType.minNotice,
    busy,
    now,
  });
  const packedSet = findPackedSlots(slots, busy, {
    duration: eventType.duration,
    bufferBefore: eventType.bufferBefore,
    bufferAfter: eventType.bufferAfter,
  });
  return { slots, packed: slots.filter((s) => packedSet.has(s.getTime())) };
}
