import { z } from "zod";
import { RESERVED_USERNAMES } from "./constants";
import { isValidTimezone } from "./utils";
import { questionsSchema } from "./questions";

export const usernameSchema = z
  .string()
  .min(3, "At least 3 characters")
  .max(30, "At most 30 characters")
  .regex(/^[a-z0-9][a-z0-9-]*$/, "Lowercase letters, numbers and dashes only")
  .refine((v) => !RESERVED_USERNAMES.includes(v), "That username is reserved");

export const timezoneSchema = z.string().max(64).refine(isValidTimezone, "Unknown timezone");

export const profileSchema = z.object({
  name: z.string().trim().min(1).max(80),
  username: usernameSchema,
  bio: z.string().max(300).nullable().optional(),
  timezone: timezoneSchema,
});

export const eventTypeSchema = z.object({
  title: z.string().trim().min(1, "Title is required").max(80),
  slug: z
    .string()
    .min(1)
    .max(50)
    .regex(/^[a-z0-9][a-z0-9-]*$/, "Lowercase letters, numbers and dashes only"),
  description: z.string().max(500).nullable().optional(),
  duration: z.number().int().min(5).max(480),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  bufferBefore: z.number().int().min(0).max(120),
  bufferAfter: z.number().int().min(0).max(120),
  minNotice: z.number().int().min(0).max(60 * 24 * 30),
  maxDaysAhead: z.number().int().min(1).max(365),
  slotInterval: z.number().int().min(5).max(480).nullable().optional(),
  location: z.enum(["GOOGLE_MEET", "IN_PERSON", "CUSTOM"]),
  locationDetail: z.string().max(200).nullable().optional(),
  active: z.boolean().optional(),
  questions: questionsSchema.optional(),
});

export const availabilitySchema = z.object({
  weekly: z
    .array(
      z
        .object({
          weekday: z.number().int().min(0).max(6),
          startMin: z.number().int().min(0).max(1439),
          endMin: z.number().int().min(1).max(1439),
        })
        .refine((r) => r.endMin > r.startMin, "End must be after start"),
    )
    .max(70),
  blockedDates: z.array(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).max(366),
});

export const bookingSchema = z.object({
  username: z.string().min(1).max(30),
  slug: z.string().min(1).max(50),
  start: z.string().datetime(),
  name: z.string().trim().min(1, "Name is required").max(100),
  email: z.string().trim().email("Enter a valid email").max(200),
  notes: z.string().max(1000).optional(),
  answers: z.record(z.string().max(60), z.string().max(1000)).optional(),
  timezone: timezoneSchema,
  rescheduleUid: z.string().uuid().optional(),
});

export const passwordSchema = z
  .string()
  .min(8, "Password needs at least 8 characters")
  .max(72, "Password can be at most 72 characters"); // bcrypt ignores everything after 72 bytes

export const signupSchema = z.object({
  name: z.string().trim().min(1, "Please enter your name").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email").max(254),
  password: passwordSchema,
});
