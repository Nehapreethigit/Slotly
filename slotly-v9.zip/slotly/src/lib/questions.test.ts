import { describe, expect, it } from "vitest";
import { parseAnswers, parseQuestions, questionsSchema, resolveAnswers, type Question } from "./questions";

const qs: Question[] = [
  { id: "goal", label: "What should we cover?", type: "textarea", required: true },
  { id: "size", label: "Company size", type: "select", required: false, options: ["1-10", "11-50", "50+"] },
  { id: "site", label: "Website", type: "text", required: false },
];

describe("resolveAnswers", () => {
  it("keeps answers in question order and snapshots the label", () => {
    const r = resolveAnswers(qs, { site: " example.com ", goal: "Review my resume", size: "11-50" });
    expect(r).toEqual({
      ok: true,
      answers: [
        { id: "goal", label: "What should we cover?", value: "Review my resume" },
        { id: "size", label: "Company size", value: "11-50" },
        { id: "site", label: "Website", value: "example.com" },
      ],
    });
  });

  it("rejects a missing or blank required answer", () => {
    expect(resolveAnswers(qs, {})).toEqual({ ok: false, error: "Please answer: What should we cover?" });
    expect(resolveAnswers(qs, { goal: "   " }).ok).toBe(false);
  });

  it("skips empty optional answers and ignores unknown ids", () => {
    const r = resolveAnswers(qs, { goal: "Hi", size: "", injected: "<script>" });
    expect(r).toEqual({ ok: true, answers: [{ id: "goal", label: "What should we cover?", value: "Hi" }] });
  });

  it("only accepts listed options for a dropdown", () => {
    expect(resolveAnswers(qs, { goal: "x", size: "1000+" }).ok).toBe(false);
  });

  it("enforces length limits per type", () => {
    expect(resolveAnswers(qs, { goal: "x", site: "a".repeat(201) }).ok).toBe(false);
    expect(resolveAnswers(qs, { goal: "a".repeat(1000) }).ok).toBe(true);
    expect(resolveAnswers(qs, { goal: "a".repeat(1001) }).ok).toBe(false);
  });

  it("works with no questions at all", () => {
    expect(resolveAnswers([], undefined)).toEqual({ ok: true, answers: [] });
  });
});

describe("questionsSchema / parse helpers", () => {
  it("requires two options for a dropdown and unique ids", () => {
    expect(questionsSchema.safeParse([{ id: "a", label: "A", type: "select", required: false, options: ["one"] }]).success).toBe(false);
    expect(questionsSchema.safeParse([qs[0], qs[0]]).success).toBe(false);
  });

  it("caps the number of questions", () => {
    const many = Array.from({ length: 9 }, (_, i) => ({ id: `q${i}`, label: "Q", type: "text", required: false }));
    expect(questionsSchema.safeParse(many).success).toBe(false);
  });

  it("never throws on malformed stored JSON", () => {
    expect(parseQuestions(null)).toEqual([]);
    expect(parseQuestions("garbage")).toEqual([]);
    expect(parseQuestions([{ nope: 1 }])).toEqual([]);
    expect(parseAnswers({ not: "array" })).toEqual([]);
    expect(parseAnswers([{ id: "a", label: "A", value: "v" }, { bad: true }])).toEqual([{ id: "a", label: "A", value: "v" }]);
  });
});
