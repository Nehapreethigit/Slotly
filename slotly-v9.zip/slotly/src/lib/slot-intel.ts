import { formatInTimeZone } from "date-fns-tz";
import type { Interval } from "./slots";

/**
 * Slot intelligence: two small ideas that normal schedulers do not have.
 *
 * 1. "Best fit" (calendar tetris): a slot is packed when it sits flush against an existing
 *    meeting. Picking those keeps your free time in one long block instead of confetti.
 * 2. "Comfort" (fair for both): is the slot at a humane hour for each person's own timezone?
 *    The booker uses this to badge slots as good for both, or to warn that a time is a stretch.
 */

const MIN = 60_000;

export function findPackedSlots(
  slots: Date[],
  busy: Interval[],
  opts: { duration: number; bufferBefore: number; bufferAfter: number },
): Set<number> {
  const packed = new Set<number>();
  if (!busy.length) return packed;
  const ends = new Set(busy.map((b) => b.end.getTime()));
  const starts = new Set(busy.map((b) => b.start.getTime()));
  for (const s of slots) {
    const t = s.getTime();
    const touchesBefore = ends.has(t - opts.bufferBefore * MIN);
    const touchesAfter = starts.has(t + (opts.duration + opts.bufferAfter) * MIN);
    if (touchesBefore || touchesAfter) packed.add(t);
  }
  return packed;
}

export type Comfort = "good" | "stretch" | "night";

/** Local start/end hours: 8:00-20:00 good, 7:00-22:00 a stretch, anything else is night. */
export function comfortFor(startIso: string | Date, durationMin: number, timezone: string): Comfort {
  const start = new Date(startIso);
  const end = new Date(start.getTime() + durationMin * MIN);
  const s = Number(formatInTimeZone(start, timezone, "H")) * 60 + Number(formatInTimeZone(start, timezone, "m"));
  let e = Number(formatInTimeZone(end, timezone, "H")) * 60 + Number(formatInTimeZone(end, timezone, "m"));
  if (e <= s) e += 1440; // crosses midnight
  if (s >= 8 * 60 && e <= 20 * 60) return "good";
  if (s >= 7 * 60 && e <= 22 * 60) return "stretch";
  return "night";
}

export type SlotVerdict = { guest: Comfort; host: Comfort; both: boolean };

export function verdict(startIso: string | Date, durationMin: number, guestTz: string, hostTz: string): SlotVerdict {
  const guest = comfortFor(startIso, durationMin, guestTz);
  const host = comfortFor(startIso, durationMin, hostTz);
  return { guest, host, both: guest === "good" && host === "good" };
}

/**
 * Pick up to three highlights from one day's slots: the best fit, the fairest time and the soonest.
 * Each slot appears once; later labels skip slots already used.
 */
export function pickHighlights(
  slotsIso: string[],
  packed: Set<string>,
  verdicts: Record<string, SlotVerdict>,
): { iso: string; label: "Best fit" | "Fair for both" | "Soonest" }[] {
  const out: { iso: string; label: "Best fit" | "Fair for both" | "Soonest" }[] = [];
  const used = new Set<string>();
  const take = (iso: string | undefined, label: "Best fit" | "Fair for both" | "Soonest") => {
    if (!iso || used.has(iso)) return;
    used.add(iso);
    out.push({ iso, label });
  };
  take(
    slotsIso.find((s) => packed.has(s) && verdicts[s]?.both),
    "Best fit",
  );
  take(
    slotsIso.find((s) => verdicts[s]?.both),
    "Fair for both",
  );
  take(
    slotsIso.find((s) => !used.has(s) && verdicts[s]?.guest !== "night"),
    "Soonest",
  );
  return out;
}
