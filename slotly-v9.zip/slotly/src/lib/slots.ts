import { formatInTimeZone, fromZonedTime } from "date-fns-tz";

/**
 * Pure availability engine. No database, no network - everything it needs is passed in,
 * which makes it trivial to unit test (see slots.test.ts).
 *
 * Idea: walk every calendar day in the HOST's timezone, turn the weekly rules into
 * absolute UTC windows (DST-safe via date-fns-tz), cut each window into slots, then
 * drop slots that are too soon, blocked, or collide with busy time (plus buffers).
 */

export type Interval = { start: Date; end: Date };
export type WeeklyRule = { weekday: number; startMin: number; endMin: number };

export type SlotParams = {
  rangeStart: Date;
  rangeEnd: Date;
  timezone: string; // host timezone (IANA)
  weekly: WeeklyRule[];
  blockedDates: string[]; // yyyy-MM-dd in host timezone
  duration: number; // minutes
  interval: number; // minutes between slot starts
  bufferBefore: number;
  bufferAfter: number;
  minNotice: number; // minutes from `now`
  busy: Interval[];
  now: Date;
};

const MIN = 60_000;

export function nextDate(date: string): string {
  const [y, m, d] = date.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d + 1)).toISOString().slice(0, 10);
}

export function weekdayOf(date: string): number {
  const [y, m, d] = date.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

/** Epoch ms for "minutes after midnight on `date`" in `timezone`. 1440 rolls to next day. */
function zonedEpoch(date: string, minutes: number, timezone: string): number {
  const day = minutes >= 1440 ? nextDate(date) : date;
  const mins = minutes >= 1440 ? 0 : minutes;
  const hh = String(Math.floor(mins / 60)).padStart(2, "0");
  const mm = String(mins % 60).padStart(2, "0");
  return fromZonedTime(`${day}T${hh}:${mm}:00`, timezone).getTime();
}

export function computeSlots(p: SlotParams): Date[] {
  const startDate = formatInTimeZone(p.rangeStart, p.timezone, "yyyy-MM-dd");
  const endDate = formatInTimeZone(p.rangeEnd, p.timezone, "yyyy-MM-dd");
  const earliest = Math.max(p.rangeStart.getTime(), p.now.getTime() + p.minNotice * MIN);
  const latest = p.rangeEnd.getTime();
  const blocked = new Set(p.blockedDates);
  const busy = p.busy.map((b) => [b.start.getTime(), b.end.getTime()] as const);
  const result = new Set<number>();

  for (let date = startDate; date <= endDate; date = nextDate(date)) {
    if (blocked.has(date)) continue;

    const rules = p.weekly
      .filter((r) => r.weekday === weekdayOf(date))
      .sort((a, b) => a.startMin - b.startMin);

    for (const rule of rules) {
      const windowStart = zonedEpoch(date, rule.startMin, p.timezone);
      const windowEnd = zonedEpoch(date, rule.endMin, p.timezone);

      for (let t = windowStart; t + p.duration * MIN <= windowEnd; t += p.interval * MIN) {
        if (t < earliest || t >= latest) continue;

        // The slot "occupies" its duration plus the buffers on both sides.
        const occupiedStart = t - p.bufferBefore * MIN;
        const occupiedEnd = t + (p.duration + p.bufferAfter) * MIN;
        const clashes = busy.some(([bs, be]) => occupiedStart < be && occupiedEnd > bs);
        if (!clashes) result.add(t);
      }
    }
  }

  return [...result].sort((a, b) => a - b).map((t) => new Date(t));
}
