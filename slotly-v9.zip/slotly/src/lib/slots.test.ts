import { describe, expect, it } from "vitest";
import { computeSlots, nextDate, weekdayOf, type SlotParams } from "./slots";

const weekdays9to5 = [1, 2, 3, 4, 5].map((weekday) => ({ weekday, startMin: 540, endMin: 1020 }));

function params(overrides: Partial<SlotParams> = {}): SlotParams {
  return {
    // Mon 2026-10-05 00:00Z -> Tue 2026-10-06 00:00Z
    rangeStart: new Date("2026-10-05T00:00:00Z"),
    rangeEnd: new Date("2026-10-06T00:00:00Z"),
    timezone: "UTC",
    weekly: weekdays9to5,
    blockedDates: [],
    duration: 60,
    interval: 60,
    bufferBefore: 0,
    bufferAfter: 0,
    minNotice: 0,
    busy: [],
    now: new Date("2026-10-01T00:00:00Z"),
    ...overrides,
  };
}

const iso = (slots: Date[]) => slots.map((s) => s.toISOString());

describe("date helpers", () => {
  it("rolls over month and year boundaries", () => {
    expect(nextDate("2026-10-31")).toBe("2026-11-01");
    expect(nextDate("2026-12-31")).toBe("2027-01-01");
    expect(nextDate("2028-02-28")).toBe("2028-02-29");
  });

  it("knows the weekday", () => {
    expect(weekdayOf("2026-10-05")).toBe(1); // Monday
    expect(weekdayOf("2026-10-11")).toBe(0); // Sunday
  });
});

describe("computeSlots", () => {
  it("cuts a 9-17 window into hourly slots", () => {
    const slots = computeSlots(params());
    expect(slots).toHaveLength(8);
    expect(slots[0].toISOString()).toBe("2026-10-05T09:00:00.000Z");
    expect(slots[7].toISOString()).toBe("2026-10-05T16:00:00.000Z");
  });

  it("returns nothing on days with no availability (weekend)", () => {
    const slots = computeSlots(
      params({
        rangeStart: new Date("2026-10-10T00:00:00Z"), // Saturday
        rangeEnd: new Date("2026-10-12T00:00:00Z"), // through Sunday
      }),
    );
    expect(slots).toEqual([]);
  });

  it("converts host-timezone rules to the right UTC instants (Asia/Kolkata)", () => {
    const slots = computeSlots(
      params({
        timezone: "Asia/Kolkata",
        duration: 30,
        interval: 30,
        rangeStart: new Date("2026-10-04T18:30:00Z"), // Mon 00:00 IST
        rangeEnd: new Date("2026-10-05T18:30:00Z"), // Tue 00:00 IST
      }),
    );
    // 09:00 IST = 03:30Z, last 30-min slot starts 16:30 IST = 11:00Z
    expect(slots[0].toISOString()).toBe("2026-10-05T03:30:00.000Z");
    expect(slots.at(-1)?.toISOString()).toBe("2026-10-05T11:00:00.000Z");
    expect(slots).toHaveLength(16);
  });

  it("handles DST: 9am New York is 14:00Z before and 13:00Z after spring-forward", () => {
    const before = computeSlots(
      params({
        timezone: "America/New_York",
        now: new Date("2026-03-01T00:00:00Z"),
        rangeStart: new Date("2026-03-06T00:00:00Z"), // Friday, EST
        rangeEnd: new Date("2026-03-07T12:00:00Z"),
      }),
    );
    expect(before[0].toISOString()).toBe("2026-03-06T14:00:00.000Z");

    const after = computeSlots(
      params({
        timezone: "America/New_York",
        now: new Date("2026-03-01T00:00:00Z"),
        rangeStart: new Date("2026-03-09T00:00:00Z"), // Monday, EDT
        rangeEnd: new Date("2026-03-10T00:00:00Z"),
      }),
    );
    expect(after[0].toISOString()).toBe("2026-03-09T13:00:00.000Z");
  });

  it("removes slots that collide with busy time", () => {
    const slots = computeSlots(
      params({
        busy: [{ start: new Date("2026-10-05T10:30:00Z"), end: new Date("2026-10-05T11:30:00Z") }],
      }),
    );
    // 10:00-11:00 and 11:00-12:00 both overlap the busy block
    expect(iso(slots)).not.toContain("2026-10-05T10:00:00.000Z");
    expect(iso(slots)).not.toContain("2026-10-05T11:00:00.000Z");
    expect(iso(slots)).toContain("2026-10-05T09:00:00.000Z");
    expect(iso(slots)).toContain("2026-10-05T12:00:00.000Z");
  });

  it("applies buffers before and after", () => {
    const busy = [{ start: new Date("2026-10-05T12:00:00Z"), end: new Date("2026-10-05T13:00:00Z") }];
    const withoutBuffer = iso(computeSlots(params({ busy })));
    expect(withoutBuffer).toContain("2026-10-05T11:00:00.000Z");
    expect(withoutBuffer).toContain("2026-10-05T13:00:00.000Z");

    const withBuffer = iso(computeSlots(params({ busy, bufferBefore: 15, bufferAfter: 15 })));
    expect(withBuffer).not.toContain("2026-10-05T11:00:00.000Z"); // 11:00-12:00 + 15 after touches 12:00
    expect(withBuffer).not.toContain("2026-10-05T13:00:00.000Z"); // 15 before reaches 12:45
    expect(withBuffer).toContain("2026-10-05T10:00:00.000Z");
    expect(withBuffer).toContain("2026-10-05T14:00:00.000Z");
  });

  it("enforces minimum notice", () => {
    const slots = computeSlots(
      params({
        now: new Date("2026-10-05T08:00:00Z"),
        minNotice: 180, // earliest allowed = 11:00Z
      }),
    );
    expect(slots[0].toISOString()).toBe("2026-10-05T11:00:00.000Z");
  });

  it("skips blocked dates", () => {
    const slots = computeSlots(params({ blockedDates: ["2026-10-05"] }));
    expect(slots).toEqual([]);
  });

  it("supports split availability on the same day", () => {
    const slots = computeSlots(
      params({
        weekly: [
          { weekday: 1, startMin: 540, endMin: 720 }, // 09-12
          { weekday: 1, startMin: 780, endMin: 960 }, // 13-16
        ],
      }),
    );
    expect(iso(slots)).toEqual([
      "2026-10-05T09:00:00.000Z",
      "2026-10-05T10:00:00.000Z",
      "2026-10-05T11:00:00.000Z",
      "2026-10-05T13:00:00.000Z",
      "2026-10-05T14:00:00.000Z",
      "2026-10-05T15:00:00.000Z",
    ]);
  });

  it("does not offer a slot that would overrun the window", () => {
    const slots = computeSlots(params({ duration: 45, interval: 60 }));
    // 16:00 + 45min = 16:45 fits inside 17:00, so the last slot is 16:00
    expect(slots.at(-1)?.toISOString()).toBe("2026-10-05T16:00:00.000Z");
    const long = computeSlots(params({ duration: 90, interval: 60 }));
    // 16:00 + 90min = 17:30 overruns, so the last slot is 15:00
    expect(long.at(-1)?.toISOString()).toBe("2026-10-05T15:00:00.000Z");
  });

  it("de-duplicates slots when rules overlap", () => {
    const slots = computeSlots(
      params({
        weekly: [
          { weekday: 1, startMin: 540, endMin: 720 },
          { weekday: 1, startMin: 600, endMin: 780 },
        ],
      }),
    );
    const unique = new Set(iso(slots));
    expect(unique.size).toBe(slots.length);
  });
});
