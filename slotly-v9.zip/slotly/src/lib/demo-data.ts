import { fromZonedTime, formatInTimeZone } from "date-fns-tz";
import { nextDate, weekdayOf, type WeeklyRule } from "./slots";

/**
 * Generates realistic sample bookings for demos and screenshots. Pure and deterministic
 * (seeded random numbers, no database), so it is unit tested and gives the same result every run.
 *
 * Guarantees: every booking starts inside the host's weekly hours (in the host's timezone),
 * and no two bookings overlap, so a demo host is never shown double-booked.
 */

export const DEMO_EMAIL_DOMAIN = "demo.slotly.invalid";

export type DemoEventType = { id: string; duration: number };
export type DemoBooking = {
  eventTypeId: string;
  startTime: Date;
  endTime: Date;
  attendeeName: string;
  attendeeEmail: string;
  attendeeTimezone: string;
  notes: string | null;
  status: "CONFIRMED" | "CANCELLED";
};

const NAMES = [
  "Priya Sharma", "Rahul Verma", "Ananya Iyer", "Karthik Nair", "Sneha Reddy", "Vikram Singh",
  "Meera Kapoor", "Arjun Mehta", "Diya Patel", "Rohan Das", "Ishita Joshi", "Aditya Rao",
  "Sara Johnson", "Liam Carter", "Noor Hassan", "Mateo Garcia", "Yuki Tanaka", "Emma Wilson",
];
const ZONES = ["Asia/Kolkata", "Asia/Kolkata", "Asia/Kolkata", "Europe/London", "America/New_York", "Asia/Singapore", "Europe/Berlin"];
const NOTES = [
  "Would love feedback on my system design approach.",
  "Can we focus on the backend part?",
  "First time using Slotly, looking forward to it.",
  "Please share a short agenda beforehand.",
  "Preparing for a full-stack interview next week.",
];

/** Small deterministic PRNG (mulberry32): same seed, same sequence. */
export function createRng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generateDemoBookings(args: {
  now: Date;
  timezone: string;
  weekly: WeeklyRule[];
  eventTypes: DemoEventType[];
  pastDays?: number;
  futureDays?: number;
  max?: number;
  seed?: number;
}): DemoBooking[] {
  const { now, timezone, weekly, eventTypes } = args;
  const pastDays = args.pastDays ?? 45;
  const futureDays = args.futureDays ?? 14;
  const max = args.max ?? 70;
  const rand = createRng(args.seed ?? 42);
  if (eventTypes.length === 0 || weekly.length === 0) return [];

  const pick = <T,>(list: T[]) => list[Math.floor(rand() * list.length)];

  // Walk from `pastDays` ago to `futureDays` ahead, in the host's timezone.
  let date = formatInTimeZone(new Date(now.getTime() - pastDays * 86_400_000), timezone, "yyyy-MM-dd");
  const lastDate = formatInTimeZone(new Date(now.getTime() + futureDays * 86_400_000), timezone, "yyyy-MM-dd");

  const taken: [number, number][] = [];
  const out: DemoBooking[] = [];

  for (; date <= lastDate && out.length < max; date = nextDate(date)) {
    const rules = weekly.filter((r) => r.weekday === weekdayOf(date));
    if (rules.length === 0) continue;

    // Midweek is busier, like a real calendar. 0 to 3 bookings a day.
    const wd = weekdayOf(date);
    const busy = wd >= 2 && wd <= 4 ? 0.8 : 0.5;
    const perDay = rand() < busy ? 1 + Math.floor(rand() * 3) : 0;

    for (let i = 0; i < perDay && out.length < max; i++) {
      const type = pick(eventTypes);
      const rule = pick(rules);
      const latestStart = rule.endMin - type.duration;
      if (latestStart < rule.startMin) continue;

      // Start times on the half hour inside the window.
      const slots = Math.floor((latestStart - rule.startMin) / 30) + 1;
      const minutes = rule.startMin + Math.floor(rand() * slots) * 30;
      const hh = String(Math.floor(minutes / 60)).padStart(2, "0");
      const mm = String(minutes % 60).padStart(2, "0");
      const start = fromZonedTime(`${date}T${hh}:${mm}:00`, timezone);
      const end = new Date(start.getTime() + type.duration * 60_000);

      if (taken.some(([s, e]) => start.getTime() < e && end.getTime() > s)) continue;
      taken.push([start.getTime(), end.getTime()]);

      const name = pick(NAMES);
      const past = start < now;
      out.push({
        eventTypeId: type.id,
        startTime: start,
        endTime: end,
        attendeeName: name,
        attendeeEmail: `${name.toLowerCase().replace(/[^a-z]+/g, ".")}${out.length}@${DEMO_EMAIL_DOMAIN}`,
        attendeeTimezone: pick(ZONES),
        notes: rand() < 0.3 ? pick(NOTES) : null,
        status: rand() < (past ? 0.1 : 0.04) ? "CANCELLED" : "CONFIRMED",
      });
    }
  }

  return out.sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
}
