import { prisma } from "./prisma";
import type { Interval } from "./slots";

/**
 * Thin Google Calendar client built on plain fetch (no heavy SDK).
 * - Reads the user's stored OAuth tokens, refreshing the access token when it expires.
 * - freeBusy: tells us when the host is busy on their real calendar.
 * - events.insert: creates the meeting, with a Google Meet link, and emails the invite.
 */

const TOKEN_URL = "https://oauth2.googleapis.com/token";
const CAL = "https://www.googleapis.com/calendar/v3";

export class GoogleAuthError extends Error {}

async function getAccessToken(userId: string): Promise<string> {
  const account = await prisma.account.findFirst({ where: { userId, provider: "google" } });
  if (!account?.access_token) throw new GoogleAuthError("No Google account linked");

  const nowSec = Math.floor(Date.now() / 1000);
  if (account.expires_at && account.expires_at - 60 > nowSec) return account.access_token;

  if (!account.refresh_token) throw new GoogleAuthError("No refresh token - reconnect Google in Settings");

  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID ?? "",
      client_secret: process.env.GOOGLE_CLIENT_SECRET ?? "",
      refresh_token: account.refresh_token,
      grant_type: "refresh_token",
    }),
  });
  if (!res.ok) throw new GoogleAuthError(`Token refresh failed (${res.status})`);

  const data = (await res.json()) as { access_token: string; expires_in: number };
  await prisma.account.update({
    where: { id: account.id },
    data: { access_token: data.access_token, expires_at: Math.floor(Date.now() / 1000) + data.expires_in },
  });
  return data.access_token;
}

async function calendarFetch(userId: string, path: string, init: RequestInit = {}) {
  const token = await getAccessToken(userId);
  return fetch(`${CAL}${path}`, {
    ...init,
    cache: "no-store",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
}

/** Busy intervals on the host's primary calendar. Fails open (returns []) so a Google outage never blocks booking. */
export async function getBusyTimes(userId: string, timeMin: Date, timeMax: Date): Promise<Interval[]> {
  try {
    const res = await calendarFetch(userId, "/freeBusy", {
      method: "POST",
      body: JSON.stringify({
        timeMin: timeMin.toISOString(),
        timeMax: timeMax.toISOString(),
        items: [{ id: "primary" }],
      }),
    });
    if (!res.ok) {
      console.warn("[google] freeBusy failed", res.status);
      return [];
    }
    const data = (await res.json()) as {
      calendars?: { primary?: { busy?: { start: string; end: string }[] } };
    };
    return (data.calendars?.primary?.busy ?? []).map((b) => ({ start: new Date(b.start), end: new Date(b.end) }));
  } catch (err) {
    console.warn("[google] freeBusy error", err);
    return [];
  }
}

export type CreateEventInput = {
  summary: string;
  description?: string;
  start: Date;
  end: Date;
  hostTimezone: string;
  attendeeEmail: string;
  attendeeName: string;
  location?: string;
  withMeet: boolean;
  requestId: string;
};

export async function createCalendarEvent(userId: string, input: CreateEventInput) {
  const body = {
    summary: input.summary,
    description: input.description,
    location: input.location,
    start: { dateTime: input.start.toISOString(), timeZone: input.hostTimezone },
    end: { dateTime: input.end.toISOString(), timeZone: input.hostTimezone },
    attendees: [{ email: input.attendeeEmail, displayName: input.attendeeName }],
    reminders: { useDefault: true },
    ...(input.withMeet
      ? {
          conferenceData: {
            createRequest: { requestId: input.requestId, conferenceSolutionKey: { type: "hangoutsMeet" } },
          },
        }
      : {}),
  };

  const res = await calendarFetch(userId, "/calendars/primary/events?conferenceDataVersion=1&sendUpdates=all", {
    method: "POST",
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Google event create failed: ${res.status} ${await res.text()}`);

  const data = (await res.json()) as { id: string; hangoutLink?: string };
  return { eventId: data.id, meetLink: data.hangoutLink ?? null };
}

export async function deleteCalendarEvent(userId: string, eventId: string) {
  try {
    const res = await calendarFetch(userId, `/calendars/primary/events/${encodeURIComponent(eventId)}?sendUpdates=all`, {
      method: "DELETE",
    });
    // 404/410 = already gone, which is fine
    if (!res.ok && res.status !== 404 && res.status !== 410) {
      console.warn("[google] event delete failed", res.status);
    }
  } catch (err) {
    console.warn("[google] event delete error", err);
  }
}
