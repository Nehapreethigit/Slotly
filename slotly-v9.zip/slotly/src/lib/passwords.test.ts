import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./passwords";
import { signupSchema } from "./validators";

describe("passwords", () => {
  it("verifies the right password and rejects the wrong one", async () => {
    const hashed = await hashPassword("correct horse battery");
    expect(hashed).not.toContain("correct horse");
    expect(await verifyPassword("correct horse battery", hashed)).toBe(true);
    expect(await verifyPassword("wrong horse battery", hashed)).toBe(false);
  });

  it("salts: the same password hashes differently each time", async () => {
    expect(await hashPassword("same-password-1")).not.toBe(await hashPassword("same-password-1"));
  });
});

describe("signupSchema", () => {
  const ok = { name: " Neha ", email: "  Neha@Example.COM ", password: "longenough1" };

  it("trims the name and lowercases the email", () => {
    const parsed = signupSchema.parse(ok);
    expect(parsed.name).toBe("Neha");
    expect(parsed.email).toBe("neha@example.com");
  });

  it("rejects short passwords, bad emails and empty names", () => {
    expect(signupSchema.safeParse({ ...ok, password: "short" }).success).toBe(false);
    expect(signupSchema.safeParse({ ...ok, password: "x".repeat(73) }).success).toBe(false);
    expect(signupSchema.safeParse({ ...ok, email: "not-an-email" }).success).toBe(false);
    expect(signupSchema.safeParse({ ...ok, name: "   " }).success).toBe(false);
  });
});
