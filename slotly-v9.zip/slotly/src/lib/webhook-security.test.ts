import { describe, expect, it } from "vitest";
import { isSafeWebhookUrl, signPayload, verifySignature } from "./webhook-security";

describe("webhook signing", () => {
  const secret = "whsec_test";
  const body = JSON.stringify({ event: "booking.created", data: { uid: "abc" } });
  const ts = 1_800_000_000;

  it("is deterministic and prefixed", () => {
    const a = signPayload(secret, ts, body);
    expect(a).toBe(signPayload(secret, ts, body));
    expect(a).toMatch(/^sha256=[0-9a-f]{64}$/);
  });

  it("verifies a good signature", () => {
    const sig = signPayload(secret, ts, body);
    expect(verifySignature(secret, ts, body, sig, { now: ts + 10 })).toBe(true);
  });

  it("rejects a tampered body, wrong secret, or wrong timestamp", () => {
    const sig = signPayload(secret, ts, body);
    expect(verifySignature(secret, ts, body + " ", sig, { now: ts })).toBe(false);
    expect(verifySignature("other", ts, body, sig, { now: ts })).toBe(false);
    expect(verifySignature(secret, ts + 1, body, sig, { now: ts })).toBe(false);
  });

  it("rejects replays outside the tolerance window", () => {
    const sig = signPayload(secret, ts, body);
    expect(verifySignature(secret, ts, body, sig, { now: ts + 301 })).toBe(false);
    expect(verifySignature(secret, ts, body, sig, { now: ts + 299 })).toBe(true);
  });

  it("does not throw on a signature of the wrong length", () => {
    expect(verifySignature(secret, ts, body, "sha256=short", { now: ts })).toBe(false);
  });
});

describe("isSafeWebhookUrl (SSRF guard)", () => {
  const ok = (u: string) => isSafeWebhookUrl(u).ok;

  it("allows normal public https URLs", () => {
    expect(ok("https://hooks.example.com/slotly")).toBe(true);
    expect(ok("https://example.com:8443/a?b=c")).toBe(true);
  });

  it("requires https unless insecure is explicitly allowed", () => {
    expect(ok("http://example.com/hook")).toBe(false);
    expect(isSafeWebhookUrl("http://example.com/hook", { allowInsecure: true }).ok).toBe(true);
    expect(ok("ftp://example.com")).toBe(false);
  });

  it("blocks loopback and private IPv4 ranges", () => {
    for (const u of [
      "https://127.0.0.1/x",
      "https://10.0.0.5/x",
      "https://172.16.0.1/x",
      "https://172.31.255.255/x",
      "https://192.168.1.1/x",
      "https://169.254.169.254/latest/meta-data",
      "https://0.0.0.0/x",
      "https://100.64.0.1/x",
    ]) {
      expect(ok(u), u).toBe(false);
    }
  });

  it("does not over-block public addresses next to private ranges", () => {
    expect(ok("https://172.32.0.1/x")).toBe(true);
    expect(ok("https://172.15.0.1/x")).toBe(true);
    expect(ok("https://8.8.8.8/x")).toBe(true);
  });

  it("blocks localhost-style and internal hostnames", () => {
    for (const u of ["https://localhost/x", "https://app.localhost/x", "https://metadata.google.internal/x", "https://printer.local/x"]) {
      expect(ok(u), u).toBe(false);
    }
  });

  it("blocks private IPv6 literals", () => {
    for (const u of ["https://[::1]/x", "https://[fd00::1]/x", "https://[fe80::1]/x", "https://[::ffff:127.0.0.1]/x"]) {
      expect(ok(u), u).toBe(false);
    }
  });

  it("blocks embedded credentials and garbage", () => {
    expect(ok("https://user:pass@example.com/x")).toBe(false);
    expect(ok("not a url")).toBe(false);
  });
});
