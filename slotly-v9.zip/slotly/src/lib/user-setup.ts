import { prisma } from "./prisma";
import { RESERVED_USERNAMES } from "./constants";
import { slugify } from "./utils";

/** Picks a free username from the email and gives a new account weekday hours and two meeting types. */
export async function setupNewUser(user: { id: string; email?: string | null }) {
  const local = (user.email ?? "user").split("@")[0];
  let base = slugify(local) || "user";
  if (base.length < 3) base = `${base}-user`;
  let username = base;
  let n = 0;
  while (RESERVED_USERNAMES.includes(username) || (await prisma.user.findUnique({ where: { username } }))) {
    n += 1;
    username = `${base}${n}`;
  }

  await prisma.user.update({ where: { id: user.id }, data: { username } });
  await prisma.availability.createMany({
    data: [1, 2, 3, 4, 5].map((weekday) => ({ userId: user.id, weekday, startMin: 540, endMin: 1020 })),
  });
  await prisma.eventType.createMany({
    data: [
      { userId: user.id, title: "15 min chat", slug: "15min", duration: 15, color: "#7A56FF" },
      { userId: user.id, title: "30 min meeting", slug: "30min", duration: 30, color: "#22D3EE" },
    ],
  });
}
