import { describe, expect, it } from "vitest";
import { buildIcs, escapeIcsText, foldLine } from "./ics";

const base = {
  uid: "11111111-2222-3333-4444-555555555555",
  title: "30 min meeting",
  start: new Date("2026-10-12T09:00:00Z"),
  end: new Date("2026-10-12T09:30:00Z"),
  now: new Date("2026-10-08T00:00:00Z"),
};

describe("escapeIcsText", () => {
  it("escapes backslash, semicolon, comma and newlines", () => {
    expect(escapeIcsText("a;b,c\\d\ne")).toBe("a\\;b\\,c\\\\d\\ne");
  });
});

describe("foldLine", () => {
  it("leaves short lines alone", () => {
    expect(foldLine("SUMMARY:hi")).toBe("SUMMARY:hi");
  });

  it("folds long lines so no physical line exceeds 75 octets", () => {
    const folded = foldLine("DESCRIPTION:" + "x".repeat(300));
    for (const physical of folded.split("\r\n")) expect(Buffer.byteLength(physical)).toBeLessThanOrEqual(75);
    // unfolding restores the original
    expect(folded.replace(/\r\n /g, "")).toBe("DESCRIPTION:" + "x".repeat(300));
  });

  it("never splits a multi-byte character", () => {
    const text = "DESCRIPTION:" + "नमस्ते ".repeat(40);
    const folded = foldLine(text);
    expect(folded.replace(/\r\n /g, "")).toBe(text);
    for (const physical of folded.split("\r\n")) expect(Buffer.byteLength(physical)).toBeLessThanOrEqual(75);
  });
});

describe("buildIcs", () => {
  it("produces a valid-looking VCALENDAR with CRLF endings and UTC times", () => {
    const ics = buildIcs(base);
    expect(ics.startsWith("BEGIN:VCALENDAR\r\n")).toBe(true);
    expect(ics.endsWith("END:VCALENDAR\r\n")).toBe(true);
    expect(ics).toContain("DTSTART:20261012T090000Z");
    expect(ics).toContain("DTEND:20261012T093000Z");
    expect(ics).toContain("DTSTAMP:20261008T000000Z");
    expect(ics).toContain("UID:11111111-2222-3333-4444-555555555555@slotly");
    expect(ics).not.toMatch(/[^\r]\n/); // every newline is part of a CRLF
  });

  it("escapes user-controlled text so it cannot inject extra ICS properties", () => {
    const ics = buildIcs({ ...base, title: "Hi\r\nATTENDEE:mailto:evil@x.com", description: "a;b,c" });
    expect(ics).not.toMatch(/\r\nATTENDEE:mailto:evil/);
    expect(ics).toContain("SUMMARY:Hi\\nATTENDEE:mailto:evil@x.com");
    expect(ics).toContain("DESCRIPTION:a\\;b\\,c");
  });

  it("marks cancellations with METHOD:CANCEL", () => {
    const ics = buildIcs({ ...base, status: "CANCELLED", sequence: 1 });
    expect(ics).toContain("METHOD:CANCEL");
    expect(ics).toContain("STATUS:CANCELLED");
    expect(ics).toContain("SEQUENCE:1");
  });

  it("strips quote/colon characters from CN so parameters stay well-formed", () => {
    const ics = buildIcs({ ...base, attendee: { name: 'Eve "x": y', email: "eve@example.com" } });
    expect(ics).toContain("ATTENDEE;CN=Eve x y;RSVP=FALSE:mailto:eve@example.com");
  });
});
