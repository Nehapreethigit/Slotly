import { compare, hash } from "bcryptjs";

// Cost 11 is about 100ms on a serverless CPU: slow enough to hurt brute force, fast enough for a login.
const COST = 11;

export const hashPassword = (plain: string) => hash(plain, COST);
export const verifyPassword = (plain: string, hashed: string) => compare(plain, hashed);
