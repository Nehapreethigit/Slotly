import { redirect } from "next/navigation";

// One combined page: log in or sign up
export default function Page() {
  redirect("/login");
}
