"use client";

import { useEffect } from "react";

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <main id="main" className="mx-auto flex min-h-screen max-w-md flex-col items-start justify-center px-6">
      <h1 className="text-2xl font-bold">Something broke on our side.</h1>
      <p className="mt-2 text-slate-600">
        Your data is safe. Try again, and if it keeps happening, check that the database is reachable.
        {error.digest && <span className="mt-3 block text-xs text-slate-400">Reference: {error.digest}</span>}
      </p>
      <button onClick={reset} className="btn-dark mt-8">
        Try again
      </button>
    </main>
  );
}
