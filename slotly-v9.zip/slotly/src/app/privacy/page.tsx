import type { Metadata } from "next";
import { LegalPage } from "@/components/legal-page";

export const metadata: Metadata = { title: "Privacy policy", alternates: { canonical: "/privacy" } };

export default function PrivacyPage() {
  return (
    <LegalPage title="Privacy policy" updated="October 2026">
      <p>
        Slotly is a scheduling tool. This page explains in plain words what information it handles and why. Whoever
        hosts this site is responsible for it; if you self-host Slotly, edit this page to match your setup.
      </p>
      <h2>What we collect</h2>
      <ul>
        <li>Account details: your name, email address and, if you sign up with a password, a salted hash of it (never the password itself). If you use Google sign-in, your Google name, email and profile picture.</li>
        <li>Scheduling data you create: event types, weekly hours, blocked dates and webhook settings.</li>
        <li>Booking data: when someone books a meeting we store their name, email, timezone, chosen time, any notes and any answers to the host&apos;s booking questions.</li>
        <li>Google Calendar data, only if you connect it: we read busy times to hide slots that are taken and create events for new bookings. We do not read event titles or contents for any other purpose.</li>
      </ul>
      <h2>How it is used</h2>
      <p>
        Only to run the service: show free times, confirm bookings, send confirmation emails and calendar invites, and
        deliver webhooks you configure. We do not sell your data and do not show ads.
      </p>
      <h2>Cookies</h2>
      <p>
        Slotly sets only essential cookies to keep you signed in and protect against forgery. There are no advertising
        or tracking cookies.
      </p>
      <h2>Who else sees it</h2>
      <ul>
        <li>The hosting and database providers that run the site.</li>
        <li>Google, if you use Google sign-in or calendar sync.</li>
        <li>An email provider, if email is enabled, to deliver confirmations.</li>
        <li>Any webhook URL you add yourself.</li>
      </ul>
      <h2>Your choices</h2>
      <p>
        You can disconnect Google at any time in your Google account settings, cancel any booking from its link, and
        ask for your account and data to be deleted by contacting us below.
      </p>
    </LegalPage>
  );
}
