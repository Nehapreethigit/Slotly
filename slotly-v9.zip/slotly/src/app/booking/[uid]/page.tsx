import Link from "next/link";
import { parseAnswers } from "@/lib/questions";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { formatInTimeZone } from "date-fns-tz";
import { CalendarPlus, CheckCircle2, Download, Globe, MapPin, RefreshCw, Video, XCircle } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { locationLabel } from "@/lib/constants";
import { CancelBookingButton } from "@/components/cancel-booking-button";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Your booking", robots: { index: false } };

function googleCalendarUrl(args: { title: string; start: Date; end: Date; details: string; location: string }) {
  const fmt = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const q = new URLSearchParams({
    action: "TEMPLATE",
    text: args.title,
    dates: `${fmt(args.start)}/${fmt(args.end)}`,
    details: args.details,
    location: args.location,
  });
  return `https://calendar.google.com/calendar/render?${q}`;
}

export default async function BookingConfirmationPage({ params }: { params: { uid: string } }) {
  const booking = await prisma.booking.findUnique({
    where: { uid: params.uid },
    include: { eventType: true, host: { select: { name: true, username: true } } },
  });
  if (!booking) notFound();

  const cancelled = booking.status === "CANCELLED";
  const past = booking.endTime < new Date();
  const tz = booking.attendeeTimezone;
  const where = booking.meetLink ?? locationLabel(booking.eventType.location, booking.eventType.locationDetail);

  return (
    <main id="main" className="mx-auto flex min-h-screen max-w-lg flex-col justify-center px-4 py-12">
      <div className="card animate-fade-up overflow-hidden">
        <div className="flex flex-col items-center px-6 pb-2 pt-8 text-center">
          {cancelled ? (
            <XCircle className="h-14 w-14 text-red-500" />
          ) : (
            <CheckCircle2 className="h-14 w-14 text-emerald-500" />
          )}
          <h1 className="mt-4 text-2xl font-bold tracking-tight">
            {cancelled ? "This booking was cancelled" : past ? "This meeting has ended" : "You're booked!"}
          </h1>
          {!cancelled && !past && (
            <p className="mt-1.5 text-sm text-slate-500">
              A calendar invite is on its way to <strong className="font-medium text-slate-700">{booking.attendeeEmail}</strong>.
            </p>
          )}
        </div>

        <dl className="m-6 space-y-4 rounded-xl bg-slate-50 p-5 text-sm">
          <div className="grid grid-cols-[90px_1fr] gap-2">
            <dt className="font-medium text-slate-500">What</dt>
            <dd className="font-medium">
              {booking.eventType.title} <span className="font-normal text-slate-500">with {booking.host.name}</span>
            </dd>
          </div>
          <div className="grid grid-cols-[90px_1fr] gap-2">
            <dt className="font-medium text-slate-500">When</dt>
            <dd className={cancelled ? "line-through decoration-slate-400" : ""}>
              {formatInTimeZone(booking.startTime, tz, "EEEE, d MMMM yyyy")}
              <br />
              {formatInTimeZone(booking.startTime, tz, "h:mm a")} - {formatInTimeZone(booking.endTime, tz, "h:mm a")}
              <span className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
                <Globe className="h-3.5 w-3.5" /> {tz.replace(/_/g, " ")}
              </span>
            </dd>
          </div>
          <div className="grid grid-cols-[90px_1fr] gap-2">
            <dt className="font-medium text-slate-500">Where</dt>
            <dd className="break-all">
              {booking.meetLink ? (
                <a href={booking.meetLink} target="_blank" className="inline-flex items-center gap-1.5 font-medium text-brand-400 hover:underline">
                  <Video className="h-4 w-4" /> Join with Google Meet
                </a>
              ) : (
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-slate-400" />
                  {booking.eventType.location === "GOOGLE_MEET" ? "Google Meet link will be in your invite" : where}
                </span>
              )}
            </dd>
          </div>
          {parseAnswers(booking.answers).map((a) => (
            <div key={a.id} className="grid grid-cols-[90px_1fr] gap-2">
              <dt className="font-medium text-slate-500">{a.label}</dt>
              <dd className="whitespace-pre-line break-words text-slate-700">{a.value}</dd>
            </div>
          ))}
          {booking.notes && (
            <div className="grid grid-cols-[90px_1fr] gap-2">
              <dt className="font-medium text-slate-500">Notes</dt>
              <dd className="text-slate-700">{booking.notes}</dd>
            </div>
          )}
        </dl>

        {!cancelled && !past && (
          <div className="flex flex-wrap items-center justify-center gap-2 border-t border-slate-100 px-6 py-5">
            <a
              href={googleCalendarUrl({
                title: `${booking.eventType.title} with ${booking.host.name}`,
                start: booking.startTime,
                end: booking.endTime,
                details: booking.meetLink ? `Join: ${booking.meetLink}` : "",
                location: booking.meetLink ?? where,
              })}
              target="_blank"
              className="btn-secondary"
            >
              <CalendarPlus className="h-4 w-4" /> Google Calendar
            </a>
            <a href={`/api/bookings/${booking.uid}/ics`} className="btn-secondary">
              <Download className="h-4 w-4" /> .ics file
            </a>
            <Link href={`/${booking.host.username}/${booking.eventType.slug}?reschedule=${booking.uid}`} className="btn-secondary">
              <RefreshCw className="h-4 w-4" /> Reschedule
            </Link>
            <CancelBookingButton uid={booking.uid} />
          </div>
        )}

        {(cancelled || past) && (
          <div className="flex justify-center border-t border-slate-100 px-6 py-5">
            <Link href={`/${booking.host.username}/${booking.eventType.slug}`} className="btn-primary">
              Book another time
            </Link>
          </div>
        )}
      </div>
      <p className="mt-6 text-center text-xs text-slate-400">
        Powered by{" "}
        <Link href="/" className="font-medium hover:text-brand-400">
          Slotly
        </Link>
      </p>
    </main>
  );
}
