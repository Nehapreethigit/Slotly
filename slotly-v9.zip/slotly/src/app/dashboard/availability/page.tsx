import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { AvailabilityEditor } from "@/components/availability-editor";

export const metadata = { title: "Availability" };

export default async function AvailabilityPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");

  const [user, weekly, blocked] = await Promise.all([
    prisma.user.findUnique({ where: { id: session.user.id } }),
    prisma.availability.findMany({
      where: { userId: session.user.id },
      orderBy: [{ weekday: "asc" }, { startMin: "asc" }],
    }),
    prisma.blockedDate.findMany({ where: { userId: session.user.id }, orderBy: { date: "asc" } }),
  ]);
  if (!user) redirect("/");

  return (
    <AvailabilityEditor
      timezone={user.timezone}
      initialWeekly={weekly.map(({ weekday, startMin, endMin }) => ({ weekday, startMin, endMin }))}
      initialBlocked={blocked.map((b) => b.date)}
    />
  );
}
