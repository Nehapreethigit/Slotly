import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { EventTypesManager } from "@/components/event-types-manager";
import { parseQuestions } from "@/lib/questions";

export const metadata = { title: "Event types" };

export default async function EventTypesPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");

  const [user, eventTypes] = await Promise.all([
    prisma.user.findUnique({ where: { id: session.user.id } }),
    prisma.eventType.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "asc" },
      include: { _count: { select: { bookings: true } } },
    }),
  ]);
  if (!user) redirect("/");

  return (
    <EventTypesManager
      username={user.username ?? ""}
      initial={eventTypes.map((e) => ({
        id: e.id,
        title: e.title,
        slug: e.slug,
        description: e.description,
        duration: e.duration,
        color: e.color,
        bufferBefore: e.bufferBefore,
        bufferAfter: e.bufferAfter,
        minNotice: e.minNotice,
        maxDaysAhead: e.maxDaysAhead,
        slotInterval: e.slotInterval,
        location: e.location,
        locationDetail: e.locationDetail,
        active: e.active,
        bookingCount: e._count.bookings,
        questions: parseQuestions(e.questions),
      }))}
    />
  );
}
