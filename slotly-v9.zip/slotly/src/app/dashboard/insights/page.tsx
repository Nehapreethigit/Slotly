import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { computeInsights } from "@/lib/insights";
import { InsightsView } from "@/components/insights-view";

export const metadata = { title: "Insights" };
export const dynamic = "force-dynamic";

export default async function InsightsPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user) redirect("/");

  const bookings = await prisma.booking.findMany({
    where: { hostId: user.id },
    select: { startTime: true, status: true, eventTypeId: true, eventType: { select: { title: true } } },
  });

  const insights = computeInsights(
    bookings.map((b) => ({ startTime: b.startTime, status: b.status, eventTypeId: b.eventTypeId, eventTypeTitle: b.eventType.title })),
    user.timezone,
    new Date(),
  );

  return <InsightsView insights={insights} timezone={user.timezone} />;
}
