import Link from "next/link";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { formatInTimeZone } from "date-fns-tz";
import { ArrowRight, BarChart3, CalendarCheck2, CalendarClock, CalendarPlus, Percent, Timer, Users, Video } from "lucide-react";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { computeInsights } from "@/lib/insights";
import { SetupPanel } from "@/components/setup-panel";
import { MiniBars } from "@/components/mini-bars";

export const metadata = { title: "Overview" };
export const dynamic = "force-dynamic";

function greeting(hour: number) {
  return hour < 5 ? "Working late" : hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
}

export default async function OverviewPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");
  const userId = session.user.id;

  const [user, google, availabilityCount, bookings] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId } }),
    prisma.account.findFirst({ where: { userId, provider: "google" }, select: { refresh_token: true, scope: true } }),
    prisma.availability.count({ where: { userId } }),
    prisma.booking.findMany({
      where: { hostId: userId },
      include: { eventType: { select: { id: true, title: true, color: true } } },
      orderBy: { startTime: "desc" },
      take: 2000,
    }),
  ]);
  if (!user) redirect("/");

  const now = new Date();
  const tz = user.timezone;
  const insights = computeInsights(
    bookings.map((b) => ({ startTime: b.startTime, status: b.status, eventTypeId: b.eventType.id, eventTypeTitle: b.eventType.title })),
    tz,
    now,
    30,
  );

  const upcoming = bookings
    .filter((b) => b.status === "CONFIRMED" && b.endTime >= now)
    .sort((a, b) => a.startTime.getTime() - b.startTime.getTime())
    .slice(0, 5);
  const colorOf = new Map(bookings.map((b) => [b.eventType.id, b.eventType.color]));
  const firstName = user.name?.split(" ")[0] ?? "there";
  const hour = Number(formatInTimeZone(now, tz, "H"));
  const topTypes = insights.byEventType.slice(0, 4);
  const topMax = Math.max(1, ...topTypes.map((t) => t.count));
  const last7 = insights.perDay.slice(-7).reduce((n, d) => n + d.count, 0);

  const kpis = [
    { label: "Upcoming", value: String(insights.upcoming), hint: "confirmed and still to come", icon: CalendarClock },
    { label: "This month", value: String(insights.thisMonth), hint: `${last7} in the last 7 days`, icon: CalendarCheck2 },
    { label: "All time", value: String(insights.totalConfirmed), hint: "confirmed bookings", icon: Users },
    {
      label: "Cancellations",
      value: `${Math.round(insights.cancellationRate * 100)}%`,
      hint: `${insights.cancelled} cancelled in total`,
      icon: Percent,
    },
  ];

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-slate-500">{formatInTimeZone(now, tz, "EEEE, d MMMM")}</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight">
            {greeting(hour)}, {firstName}
          </h1>
        </div>
        <Link href="/dashboard/event-types" className="btn-primary">
          <CalendarPlus className="h-4 w-4" /> New event type
        </Link>
      </header>

      <SetupPanel
        username={user.username ?? ""}
        setup={{
          googleConnected: !!google?.refresh_token && !!google.scope?.includes("calendar.events"),
          hasAvailability: availabilityCount > 0,
          hasBooking: bookings.length > 0,
        }}
      />

      <section aria-label="Key numbers" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {kpis.map(({ label, value, hint, icon: Icon }) => (
          <div key={label} className="card card-lift p-5">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-slate-500">{label}</p>
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-50 text-brand-400">
                <Icon className="h-4 w-4" />
              </span>
            </div>
            <p className="mt-3 font-display text-4xl font-bold tracking-tight">{value}</p>
            <p className="mt-1 text-xs text-slate-500">{hint}</p>
          </div>
        ))}
      </section>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <section className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 className="text-base font-semibold">Next up</h2>
            <Link href="/dashboard/bookings" className="inline-flex items-center gap-1 text-sm font-semibold text-brand-400 hover:underline">
              All bookings <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          {upcoming.length === 0 ? (
            <div className="px-5 py-12 text-center">
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-slate-100 text-slate-400">
                <CalendarClock className="h-6 w-6" />
              </span>
              <p className="mt-4 font-semibold">Nothing booked yet</p>
              <p className="mx-auto mt-1 max-w-xs text-sm text-slate-500">Share your booking link and the next meetings will show up here.</p>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {upcoming.map((b, i) => (
                <li key={b.id} className="flex items-center gap-4 px-5 py-4">
                  <div className={`grid h-14 w-14 shrink-0 place-items-center rounded-xl text-center leading-none ${i === 0 ? "bg-slot-100" : "bg-slate-100"}`}>
                    <div>
                      <p className="text-[11px] font-bold uppercase tracking-wider text-slate-700">{formatInTimeZone(b.startTime, tz, "EEE")}</p>
                      <p className="mt-1 font-display text-xl font-bold">{formatInTimeZone(b.startTime, tz, "d")}</p>
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-2 font-medium">
                      <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: colorOf.get(b.eventType.id) }} />
                      <span className="truncate">{b.eventType.title}</span>
                    </p>
                    <p className="mt-0.5 truncate text-sm text-slate-600">
                      {formatInTimeZone(b.startTime, tz, "h:mm a")} - {formatInTimeZone(b.endTime, tz, "h:mm a")} <span className="text-slate-400">with</span> {b.attendeeName}
                    </p>
                  </div>
                  {b.meetLink && (
                    <a href={b.meetLink} target="_blank" rel="noreferrer" className="btn-secondary !px-3 !py-2">
                      <Video className="h-4 w-4" /> Join
                    </a>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>

        <div className="space-y-6">
          <section className="card p-5">
            <div className="flex items-baseline justify-between">
              <h2 className="text-base font-semibold">Last 30 days</h2>
              <p className="text-xs text-slate-500">
                {insights.perDay.reduce((n, d) => n + d.count, 0)} bookings
              </p>
            </div>
            <div className="mt-4">
              <MiniBars values={insights.perDay.map((d) => d.count)} labels={insights.perDay.map((d) => d.date)} />
            </div>
            <div className="mt-2 flex justify-between text-[11px] text-slate-400">
              <span>30 days ago</span>
              <span>Today</span>
            </div>
          </section>

          <section className="card p-5">
            <h2 className="text-base font-semibold">Popular meeting types</h2>
            {topTypes.length === 0 ? (
              <p className="mt-3 text-sm text-slate-500">Once people book, you will see which meetings they pick.</p>
            ) : (
              <ul className="mt-4 space-y-3">
                {topTypes.map((t) => (
                  <li key={t.id}>
                    <div className="flex justify-between text-sm">
                      <span className="truncate font-medium">{t.title}</span>
                      <span className="text-slate-500">{t.count}</span>
                    </div>
                    <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full" style={{ width: `${(t.count / topMax) * 100}%`, background: colorOf.get(t.id) ?? "#7A56FF" }} />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>

      <section aria-label="Shortcuts" className="grid gap-3 sm:grid-cols-3">
        {[
          { href: "/dashboard/availability", label: "Set your weekly hours", icon: Timer },
          { href: "/dashboard/insights", label: "See your busiest times", icon: BarChart3 },
          { href: "/dashboard/event-types", label: "Edit meeting types and questions", icon: CalendarPlus },
        ].map(({ href, label, icon: Icon }) => (
          <Link key={href} href={href} className="card card-lift group flex items-center gap-3 p-4 text-sm font-semibold">
            <Icon className="h-[18px] w-[18px] text-slate-500 group-hover:text-brand-400" />
            <span className="flex-1">{label}</span>
            <ArrowRight className="h-4 w-4 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-brand-400" />
          </Link>
        ))}
      </section>
    </div>
  );
}
