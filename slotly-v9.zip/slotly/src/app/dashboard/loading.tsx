export default function DashboardLoading() {
  return (
    <div aria-busy="true" aria-label="Loading">
      <div className="skeleton h-8 w-56" />
      <div className="skeleton mt-3 h-4 w-80 max-w-full" />
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="card p-5">
            <div className="skeleton h-5 w-40" />
            <div className="skeleton mt-3 h-3 w-28" />
            <div className="mt-5 flex gap-2">
              <div className="skeleton h-6 w-16" />
              <div className="skeleton h-6 w-24" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
