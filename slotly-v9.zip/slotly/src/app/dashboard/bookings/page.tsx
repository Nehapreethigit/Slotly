import Link from "next/link";
import { parseAnswers } from "@/lib/questions";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { formatInTimeZone } from "date-fns-tz";
import { CalendarX, ExternalLink, Mail, Video } from "lucide-react";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { CancelBookingButton } from "@/components/cancel-booking-button";
import { cn } from "@/lib/utils";

export const metadata = { title: "Bookings" };
export const dynamic = "force-dynamic";

const TABS = [
  { key: "upcoming", label: "Upcoming" },
  { key: "past", label: "Past" },
  { key: "cancelled", label: "Cancelled" },
] as const;

export default async function BookingsPage({ searchParams }: { searchParams: { tab?: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");

  const tab = TABS.some((t) => t.key === searchParams.tab) ? (searchParams.tab as (typeof TABS)[number]["key"]) : "upcoming";
  const now = new Date();

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user) redirect("/");

  const where =
    tab === "upcoming"
      ? { hostId: user.id, status: "CONFIRMED" as const, endTime: { gte: now } }
      : tab === "past"
        ? { hostId: user.id, status: "CONFIRMED" as const, endTime: { lt: now } }
        : { hostId: user.id, status: "CANCELLED" as const };

  const bookings = await prisma.booking.findMany({
    where,
    include: { eventType: true },
    orderBy: { startTime: tab === "upcoming" ? "asc" : "desc" },
    take: 100,
  });

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight">Bookings</h1>
      <p className="mt-1 text-sm text-slate-500">
        Times shown in <strong className="font-medium text-slate-700">{user.timezone}</strong>.
      </p>

      <div className="mt-6 inline-flex rounded-xl bg-slate-100 p-1">
        {TABS.map((t) => (
          <Link
            key={t.key}
            href={`/dashboard/bookings?tab=${t.key}`}
            className={cn(
              "rounded-lg px-4 py-1.5 text-sm font-medium transition",
              tab === t.key ? "bg-surface text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-800",
            )}
          >
            {t.label}
          </Link>
        ))}
      </div>

      {bookings.length === 0 ? (
        <div className="card mt-6 flex flex-col items-center px-6 py-14 text-center">
          <span className="grid h-12 w-12 place-items-center rounded-full bg-slate-100 text-slate-400">
            <CalendarX className="h-6 w-6" />
          </span>
          <p className="mt-4 font-semibold">No {tab} bookings</p>
          <p className="mt-1 text-sm text-slate-500">
            {tab === "upcoming" ? "Share your link and they will show up here." : "Nothing to show here yet."}
          </p>
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {bookings.map((b) => (
            <li key={b.id} className="card flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
              <div className="w-full shrink-0 sm:w-44">
                <p className="text-sm font-semibold">{formatInTimeZone(b.startTime, user.timezone, "EEE, d MMM yyyy")}</p>
                <p className="text-sm text-slate-500">
                  {formatInTimeZone(b.startTime, user.timezone, "h:mm a")} - {formatInTimeZone(b.endTime, user.timezone, "h:mm a")}
                </p>
              </div>

              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 font-medium">
                  <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: b.eventType.color }} />
                  <span className="truncate">{b.eventType.title}</span>
                </p>
                <p className="mt-0.5 truncate text-sm text-slate-600">
                  {b.attendeeName} <span className="text-slate-400">-</span>{" "}
                  <a href={`mailto:${b.attendeeEmail}`} className="inline-flex items-center gap-1 hover:text-brand-400">
                    <Mail className="h-3.5 w-3.5" />
                    {b.attendeeEmail}
                  </a>
                </p>
                {parseAnswers(b.answers).length > 0 && (
                  <dl className="mt-2 space-y-0.5 rounded-lg bg-slate-50 px-3 py-2 text-sm">
                    {parseAnswers(b.answers).map((a) => (
                      <div key={a.id} className="flex gap-2">
                        <dt className="shrink-0 text-slate-500">{a.label}:</dt>
                        <dd className="min-w-0 break-words text-slate-800">{a.value}</dd>
                      </div>
                    ))}
                  </dl>
                )}
                {b.notes && <p className="mt-1.5 line-clamp-2 text-sm text-slate-500">&ldquo;{b.notes}&rdquo;</p>}
              </div>

              <div className="flex shrink-0 items-center gap-2">
                {b.meetLink && tab === "upcoming" && (
                  <a href={b.meetLink} target="_blank" className="btn-secondary !px-3 !py-2">
                    <Video className="h-4 w-4" /> Join
                  </a>
                )}
                <Link href={`/booking/${b.uid}`} target="_blank" className="btn-ghost !px-2.5 !py-2" aria-label="Open booking page">
                  <ExternalLink className="h-4 w-4" />
                </Link>
                {tab === "upcoming" && <CancelBookingButton uid={b.uid} compact />}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
