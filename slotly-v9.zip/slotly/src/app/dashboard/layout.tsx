import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { DashboardNav } from "@/components/dashboard-nav";
import { TimezoneSync } from "@/components/timezone-sync";
import { InstallApp } from "@/components/pwa";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { robots: { index: false, follow: false } };

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user) redirect("/");

  return (
    <div className="min-h-screen">
      <DashboardNav name={user.name} email={user.email} image={user.image} username={user.username} />
      <TimezoneSync needsSync={!user.timezoneSet} />
      <main id="main" tabIndex={-1} className="outline-none lg:pl-64">
        <div className="mx-auto max-w-5xl px-4 py-8 sm:px-8 sm:py-10">
          <InstallApp />
          {children}
        </div>
      </main>
    </div>
  );
}
