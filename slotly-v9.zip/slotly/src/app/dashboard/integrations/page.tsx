import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { emailEnabled } from "@/lib/email";
import { WebhooksManager } from "@/components/webhooks-manager";

export const metadata = { title: "Integrations" };
export const dynamic = "force-dynamic";

export default async function IntegrationsPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");

  const hooks = await prisma.webhook.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "asc" },
    include: { deliveries: { orderBy: { createdAt: "desc" }, take: 5 } },
  });

  return (
    <WebhooksManager
      emailOn={emailEnabled()}
      hooks={hooks.map((h) => ({
        id: h.id,
        url: h.url,
        // Show the secret only partly; it is needed once, when wiring up the receiver.
        secretHint: `${h.secret.slice(0, 10)}...${h.secret.slice(-4)}`,
        secret: h.secret,
        events: h.events,
        active: h.active,
        deliveries: h.deliveries.map((d) => ({
          id: d.id,
          event: d.event,
          success: d.success,
          statusCode: d.statusCode,
          attempts: d.attempts,
          error: d.error,
          durationMs: d.durationMs,
          at: d.createdAt.toISOString(),
        })),
      }))}
    />
  );
}
