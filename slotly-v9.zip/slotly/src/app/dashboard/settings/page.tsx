import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { SettingsForm } from "@/components/settings-form";

export const metadata = { title: "Settings" };
export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/");

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: { accounts: { where: { provider: "google" }, select: { refresh_token: true, scope: true } } },
  });
  if (!user) redirect("/");

  const google = user.accounts[0];

  return (
    <SettingsForm
      email={user.email}
      initial={{ name: user.name ?? "", username: user.username ?? "", bio: user.bio ?? "", timezone: user.timezone }}
      calendar={{
        connected: !!google,
        canWrite: !!google?.scope?.includes("calendar.events"),
        hasRefreshToken: !!google?.refresh_token,
      }}
    />
  );
}
