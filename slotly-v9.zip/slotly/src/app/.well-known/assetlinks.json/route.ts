import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Digital Asset Links: proves to Android that your Play Store app and this website belong together,
 * which is what removes the browser address bar inside the app.
 * Set ANDROID_PACKAGE_NAME (e.g. com.yourname.slotly) and ANDROID_SHA256_FINGERPRINTS
 * (comma separated; Play Console > App integrity gives you the signing one).
 */
export function GET() {
  const pkg = process.env.ANDROID_PACKAGE_NAME?.trim();
  const prints = (process.env.ANDROID_SHA256_FINGERPRINTS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  const body =
    pkg && prints.length
      ? [
          {
            relation: ["delegate_permission/common.handle_all_urls"],
            target: { namespace: "android_app", package_name: pkg, sha256_cert_fingerprints: prints },
          },
        ]
      : [];
  return NextResponse.json(body, { headers: { "Cache-Control": "public, max-age=300" } });
}
