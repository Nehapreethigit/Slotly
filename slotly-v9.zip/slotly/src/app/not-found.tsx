import Link from "next/link";

export default function NotFound() {
  return (
    <main id="main" className="mx-auto flex min-h-screen max-w-md flex-col items-start justify-center px-6">
      <p className="font-display text-7xl font-bold tracking-tight text-brand-400">404</p>
      <h1 className="mt-4 text-2xl font-bold">This page isn&apos;t on the calendar.</h1>
      <p className="mt-2 text-slate-600">The link may be mistyped, or the person changed their username or turned this meeting type off.</p>
      <Link href="/" className="btn-dark mt-8">
        Back to Slotly
      </Link>
    </main>
  );
}
