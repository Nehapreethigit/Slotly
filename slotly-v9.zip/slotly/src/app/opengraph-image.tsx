import { ImageResponse } from "next/og";
import { SITE_NAME, SITE_TAGLINE } from "@/lib/site";

export const alt = `${SITE_NAME} - ${SITE_TAGLINE}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

// The picture shown when the link is shared on WhatsApp, LinkedIn, Slack, X and so on.
export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          color: "#F3F4FF",
          backgroundColor: "#07070F",
          backgroundImage:
            "radial-gradient(circle at 0% 0%, rgba(122,86,255,0.55), rgba(7,7,15,0) 55%), radial-gradient(circle at 100% 0%, rgba(34,211,238,0.3), rgba(7,7,15,0) 50%), radial-gradient(circle at 80% 100%, rgba(244,114,182,0.3), rgba(7,7,15,0) 55%)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: 16,
              background: "linear-gradient(135deg, #7A56FF, #C04BFF)",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              gap: 6,
              padding: "0 14px",
            }}
          >
            <div style={{ height: 8, width: 20, borderRadius: 4, background: "rgba(255,255,255,0.6)" }} />
            <div style={{ height: 10, width: 36, borderRadius: 5, background: "#22D3EE" }} />
            <div style={{ height: 8, width: 24, borderRadius: 4, background: "rgba(255,255,255,0.6)" }} />
          </div>
          <div style={{ fontSize: 44, fontWeight: 800 }}>{SITE_NAME}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 84, fontWeight: 800, lineHeight: 1.05, letterSpacing: -3, display: "flex", flexDirection: "column" }}>
            <div style={{ display: "flex" }}>Booking links that check</div>
            <div style={{ display: "flex" }}>
              <span>your</span>
              <span style={{ color: "#B6A3FF", marginLeft: 24 }}>real calendar.</span>
            </div>
          </div>
          <div style={{ marginTop: 28, fontSize: 32, color: "#AEB0D6" }}>Pick a time that is actually free. The invite sends itself.</div>
        </div>
      </div>
    ),
    size,
  );
}
