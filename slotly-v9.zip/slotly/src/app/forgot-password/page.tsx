import Link from "next/link";
import { ForgotForm } from "@/components/reset-forms";
import { Logo } from "@/components/logo";
import { emailEnabled } from "@/lib/email";

export const dynamic = "force-dynamic";
export const metadata = { title: "Forgot password", robots: { index: false, follow: false } };

export default function Page({ searchParams }: { searchParams: { email?: string } }) {
  return (
    <main id="main" className="flex min-h-screen flex-col items-center px-5 py-8">
      <Link href="/" aria-label="Slotly home" className="mb-10">
        <Logo />
      </Link>
      <div className="card w-full max-w-md p-7 sm:p-8">
        <h1 className="text-2xl font-bold">Forgot your password?</h1>
        <p className="mt-1 text-sm text-slate-500">Enter your email and we will send you a link to choose a new one.</p>
        <ForgotForm enabled={emailEnabled()} initialEmail={searchParams.email ?? ""} />
        <p className="mt-6 text-sm">
          <Link href="/login" className="text-brand-300 underline">Back to log in</Link>
        </p>
      </div>
    </main>
  );
}
