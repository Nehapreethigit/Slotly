import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { LiveDemo } from "@/components/live-demo";
import { Logo } from "@/components/logo";
import { BarChart3, Command, Globe, ListChecks, Mail, RefreshCw, ShieldCheck, Timer, Webhook } from "lucide-react";

const steps = [
  { title: "You share one link", body: "Your page lists the meeting types you offer. Send it in an email, a bio or a message." },
  { title: "A guest picks a free time", body: "Slots come from your weekly hours minus anything already on your Google Calendar, shown in the guest's timezone." },
  { title: "Both calendars update", body: "The event, a Google Meet link and an invite email are created. Either side can reschedule or cancel." },
];

const handled = [
  { icon: ShieldCheck, title: "No double booking", body: "Two people choosing the same slot at once is settled in the database. One gets it, the other is asked to pick again." },
  { icon: Globe, title: "Timezones and daylight saving", body: "Your hours are stored in your timezone and converted for each guest, including across clock changes." },
  { icon: Timer, title: "Gaps between meetings", body: "Buffers before and after, a minimum notice period, how far ahead people can book, and days off." },
  { icon: ListChecks, title: "Your own questions", body: "Ask guests what they need before the call. Required fields, dropdowns and long answers, all saved with the booking." },
  { icon: RefreshCw, title: "Reschedule and cancel", body: "Guests change plans from their confirmation page. The calendar event moves or disappears with them." },
  { icon: Mail, title: "Confirmations", body: "Branded emails with an .ics file for Apple and Outlook, on top of the Google Calendar invite." },
  { icon: Webhook, title: "Signed webhooks", body: "Send each booking to Slack, Zapier or your own server. Requests are signed so you can verify them." },
  { icon: BarChart3, title: "Insights", body: "See which days and hours people book most, which meeting types are popular, and how many get cancelled." },
  { icon: Command, title: "Built for speed", body: "Press Ctrl K anywhere in your dashboard to jump to a page or copy your booking link." },
];

const stack = ["Next.js 14", "TypeScript", "Prisma", "PostgreSQL", "NextAuth", "Tailwind CSS", "Vitest", "Docker"];

export default async function Home() {
  const session = await getServerSession(authOptions);

  return (
    <main id="main">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" aria-label="Slotly home">
          <Logo />
        </Link>
        {session ? (
          <Link href="/dashboard" className="btn-dark">
            Open dashboard
          </Link>
        ) : (
          <div className="flex items-center gap-2">
            <Link href="/login" className="btn-ghost">
              Log in
            </Link>
            <Link href="/login" className="btn-dark">
              Get started
            </Link>
          </div>
        )}
      </header>

      <div className="relative">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[560px] bg-[radial-gradient(circle_at_1px_1px,#2c2c52_1px,transparent_0)] [background-size:24px_24px] [mask-image:linear-gradient(to_bottom,black,transparent)]"
      />
      <section className="relative mx-auto grid max-w-6xl items-start gap-12 px-5 pb-24 pt-10 sm:px-8 lg:grid-cols-[1fr_440px] lg:gap-16 lg:pt-16">
        <div className="max-w-xl animate-fade-up">
          <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-surface px-3 py-1.5 text-xs font-semibold text-slate-600">
            <span className="h-2 w-2 rounded-full bg-slot-400" /> Open source scheduling, built with Next.js and Postgres
          </p>
          <h1 className="text-balance text-5xl font-bold leading-[1.02] sm:text-6xl lg:text-[4.25rem]">Booking links that check your <span className="text-neon">real calendar.</span></h1>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-slate-600">
            Share one link. People pick a time that is actually free, and the Google Meet invite sends itself.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-x-5 gap-y-3">
            {session ? (
              <Link href="/dashboard" className="btn-dark !px-6 !py-3.5 !text-base">
                Go to your dashboard
              </Link>
            ) : (
              <>
                <Link href="/login" className="btn-dark !px-6 !py-3.5 !text-base">
                  Create free account
                </Link>
              </>
            )}
            <span className="text-sm text-slate-500">Free. Set up in about two minutes.</span>
          </div>
          <p className="mt-12 max-w-sm text-sm leading-relaxed text-slate-500">
            The card on the right is what your guests will see. These are sample times, so go ahead and click around.
          </p>
        </div>

        <LiveDemo />
      </section>
      </div>

      <section className="border-t border-slate-200 bg-black/25">
        <div className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
          <h2 className="max-w-lg text-3xl font-bold sm:text-4xl">What happens when someone books you</h2>
          <ol className="mt-12 grid gap-10 md:grid-cols-3 md:gap-8">
            {steps.map((s, i) => (
              <li key={s.title} className="border-t-2 border-slate-900 pt-5">
                <span className="font-display text-5xl font-bold text-brand-400">{i + 1}</span>
                <h3 className="mt-4 text-xl font-bold">{s.title}</h3>
                <p className="mt-2 leading-relaxed text-slate-600">{s.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <h2 className="max-w-lg text-3xl font-bold sm:text-4xl">The details it takes care of</h2>
        <p className="mt-3 max-w-xl text-slate-600">The boring parts that make a booking link trustworthy.</p>
        <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {handled.map(({ icon: Icon, title, body }) => (
            <li key={title} className="card card-lift p-6">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-400">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-5 font-display text-lg font-bold">{title}</h3>
              <p className="mt-1.5 leading-relaxed text-slate-600">{body}</p>
            </li>
          ))}
        </ul>

        <div className="mt-14 flex flex-wrap items-center gap-x-3 gap-y-2">
          <span className="text-sm font-semibold text-slate-500">Built with</span>
          {stack.map((t) => (
            <span key={t} className="rounded-full border border-slate-200 bg-surface px-3 py-1 text-sm font-medium text-slate-700">
              {t}
            </span>
          ))}
        </div>
      </section>

      <section className="bg-gradient-to-r from-[#3B1FB8] via-[#6A2BD6] to-[#0B6C85] text-white">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-8 px-5 py-16 sm:px-8 md:flex-row md:items-center">
          <div>
            <h2 className="max-w-md text-3xl font-bold sm:text-4xl">Your booking page is two minutes away.</h2>
            <p className="mt-3 max-w-md text-white/80">Create a free account. Slotly sets up two meeting types and weekday hours so you can share a link straight away.</p>
          </div>
          {session ? (
            <Link href="/dashboard" className="btn bg-white !px-6 !py-3.5 !text-base !text-[#07070F] shadow-[0_0_30px_-6px_rgba(255,255,255,0.6)] hover:brightness-95">
              Open dashboard
            </Link>
          ) : (
            <Link href="/login" className="btn bg-white !px-6 !py-3.5 !text-base !text-[#07070F] shadow-[0_0_30px_-6px_rgba(255,255,255,0.6)] hover:brightness-95">
              Create free account
            </Link>
          )}
        </div>
      </section>

      <footer className="mx-auto flex max-w-6xl flex-col gap-3 px-5 py-8 text-sm text-slate-600 sm:flex-row sm:items-center sm:justify-between sm:px-8">
        <p>Slotly is an open source scheduling app built with Next.js, Prisma and PostgreSQL.</p>
        <nav aria-label="Legal" className="flex gap-5">
          <Link href="/privacy" className="hover:text-slate-900 hover:underline">Privacy</Link>
          <Link href="/terms" className="hover:text-slate-900 hover:underline">Terms</Link>
        </nav>
      </footer>
    </main>
  );
}
