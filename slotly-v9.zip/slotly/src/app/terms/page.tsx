import type { Metadata } from "next";
import { LegalPage } from "@/components/legal-page";

export const metadata: Metadata = { title: "Terms of use", alternates: { canonical: "/terms" } };

export default function TermsPage() {
  return (
    <LegalPage title="Terms of use" updated="October 2026">
      <p>By using Slotly you agree to these simple terms. If you do not agree, please do not use the service.</p>
      <h2>Using the service</h2>
      <ul>
        <li>You are responsible for your account and for what you publish on your booking pages.</li>
        <li>Do not use Slotly to send spam, harass people, break the law or attack the service.</li>
        <li>Keep your password private. Tell us if you think your account was accessed by someone else.</li>
      </ul>
      <h2>Availability</h2>
      <p>
        Slotly is provided as is, without any promise that it will always be available or error free. Always confirm
        important meetings directly with the other person.
      </p>
      <h2>Ending your use</h2>
      <p>
        You can stop using Slotly at any time and ask for your data to be deleted. We may suspend accounts that break
        these terms.
      </p>
      <h2>Changes</h2>
      <p>We may update these terms; the date at the top shows when they last changed.</p>
    </LegalPage>
  );
}
