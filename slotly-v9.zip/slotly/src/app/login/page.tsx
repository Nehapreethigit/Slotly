import Link from "next/link";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions, googleEnabled } from "@/lib/auth";
import { AuthForm } from "@/components/auth-form";
import { Logo } from "@/components/logo";
import { emailEnabled } from "@/lib/email";

export const dynamic = "force-dynamic";
export const metadata = { title: "Log in or sign up | Slotly" };

export default async function Page() {
  const session = await getServerSession(authOptions);
  if (session) redirect("/dashboard");

  return (
    <main id="main" className="flex min-h-screen flex-col items-center px-5 py-8">
      <Link href="/" aria-label="Slotly home" className="mb-10">
        <Logo />
      </Link>
      <AuthForm google={googleEnabled} canReset={emailEnabled()} />
    </main>
  );
}
