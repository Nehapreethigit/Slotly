import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowRight, Clock, MapPin } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { locationLabel } from "@/lib/constants";
import { initials } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { params: { username: string } };

async function getHost(username: string) {
  return prisma.user.findUnique({
    where: { username },
    include: { eventTypes: { where: { active: true }, orderBy: { createdAt: "asc" } } },
  });
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const host = await getHost(params.username);
  return { title: host?.name ? `Book time with ${host.name}` : "Not found", robots: { index: false, follow: false } };
}

export default async function HostPage({ params }: Props) {
  const host = await getHost(params.username);
  if (!host) notFound();

  return (
    <main id="main" className="mx-auto max-w-2xl px-4 py-12 sm:py-16">
      <div className="flex flex-col items-center text-center">
        {host.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={host.image} alt="" className="h-20 w-20 rounded-full ring-4 ring-white shadow-soft" referrerPolicy="no-referrer" />
        ) : (
          <span className="grid h-20 w-20 place-items-center rounded-full bg-brand-100 text-2xl font-semibold text-brand-300">
            {initials(host.name)}
          </span>
        )}
        <h1 className="mt-4 text-2xl font-bold tracking-tight">{host.name}</h1>
        {host.bio && <p className="mt-2 max-w-md text-slate-600">{host.bio}</p>}
      </div>

      <div className="mt-10 space-y-3">
        {host.eventTypes.length === 0 && (
          <p className="card p-8 text-center text-slate-500">{host.name} has no event types available right now.</p>
        )}
        {host.eventTypes.map((e) => (
          <Link
            key={e.id}
            href={`/${host.username}/${e.slug}`}
            className="card group relative flex items-center gap-4 overflow-hidden p-5 pl-7 transition hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-lift"
          >
            <span className="absolute inset-y-0 left-0 w-1.5" style={{ background: e.color }} />
            <div className="min-w-0 flex-1">
              <h2 className="font-semibold">{e.title}</h2>
              {e.description && <p className="mt-0.5 line-clamp-2 text-sm text-slate-600">{e.description}</p>}
              <div className="mt-2.5 flex flex-wrap gap-2">
                <span className="badge">
                  <Clock className="h-3 w-3" /> {e.duration} min
                </span>
                <span className="badge">
                  <MapPin className="h-3 w-3" /> {locationLabel(e.location, e.locationDetail)}
                </span>
              </div>
            </div>
            <ArrowRight className="h-5 w-5 text-slate-300 transition group-hover:translate-x-1 group-hover:text-brand-400" />
          </Link>
        ))}
      </div>

      <p className="mt-12 text-center text-xs text-slate-400">
        Powered by{" "}
        <Link href="/" className="font-medium hover:text-brand-400">
          Slotly
        </Link>
      </p>
    </main>
  );
}
