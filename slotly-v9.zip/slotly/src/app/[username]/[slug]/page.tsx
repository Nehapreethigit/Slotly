import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getHostAndEventType } from "@/lib/booking-service";
import { Booker } from "@/components/booker";
import { parseAnswers, parseQuestions } from "@/lib/questions";

export const dynamic = "force-dynamic";

type Props = { params: { username: string; slug: string }; searchParams: { reschedule?: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const found = await getHostAndEventType(params.username, params.slug);
  return {
    title: found ? `${found.eventType.title} with ${found.user.name}` : "Not found",
    robots: { index: false, follow: false },
  };
}

export default async function BookingPage({ params, searchParams }: Props) {
  const found = await getHostAndEventType(params.username, params.slug);
  if (!found) notFound();
  const { user, eventType } = found;

  // Rescheduling: prefill the guest's details from the existing booking.
  const existing = searchParams.reschedule
    ? await prisma.booking.findFirst({
        where: { uid: searchParams.reschedule, hostId: user.id, eventTypeId: eventType.id, status: "CONFIRMED" },
      })
    : null;

  return (
    <main id="main" className="min-h-screen px-4 py-8 sm:py-14">
      <Booker
        host={{ name: user.name ?? "Host", username: user.username ?? "", image: user.image }}
        eventType={{
          title: eventType.title,
          slug: eventType.slug,
          description: eventType.description,
          duration: eventType.duration,
          color: eventType.color,
          location: eventType.location,
          locationDetail: eventType.locationDetail,
          maxDaysAhead: eventType.maxDaysAhead,
          questions: parseQuestions(eventType.questions),
        }}
        reschedule={
          existing
            ? {
                uid: existing.uid,
                name: existing.attendeeName,
                email: existing.attendeeEmail,
                answers: Object.fromEntries(parseAnswers(existing.answers).map((a) => [a.id, a.value])),
              }
            : undefined
        }
      />
    </main>
  );
}
