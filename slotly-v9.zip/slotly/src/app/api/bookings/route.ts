import { NextResponse } from "next/server";
import { addMinutes, format } from "date-fns";
import { formatInTimeZone } from "date-fns-tz";
import { prisma } from "@/lib/prisma";
import { bookingSchema } from "@/lib/validators";
import { getAvailableSlots, getHostAndEventType } from "@/lib/booking-service";
import { createCalendarEvent, deleteCalendarEvent } from "@/lib/google";
import { rateLimit } from "@/lib/rate-limit";
import { notifyBooking } from "@/lib/notifications";
import { parseQuestions, resolveAnswers } from "@/lib/questions";
import { siteUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

class SlotTakenError extends Error {}

// Public endpoint: an attendee books a slot.
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (!rateLimit(`book:${ip}`, 10, 60_000)) {
    return NextResponse.json({ error: "Too many requests, slow down." }, { status: 429 });
  }

  const parsed = bookingSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }
  const input = parsed.data;

  const found = await getHostAndEventType(input.username, input.slug);
  if (!found) return NextResponse.json({ error: "Event not found" }, { status: 404 });
  const { user, eventType } = found;

  // Custom questions: enforce the host's required ones and keep only answers to questions that exist.
  const resolved = resolveAnswers(parseQuestions(eventType.questions), input.answers);
  if (!resolved.ok) return NextResponse.json({ error: resolved.error }, { status: 400 });

  const start = new Date(input.start);
  const end = addMinutes(start, eventType.duration);

  // Rescheduling? Make sure the old booking is real, ours and still active.
  let oldBooking = null;
  if (input.rescheduleUid) {
    oldBooking = await prisma.booking.findFirst({
      where: { uid: input.rescheduleUid, hostId: user.id, eventTypeId: eventType.id, status: "CONFIRMED" },
    });
    if (!oldBooking) return NextResponse.json({ error: "Original booking not found" }, { status: 404 });
  }

  // 1) The requested start must be one of the slots we'd actually offer (rules, notice, buffers, Google busy).
  const available = await getAvailableSlots({
    user,
    eventType,
    rangeStart: start,
    rangeEnd: end,
    excludeBookingUid: oldBooking?.uid,
  });
  if (!available.some((s) => s.getTime() === start.getTime())) {
    return NextResponse.json({ error: "That time is no longer available. Please pick another." }, { status: 409 });
  }

  // 2) Race-proof the write. Two people can pass step 1 at the same moment, so serialize
  //    bookings per host with a Postgres advisory lock and re-check for clashes inside the lock.
  let booking;
  try {
    booking = await prisma.$transaction(
      async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${user.id}))`;

        const clash = await tx.booking.findFirst({
          where: {
            hostId: user.id,
            status: "CONFIRMED",
            ...(oldBooking ? { uid: { not: oldBooking.uid } } : {}),
            startTime: { lt: addMinutes(end, eventType.bufferAfter) },
            endTime: { gt: addMinutes(start, -eventType.bufferBefore) },
          },
        });
        if (clash) throw new SlotTakenError();

        if (oldBooking) {
          await tx.booking.update({ where: { id: oldBooking.id }, data: { status: "CANCELLED" } });
        }

        return tx.booking.create({
          data: {
            eventTypeId: eventType.id,
            hostId: user.id,
            startTime: start,
            endTime: end,
            attendeeName: input.name,
            attendeeEmail: input.email,
            attendeeTimezone: input.timezone,
            notes: input.notes || null,
            answers: resolved.answers,
          },
        });
      },
      { timeout: 10_000 },
    );
  } catch (err) {
    if (err instanceof SlotTakenError) {
      return NextResponse.json({ error: "Someone just booked that time. Please pick another." }, { status: 409 });
    }
    throw err;
  }

  // 3) Side effects after the DB commit: Google Calendar event + Meet link + invite email.
  //    If Google is down the booking still stands - the host just won't get the calendar event.
  try {
    const when = formatInTimeZone(start, user.timezone, "EEE d MMM yyyy, HH:mm zzz");
    const { eventId, meetLink } = await createCalendarEvent(user.id, {
      summary: `${eventType.title}: ${user.name ?? "Host"} & ${input.name}`,
      description: [
        `Booked via Slotly for ${when}.`,
        resolved.answers.length ? `\n${resolved.answers.map((a) => `${a.label}: ${a.value}`).join("\n")}` : "",
        input.notes ? `\nNotes from ${input.name}:\n${input.notes}` : "",
        `\nManage booking: ${siteUrl()}/booking/${booking.uid}`,
      ].join("\n"),
      start,
      end,
      hostTimezone: user.timezone,
      attendeeEmail: input.email,
      attendeeName: input.name,
      location: eventType.location === "GOOGLE_MEET" ? undefined : eventType.locationDetail ?? undefined,
      withMeet: eventType.location === "GOOGLE_MEET",
      requestId: booking.uid,
    });
    booking = await prisma.booking.update({
      where: { id: booking.id },
      data: { googleEventId: eventId, meetLink },
    });
  } catch (err) {
    console.error(`[booking ${booking.uid}] Google event failed at ${format(new Date(), "HH:mm:ss")}`, err);
  }

  if (oldBooking?.googleEventId) await deleteCalendarEvent(user.id, oldBooking.googleEventId);

  // 4) Emails + signed webhooks. Fail-safe: never throws, never blocks the booking.
  await notifyBooking(oldBooking ? "booking.rescheduled" : "booking.created", { booking, eventType, host: user });

  return NextResponse.json({ uid: booking.uid }, { status: 201 });
}
