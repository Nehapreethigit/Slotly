import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { deleteCalendarEvent } from "@/lib/google";
import { notifyBooking } from "@/lib/notifications";

export const dynamic = "force-dynamic";

// Cancel a booking. The booking uid is an unguessable UUID, so whoever holds the link
// (the attendee from their confirmation page, or the host from the dashboard) can cancel.
export async function DELETE(_req: Request, { params }: { params: { uid: string } }) {
  const booking = await prisma.booking.findUnique({
    where: { uid: params.uid },
    include: { eventType: true, host: true },
  });
  if (!booking) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (booking.status === "CANCELLED") return NextResponse.json({ ok: true });

  // Conditional update: if two cancels race, only one flips the status and sends notifications.
  const { count } = await prisma.booking.updateMany({
    where: { id: booking.id, status: "CONFIRMED" },
    data: { status: "CANCELLED" },
  });
  if (count === 0) return NextResponse.json({ ok: true });

  if (booking.googleEventId) await deleteCalendarEvent(booking.hostId, booking.googleEventId);

  await notifyBooking("booking.cancelled", {
    booking: { ...booking, status: "CANCELLED" },
    eventType: booking.eventType,
    host: booking.host,
  });

  return NextResponse.json({ ok: true });
}
