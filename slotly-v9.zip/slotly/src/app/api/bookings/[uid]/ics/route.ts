import { prisma } from "@/lib/prisma";
import { buildIcs } from "@/lib/ics";
import { locationLabel } from "@/lib/constants";

export const dynamic = "force-dynamic";

// Download an .ics file so the booking can be added to Apple / Outlook / any calendar app.
export async function GET(_req: Request, { params }: { params: { uid: string } }) {
  const booking = await prisma.booking.findUnique({
    where: { uid: params.uid },
    include: { eventType: true, host: true },
  });
  if (!booking) return new Response("Not found", { status: 404 });

  const ics = buildIcs({
    uid: booking.uid,
    title: `${booking.eventType.title} with ${booking.host.name ?? "host"}`,
    description: booking.meetLink ? `Join: ${booking.meetLink}` : undefined,
    location: booking.meetLink ?? locationLabel(booking.eventType.location, booking.eventType.locationDetail),
    start: booking.startTime,
    end: booking.endTime,
    organizer: { name: booking.host.name ?? "Host", email: booking.host.email },
    attendee: { name: booking.attendeeName, email: booking.attendeeEmail },
    status: booking.status === "CANCELLED" ? "CANCELLED" : "CONFIRMED",
  });

  return new Response(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="booking-${booking.uid.slice(0, 8)}.ics"`,
      "Cache-Control": "no-store",
    },
  });
}
