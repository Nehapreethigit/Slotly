import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

// GET /api/health - for uptime monitors and deploy checks. Reports WHICH integrations are configured, never their values.
export async function GET() {
  let db = false;
  try {
    await prisma.$queryRaw`SELECT 1`;
    db = true;
  } catch {
    /* reported below */
  }

  const checks = {
    database: db,
    googleOAuth: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
    nextAuthSecret: !!process.env.NEXTAUTH_SECRET,
    nextAuthUrl: !!(process.env.NEXTAUTH_URL || process.env.VERCEL_URL),
    email: !!process.env.RESEND_API_KEY, // optional
  };
  const healthy = checks.database && checks.googleOAuth && checks.nextAuthSecret && checks.nextAuthUrl;

  return NextResponse.json({ status: healthy ? "ok" : "degraded", checks }, { status: healthy ? 200 : 503 });
}
