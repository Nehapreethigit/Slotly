import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getUserId, unauthorized } from "@/lib/auth";
import { profileSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request) {
  const userId = await getUserId();
  if (!userId) return unauthorized();

  const parsed = profileSchema.partial().safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  try {
    const user = await prisma.user.update({
      where: { id: userId },
      data: {
        ...parsed.data,
        // once a timezone has been saved, stop auto-detecting it from the browser
        ...(parsed.data.timezone ? { timezoneSet: true } : {}),
      },
      select: { id: true, name: true, username: true, bio: true, timezone: true },
    });
    return NextResponse.json({ user });
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
      return NextResponse.json({ error: "That username is taken" }, { status: 409 });
    }
    throw err;
  }
}
