import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getUserId, unauthorized } from "@/lib/auth";
import { generateWebhookSecret } from "@/lib/webhooks";
import { isSafeWebhookUrl, WEBHOOK_EVENTS } from "@/lib/webhook-security";

export const dynamic = "force-dynamic";

const MAX_WEBHOOKS = 5;

const createSchema = z.object({
  url: z.string().url().max(500),
  events: z.array(z.enum(WEBHOOK_EVENTS)).min(1, "Pick at least one event"),
});

export async function POST(req: Request) {
  const userId = await getUserId();
  if (!userId) return unauthorized();

  const parsed = createSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  const safe = isSafeWebhookUrl(parsed.data.url, { allowInsecure: process.env.NODE_ENV !== "production" });
  if (!safe.ok) return NextResponse.json({ error: safe.reason }, { status: 400 });

  if ((await prisma.webhook.count({ where: { userId } })) >= MAX_WEBHOOKS) {
    return NextResponse.json({ error: `You can have at most ${MAX_WEBHOOKS} webhooks` }, { status: 400 });
  }

  const webhook = await prisma.webhook.create({
    data: { userId, url: parsed.data.url, events: parsed.data.events, secret: generateWebhookSecret() },
  });
  return NextResponse.json({ webhook: { id: webhook.id } }, { status: 201 });
}
