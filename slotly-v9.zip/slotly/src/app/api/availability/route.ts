import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserId, unauthorized } from "@/lib/auth";
import { availabilitySchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export async function GET() {
  const userId = await getUserId();
  if (!userId) return unauthorized();

  const [weekly, blocked] = await Promise.all([
    prisma.availability.findMany({ where: { userId }, orderBy: [{ weekday: "asc" }, { startMin: "asc" }] }),
    prisma.blockedDate.findMany({ where: { userId }, orderBy: { date: "asc" } }),
  ]);
  return NextResponse.json({
    weekly: weekly.map(({ weekday, startMin, endMin }) => ({ weekday, startMin, endMin })),
    blockedDates: blocked.map((b) => b.date),
  });
}

// Replace the whole schedule atomically.
export async function PUT(req: Request) {
  const userId = await getUserId();
  if (!userId) return unauthorized();

  const parsed = availabilitySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }
  const { weekly, blockedDates } = parsed.data;

  await prisma.$transaction([
    prisma.availability.deleteMany({ where: { userId } }),
    prisma.availability.createMany({ data: weekly.map((r) => ({ ...r, userId })) }),
    prisma.blockedDate.deleteMany({ where: { userId } }),
    prisma.blockedDate.createMany({ data: [...new Set(blockedDates)].map((date) => ({ date, userId })) }),
  ]);

  return NextResponse.json({ ok: true });
}
