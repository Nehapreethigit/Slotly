import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getUserId, unauthorized } from "@/lib/auth";
import { eventTypeSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

type Ctx = { params: { id: string } };

export async function PATCH(req: Request, { params }: Ctx) {
  const userId = await getUserId();
  if (!userId) return unauthorized();

  const parsed = eventTypeSchema.partial().safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  try {
    // updateMany with userId in the filter = ownership check + update in one query
    const { count } = await prisma.eventType.updateMany({ where: { id: params.id, userId }, data: parsed.data });
    if (count === 0) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const eventType = await prisma.eventType.findUnique({ where: { id: params.id } });
    return NextResponse.json({ eventType });
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
      return NextResponse.json({ error: "You already have an event type with that URL" }, { status: 409 });
    }
    throw err;
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  const userId = await getUserId();
  if (!userId) return unauthorized();

  const eventType = await prisma.eventType.findFirst({ where: { id: params.id, userId } });
  if (!eventType) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const bookings = await prisma.booking.count({ where: { eventTypeId: params.id } });
  if (bookings > 0) {
    return NextResponse.json(
      { error: "This event type has bookings, so it can't be deleted. Turn it off instead." },
      { status: 409 },
    );
  }

  await prisma.eventType.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
