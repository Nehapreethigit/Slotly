import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getUserId, unauthorized } from "@/lib/auth";
import { eventTypeSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export async function GET() {
  const userId = await getUserId();
  if (!userId) return unauthorized();
  const eventTypes = await prisma.eventType.findMany({ where: { userId }, orderBy: { createdAt: "asc" } });
  return NextResponse.json({ eventTypes });
}

export async function POST(req: Request) {
  const userId = await getUserId();
  if (!userId) return unauthorized();

  const parsed = eventTypeSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  try {
    const eventType = await prisma.eventType.create({ data: { ...parsed.data, userId } });
    return NextResponse.json({ eventType }, { status: 201 });
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
      return NextResponse.json({ error: "You already have an event type with that URL" }, { status: 409 });
    }
    throw err;
  }
}
