import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/**
 * Step 1 of the two-step login: "does this email already have an account, and how does it sign in?"
 * Like Google's own sign-in, this reveals whether an email is registered, so it is rate limited per IP.
 */
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (!rateLimit(`lookup:${ip}`, 20, 10 * 60_000)) {
    return NextResponse.json({ error: "Too many tries. Please wait a few minutes." }, { status: 429 });
  }

  const parsed = z.object({ email: z.string().trim().toLowerCase().email("Enter a valid email") }).safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Enter a valid email" }, { status: 400 });

  const user = await prisma.user.findUnique({
    where: { email: parsed.data.email },
    select: { name: true, passwordHash: true },
  });
  return NextResponse.json({
    exists: !!user,
    hasPassword: !!user?.passwordHash,
    name: user?.name?.split(" ")[0] ?? null,
  });
}
