import { NextResponse } from "next/server";
import { getHostAndEventType, getSlotsWithHints } from "@/lib/booking-service";

export const dynamic = "force-dynamic";

const MAX_RANGE_MS = 62 * 24 * 60 * 60 * 1000;

// Public endpoint: GET /api/slots?username=&slug=&start=<ISO>&end=<ISO>&exclude=<bookingUid>
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const username = searchParams.get("username");
  const slug = searchParams.get("slug");
  const start = new Date(searchParams.get("start") ?? "");
  const end = new Date(searchParams.get("end") ?? "");
  const exclude = searchParams.get("exclude") ?? undefined;

  if (!username || !slug || Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    return NextResponse.json({ error: "username, slug, start and end are required" }, { status: 400 });
  }
  if (end <= start || end.getTime() - start.getTime() > MAX_RANGE_MS) {
    return NextResponse.json({ error: "Invalid date range" }, { status: 400 });
  }

  const found = await getHostAndEventType(username, slug);
  if (!found) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const { slots, packed } = await getSlotsWithHints({
    user: found.user,
    eventType: found.eventType,
    rangeStart: start,
    rangeEnd: end,
    excludeBookingUid: exclude,
  });

  return NextResponse.json({
    slots: slots.map((s) => s.toISOString()),
    packed: packed.map((s) => s.toISOString()),
    hostTimezone: found.user.timezone,
  });
}
