import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";
import { emailEnabled, sendEmail } from "@/lib/email";
import { newResetToken, renderResetEmail, resetIdentifier, RESET_TTL_MS } from "@/lib/password-reset";
import { siteUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

const schema = z.object({ email: z.string().trim().toLowerCase().email().max(254) });

/** Always answers the same way, so nobody can use this form to find out who has an account. */
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (!rateLimit(`forgot-ip:${ip}`, 10, 60 * 60_000)) {
    return NextResponse.json({ error: "Too many requests. Try again later." }, { status: 429 });
  }
  if (!emailEnabled()) {
    return NextResponse.json({ error: "Password reset by email is not set up on this site yet." }, { status: 503 });
  }
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Enter a valid email." }, { status: 400 });
  const { email } = parsed.data;

  if (rateLimit(`forgot-email:${email}`, 3, 60 * 60_000)) {
    const user = await prisma.user.findUnique({ where: { email } });
    if (user?.passwordHash) {
      const { token, tokenHash } = newResetToken();
      const identifier = resetIdentifier(email);
      await prisma.verificationToken.deleteMany({ where: { identifier } });
      await prisma.verificationToken.create({ data: { identifier, token: tokenHash, expires: new Date(Date.now() + RESET_TTL_MS) } });
      const link = `${siteUrl()}/reset-password?token=${token}&email=${encodeURIComponent(email)}`;
      await sendEmail({ to: email, ...renderResetEmail(user.name, link) });
    }
  }
  return NextResponse.json({ ok: true });
}
