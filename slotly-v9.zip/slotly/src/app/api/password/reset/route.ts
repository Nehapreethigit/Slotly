import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";
import { hashPassword } from "@/lib/passwords";
import { hashToken, isExpired, resetIdentifier } from "@/lib/password-reset";
import { passwordSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

const schema = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  token: z.string().min(32).max(128),
  password: passwordSchema,
});

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (!rateLimit(`reset-ip:${ip}`, 20, 60 * 60_000)) {
    return NextResponse.json({ error: "Too many attempts. Try again later." }, { status: 429 });
  }
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid request" }, { status: 400 });
  const { email, token, password } = parsed.data;

  const identifier = resetIdentifier(email);
  const row = await prisma.verificationToken.findUnique({ where: { token: hashToken(token) } });
  const bad = NextResponse.json({ error: "This reset link is invalid or has expired. Ask for a new one." }, { status: 400 });
  if (!row || row.identifier !== identifier || isExpired(row.expires)) return bad;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return bad;

  await prisma.$transaction([
    prisma.user.update({ where: { id: user.id }, data: { passwordHash: await hashPassword(password) } }),
    prisma.verificationToken.deleteMany({ where: { identifier } }),
  ]);
  return NextResponse.json({ ok: true });
}
