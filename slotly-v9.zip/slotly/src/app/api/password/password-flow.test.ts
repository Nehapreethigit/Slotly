import { beforeEach, describe, expect, it, vi } from "vitest";

type Tok = { identifier: string; token: string; expires: Date };
const db = { users: new Map<string, { id: string; email: string; name: string; passwordHash: string | null }>(), tokens: [] as Tok[] };
const sent: { to: string; text: string }[] = [];

vi.mock("@/lib/prisma", () => ({
  prisma: {
    user: {
      findUnique: async ({ where }: { where: { email: string } }) => db.users.get(where.email) ?? null,
      update: async ({ where, data }: { where: { id: string }; data: { passwordHash: string } }) => {
        for (const u of db.users.values()) if (u.id === where.id) u.passwordHash = data.passwordHash;
        return null;
      },
    },
    verificationToken: {
      deleteMany: async ({ where }: { where: { identifier: string } }) => {
        db.tokens = db.tokens.filter((t) => t.identifier !== where.identifier);
        return { count: 0 };
      },
      create: async ({ data }: { data: Tok }) => void db.tokens.push(data),
      findUnique: async ({ where }: { where: { token: string } }) => db.tokens.find((t) => t.token === where.token) ?? null,
    },
    $transaction: async (ops: Promise<unknown>[]) => Promise.all(ops),
  },
}));
vi.mock("@/lib/email", () => ({
  emailEnabled: () => true,
  sendEmail: async (a: { to: string; text: string }) => (sent.push(a), true),
}));

import { POST as forgot } from "./forgot/route";
import { POST as reset } from "./reset/route";
import { verifyPassword } from "@/lib/passwords";

const req = (body: unknown, ip = "1.1.1.1") =>
  new Request("http://x.test/api", { method: "POST", headers: { "x-forwarded-for": ip, "content-type": "application/json" }, body: JSON.stringify(body) });

function linkFromEmail() {
  const m = sent.at(-1)!.text.match(/reset-password\?token=([a-f0-9]+)&email=([^\s]+)/)!;
  return { token: m[1], email: decodeURIComponent(m[2]) };
}

beforeEach(() => {
  db.users.clear();
  db.tokens = [];
  sent.length = 0;
  db.users.set("neha@example.com", { id: "u1", email: "neha@example.com", name: "Neha K", passwordHash: "old" });
  db.users.set("g@example.com", { id: "u2", email: "g@example.com", name: "G", passwordHash: null });
});

describe("password reset flow", () => {
  it("emails a link and lets the user choose a new password once", async () => {
    expect((await forgot(req({ email: "neha@example.com" }, "2.2.2.1"))).status).toBe(200);
    expect(sent).toHaveLength(1);
    const { token, email } = linkFromEmail();
    expect(db.tokens[0].token).not.toBe(token); // only the hash is stored

    const ok = await reset(req({ token, email, password: "brand-new-pass" }, "2.2.2.2"));
    expect(ok.status).toBe(200);
    expect(await verifyPassword("brand-new-pass", db.users.get("neha@example.com")!.passwordHash!)).toBe(true);

    const again = await reset(req({ token, email, password: "another-pass-1" }, "2.2.2.3"));
    expect(again.status).toBe(400); // link cannot be reused
  });

  it("answers the same for unknown and Google-only accounts and sends nothing", async () => {
    for (const [i, e] of ["nobody@example.com", "g@example.com"].entries()) {
      const r = await forgot(req({ email: e }, `3.3.3.${i}`));
      expect(r.status).toBe(200);
      expect(await r.json()).toEqual({ ok: true });
    }
    expect(sent).toHaveLength(0);
  });

  it("rejects expired tokens, wrong emails and short passwords", async () => {
    await forgot(req({ email: "neha@example.com" }, "4.4.4.1"));
    const { token, email } = linkFromEmail();
    expect((await reset(req({ token, email: "g@example.com", password: "long-enough-1" }, "4.4.4.2"))).status).toBe(400);
    expect((await reset(req({ token, email, password: "short" }, "4.4.4.3"))).status).toBe(400);
    db.tokens[0].expires = new Date(Date.now() - 1000);
    expect((await reset(req({ token, email, password: "long-enough-1" }, "4.4.4.4"))).status).toBe(400);
    expect(db.users.get("neha@example.com")!.passwordHash).toBe("old");
  });

  it("limits repeated requests for the same email", async () => {
    db.users.set("rate@example.com", { id: "u3", email: "rate@example.com", name: "R", passwordHash: "old" });
    for (let i = 0; i < 5; i++) await forgot(req({ email: "rate@example.com" }, `5.5.5.${i}`));
    expect(sent).toHaveLength(3);
  });
});
