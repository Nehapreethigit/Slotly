import Link from "next/link";
import { ResetForm } from "@/components/reset-forms";
import { Logo } from "@/components/logo";

export const dynamic = "force-dynamic";
export const metadata = { title: "Choose a new password", robots: { index: false, follow: false } };

export default function Page({ searchParams }: { searchParams: { token?: string; email?: string } }) {
  return (
    <main id="main" className="flex min-h-screen flex-col items-center px-5 py-8">
      <Link href="/" aria-label="Slotly home" className="mb-10">
        <Logo />
      </Link>
      <div className="card w-full max-w-md p-7 sm:p-8">
        <h1 className="text-2xl font-bold">Choose a new password</h1>
        <ResetForm token={searchParams.token ?? ""} email={searchParams.email ?? ""} />
      </div>
    </main>
  );
}
