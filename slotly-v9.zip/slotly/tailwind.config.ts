import type { Config } from "tailwindcss";

/**
 * Design tokens.
 * Neon night theme. The scales keep their names so every existing class re-themes at once:
 *  - slate:  inverted. 50 is the page (near black), 900 is the main text (near white)
 *  - surface: card and input background
 *  - brand:  electric violet, used for actions and the selected state
 *  - slot:   neon cyan, used only to mark open/bookable times
 */
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        slate: {
          50: "#07070F",
          100: "#16162E",
          200: "#262647",
          300: "#3A3A66",
          400: "#7E80AB",
          500: "#9193BD",
          600: "#AEB0D6",
          700: "#C9CBE8",
          800: "#E0E2F7",
          900: "#F3F4FF",
          950: "#FFFFFF",
        },
        surface: "#0E0E20",
        brand: {
          50: "#1A1540",
          100: "#241B5C",
          200: "#3B2D94",
          300: "#B6A3FF",
          400: "#9A7DFF",
          500: "#8662FF",
          600: "#7A56FF",
          700: "#6A42F0",
          800: "#5A33D6",
          900: "#4527A8",
        },
        slot: {
          50: "#0B2F38",
          100: "#0F3E4A",
          200: "#145566",
          300: "#22D3EE",
          400: "#2EE6F5",
          700: "#67E8F9",
        },
      },
      fontFamily: {
        sans: ['"Instrument Sans Variable"', "ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Arial", "sans-serif"],
        display: ['"Bricolage Grotesque Variable"', '"Instrument Sans Variable"', "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        soft: "0 1px 0 rgba(255,255,255,.04)",
        pop: "0 24px 80px -24px rgba(122,86,255,.6)",
        lift: "0 18px 50px -20px rgba(122,86,255,.5)",
        glow: "0 0 0 1px rgba(122,86,255,.4), 0 8px 40px -8px rgba(122,86,255,.6)",
        "glow-cyan": "0 0 28px -6px rgba(34,211,238,.6)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(6px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pop-in": {
          "0%": { opacity: "0", transform: "scale(.96)" },
          "100%": { opacity: "1", transform: "scale(1)" },
        },
        "slide-in": {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-400px 0" },
          "100%": { backgroundPosition: "400px 0" },
        },
      },
      animation: {
        "fade-up": "fade-up .3s ease-out both",
        "pop-in": "pop-in .18s ease-out both",
        "slide-in": "slide-in .25s ease-out both",
        shimmer: "shimmer 1.4s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
