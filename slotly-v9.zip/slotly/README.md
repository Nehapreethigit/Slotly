# Slotly

Booking links that check your real calendar. Share one link, guests pick a time that is actually free, and a Google Meet invite sends itself. Built with Next.js, TypeScript, Prisma and PostgreSQL.

**Live site:** _add your Vercel URL here_

![Landing page with a working booking demo](docs/screenshots/landing.png)

<table>
  <tr>
    <td width="68%"><img src="docs/screenshots/booking-page.png" alt="Public booking page with calendar and time slots"></td>
    <td width="32%"><img src="docs/screenshots/booking-page-mobile.png" alt="Booking page on a phone"></td>
  </tr>
</table>

<table>
  <tr>
    <td><img src="docs/screenshots/dashboard.png" alt="Overview dashboard with key numbers, next meetings and a 30-day chart"></td>
    <td><img src="docs/screenshots/insights.png" alt="Insights page with bookings per day and a busiest-times heatmap"></td>
  </tr>
</table>

_Screenshots are rendered with sample data._

## Quick start (easiest way to run it)

1. Install **Node.js (LTS)** from https://nodejs.org and **Docker Desktop**. Open Docker Desktop and wait for "Engine running".
2. **Windows:** double-click **`start.bat`** in this folder. **Mac or Linux:** run `sh start.sh`.
3. Wait. The first run takes a few minutes. Your browser opens at http://localhost:3000. Click **Get started** and make an account.

The script creates your settings (with a random secret), starts the database, installs everything, creates the tables and starts the app. Run it again any time to start Slotly again.

## What it does

- **Neon night theme**: a dark glass interface with violet, magenta and cyan glow, built from design tokens so the whole app re-themes in one place
- **Accounts**: email and password (bcrypt, rate limited) or Google, through a Google-style two-step login. Google also grants Calendar access, with automatic token refresh
- **Overview dashboard**: upcoming meetings, key numbers, a 30-day chart and your most popular meeting types
- **Custom booking questions** per event type (short answer, long answer, dropdown, required or optional). Answers are validated on the server, saved with the question text, and shown in bookings, emails, calendar invites and webhooks
- **Best fit slots ("calendar tetris")**: times that sit flush against an existing meeting get a "Best fit" tag, so bookings pack together and your free time stays in one long block instead of scattered gaps
- **Fair for both timezones**: every slot is checked against a sensible hour (8:00 to 20:00) in the guest's timezone and the host's. Good times are tagged "Fair for both", awkward ones show a "stretch" warning, and the guest gets one-tap picks: Best fit, Fair for both, Soonest
- **Installable app (PWA)**: one-tap install on Android, desktop and iPhone, own icon, offline page, shortcuts to Bookings and Event types. Ready to be wrapped for Google Play, see PLAY_STORE.md
- **Forgot password by email**: one-hour reset links, tokens stored hashed, same answer whether or not the email exists, rate limited
- **Command palette**: press Ctrl K (or Cmd K) in the dashboard to jump anywhere or copy your booking link
- **Event types**: duration, color, location (Google Meet, in person, custom), buffers before and after, minimum notice, booking window, custom slot interval
- **Availability**: several time ranges per day, per-host timezone, days off, daylight-saving safe
- **Two-way calendar sync**: reads your real busy time so you are never double-booked, and writes each booking back as an event with a Meet link
- **Public booking page**: month calendar, guest timezone detection and switching, 12h/24h toggle
- **Reschedule and cancel** from the confirmation link; the Google event moves or disappears
- **Race-safe booking**: a Postgres advisory lock per host, with a re-check inside the lock
- **Signed webhooks** for `booking.created`, `rescheduled` and `cancelled`, with a delivery log in the dashboard
- **Email confirmations** (optional, via Resend) with an `.ics` attachment, plus an `.ics` download for guests
- **Insights**: bookings per day, a weekday-by-hour heatmap, per-event-type breakdown, cancellation rate, and a table view
- **Setup checklist** for new hosts, toasts and confirm dialogs, loading and error states, mobile layouts
- **Ops**: `/api/health`, security headers, a non-root multi-stage Dockerfile, GitHub Actions CI, a seed script for demo data

## Tech stack

| Layer | Tech |
| --- | --- |
| Framework | Next.js 14 (App Router), React 18, TypeScript |
| Styling | Tailwind CSS, Bricolage Grotesque + Instrument Sans, lucide-react |
| Auth | NextAuth v4 (Google OAuth, JWT sessions, Prisma adapter) |
| Database | PostgreSQL + Prisma ORM |
| Calendar | Google Calendar REST API (`freeBusy`, `events.insert` with `conferenceData`) |
| Validation | Zod |
| Dates / timezones | date-fns, date-fns-tz |
| Email | Resend HTTP API (optional) |
| Tests / CI | Vitest (55 tests), GitHub Actions |
| Containers | Docker (multi-stage, standalone Next output) |
| Hosting | Vercel + Neon (free tiers) |

## How it works

```
Guest opens /{username}/{event}
        |
        v
GET /api/slots  --> getAvailableSlots()
                      |- weekly hours + days off      (Postgres)
                      |- existing bookings            (Postgres)
                      |- host's busy times            (Google freeBusy)
                      `- computeSlots()  <-- pure function, unit tested
        |
        v
POST /api/bookings
   1. re-validate the slot on the server (never trust the client)
   2. transaction: pg_advisory_xact_lock(host) -> re-check clashes -> insert booking
   3. after commit: create the Google event + Meet link, store the link on the booking
   4. emails + signed webhooks (never block or fail the booking)
```

Design decisions worth explaining:

- **The slot engine is a pure function** (`src/lib/slots.ts`). No database or network, so timezone and DST edge cases are unit tested.
- **Double-booking is prevented in two layers.** Slot validation is fast but racy; the advisory lock makes the final write safe.
- **Google trouble never loses a booking.** The booking commits first; the calendar event is a side effect. Busy-time lookup fails open, so a Google outage cannot block guests.
- **Webhooks are signed like Stripe's.** The HMAC covers `timestamp.body`, so a captured request cannot be replayed after 5 minutes, and comparison is constant-time.
- **User-supplied URLs are an SSRF risk.** Webhook URLs are checked against private, loopback and metadata ranges, and redirects are never followed.
- **Cancel is idempotent.** A conditional update means two simultaneous cancels notify once.
- **User text is escaped** in emails and `.ics` files, so a guest name cannot inject HTML or extra calendar properties.
- **No hydration mismatches.** Anything that depends on the viewer's timezone is formatted after mount (`LocalTime`, the booker), so server and browser first renders match.
- **Plain `fetch` for Google** instead of the large googleapis SDK: a smaller bundle and transparent token-refresh logic.

## Project structure

```
prisma/schema.prisma          data model (10 tables)
prisma/seed.ts                sample data for demos
src/lib/slots.ts              availability engine (pure, tested)
src/lib/google.ts             Google Calendar client + token refresh
src/lib/booking-service.ts    gathers data and calls the engine
src/lib/webhook-security.ts   HMAC signing + SSRF guard (pure, tested)
src/lib/webhooks.ts           delivery, retry, delivery log
src/lib/ics.ts                RFC 5545 calendar file builder (pure, tested)
src/lib/email*.ts             Resend client + escaped HTML templates (tested)
src/lib/insights.ts           analytics aggregation (pure, tested)
src/lib/demo-data.ts          sample booking generator (pure, tested)
src/app/api/**                REST routes
src/app/dashboard/**          host dashboard
src/app/[username]/**         public profile and booking page
src/app/booking/[uid]         confirmation, reschedule, cancel
src/components/**             UI components
```

---

## Run it locally

You need **Node 18 or newer** (20 recommended), **Docker** (for Postgres) and a **Google account**.

### 1. Install

```bash
npm install
cp .env.example .env        # Windows PowerShell: copy .env.example .env
```

### 2. Start Postgres

```bash
docker compose up -d
```

No Docker? Create a free database at https://neon.tech and paste its connection string into `DATABASE_URL` in `.env`.

### 3. Create Google credentials (about 5 minutes)

1. Create a project: https://console.cloud.google.com/projectcreate
2. Enable the Calendar API: https://console.cloud.google.com/apis/library/calendar-json.googleapis.com and click **Enable**
3. Set up the consent screen: https://console.cloud.google.com/apis/credentials/consent
   - User type **External**; fill in an app name and your email
   - Add the scopes `.../auth/calendar.events` and `.../auth/calendar.freebusy` (plus `openid`, `email`, `profile`)
   - Under **Test users**, add your own Gmail address
4. Create the credentials at https://console.cloud.google.com/apis/credentials: **Create credentials > OAuth client ID > Web application**
   - Authorized JavaScript origin: `http://localhost:3000`
   - Authorized redirect URI: `http://localhost:3000/api/auth/callback/google`
5. Copy the **Client ID** and **Client secret** into `.env` as `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`
6. Generate a secret for `NEXTAUTH_SECRET`:
   ```bash
   openssl rand -base64 32
   ```
   (No `openssl`? Use any long random string.)

### 4. Create the tables and start the app

```bash
npx prisma migrate dev --name init
npm run dev
```

The first command creates the tables and a `prisma/migrations/` folder. **Commit that folder** (it is how production databases get the same schema).

Open http://localhost:3000 and sign in with Google. Tick **every** permission box on the consent screen: Calendar access shows as optional there, but Slotly needs it. Google will warn that the app is unverified. Click **Advanced**, then **Go to Slotly (unsafe)**. That is expected for your own project.

### 5. Add sample data (optional but recommended)

```bash
npm run db:seed                              # creates a public demo host at /demo
npm run db:seed -- --email you@gmail.com     # also fills YOUR dashboard with sample bookings
npm run db:seed -- --clean                   # removes everything the seed created
```

Sign in once before using `--email`. Sample guests all use the reserved domain `@demo.slotly.invalid`, so cleanup never touches real bookings. This makes Insights and Bookings look alive for screenshots and demos.

### 6. Try it

1. **Dashboard > Event types**, open your booking link in a private window
2. Book a slot using a different email address
3. Check Google Calendar: the event, Meet link and invite are there
4. Open the confirmation page and try Reschedule and Cancel

### Optional extras

**Email confirmations.** Make a free key at https://resend.com and set `RESEND_API_KEY` in `.env`. Without a verified domain, Resend only delivers to your own address, which is enough for a demo. With no key, emails are skipped.

**Webhooks.** Get a free temporary endpoint at https://webhook.site, add its URL under **Dashboard > Integrations**, then make a booking and watch the signed request arrive. Plain `http://` URLs only work in development.

**Everything in Docker.**

```bash
docker compose --profile app up --build -d
docker compose run --rm migrate
```

### Useful commands

```bash
npm test             # 55 unit tests
npm run typecheck    # TypeScript
npm run build        # production build
npm run db:studio    # browse the database
```

---

## Put it on GitHub

If you unzipped this project, it already contains a git history. Create an **empty** repository (no README, no .gitignore) at https://github.com/new named `slotly`, then in the project folder:

```bash
git remote add origin https://github.com/YOUR-USERNAME/slotly.git
git push -u origin main
```

If there is no `.git` folder, run `git init -b main`, `git add .`, `git commit -m "Initial commit"` first.

Git will ask you to sign in. GitHub no longer accepts account passwords on the command line: create a Personal Access Token at https://github.com/settings/tokens (classic, `repo` scope) and paste it as the password. Or install the GitHub CLI (https://cli.github.com), run `gh auth login`, and then do it all in one step:

```bash
gh repo create slotly --public --source=. --remote=origin --push
```

Before you push, run `git status` and confirm `.env` is not listed (it is in `.gitignore`).

After pushing: set the repo's **About** description and website link, add the topics `nextjs`, `typescript`, `prisma`, `postgresql`, `google-calendar-api`, and pin the repository on your profile.

---

## Deploy it (free): Neon + Vercel

This is the fastest route to a live website. It needs **no Google setup**. Anyone can **create an account with email and password**. Add Google login and email afterwards if you want them.

### 1. Database on Neon (2 minutes)

1. Sign up at https://neon.tech and create a project
2. Copy the connection string. **Turn off "Connection pooling"** so you get the direct string. It ends with `?sslmode=require`

### 2. App on Vercel (3 minutes)

1. Push the project to GitHub (see above), then go to https://vercel.com/new and import the `slotly` repository
2. Under **Environment Variables** add:

| Name | Value |
| --- | --- |
| `DATABASE_URL` | the Neon connection string |
| `NEXTAUTH_SECRET` | any random text, 32+ characters |
| `NEXT_PUBLIC_CONTACT_EMAIL` | your email, shown on the privacy and terms pages |

3. Click **Deploy**. Vercel runs the `vercel-build` script, which generates the Prisma client, **creates the tables in Neon automatically** (`prisma db push`), then builds the site
4. Your URL is shown after the deploy. You do not need to set `NEXTAUTH_URL` on Vercel; Slotly detects its own address. Only add it if you attach your own domain
5. Open `/api/health`. It should say `"status": "ok"`
6. Open the site, click **Get started**, enter an email, then your name and a password. You land in your dashboard with a ready booking link and two event types

### 3. Optional: real Google login and calendar sync

Create the Google credentials as in the local setup, then add `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in Vercel and redeploy. The **Continue with Google** button appears on the login page by itself once both are set. In the Google console:

- Authorized JavaScript origins: `https://YOUR-APP.vercel.app`
- Authorized redirect URIs: `https://YOUR-APP.vercel.app/api/auth/callback/google`
- At https://console.cloud.google.com/apis/credentials/consent click **Publish app**. In Testing mode Google expires refresh tokens after 7 days, so calendar sync would quietly stop

Accounts that do not connect Google still work: bookings are saved and emailed, but no Google Calendar event is created.

Finally, put the live link at the top of this README.

---

## Ideas to extend it

- Team and round-robin event types
- Date-specific availability overrides
- An embeddable booking widget
- Stripe payments for paid events
- Redis-based rate limiting
- Playwright end-to-end tests for the booking flow

## Go-live checklist (making it public)

Do these in order. Each takes a few minutes.

1. **Database**: create a free Neon project and copy the *direct* (non-pooled) connection string.
2. **Vercel**: import the GitHub repo and add these environment variables:
   - `DATABASE_URL` - the Neon string
   - `NEXTAUTH_SECRET` - any long random string (`openssl rand -base64 32`)
   - `NEXTAUTH_URL` - **optional on Vercel**. Set it only if you use your own domain, e.g. `https://book.yourname.com`. It drives the sitemap, canonical links and the link-preview image.
   - `NEXT_PUBLIC_CONTACT_EMAIL` - shown on the privacy and terms pages so people can reach you
3. **Custom domain** (optional): Vercel > Settings > Domains, then update `NEXTAUTH_URL` to match and redeploy.
4. **Google sign-in and calendar** (optional): create OAuth credentials, add `https://YOUR-DOMAIN/api/auth/callback/google` as a redirect URI, set `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`, and **publish** the consent screen (testing mode expires tokens after 7 days and limits you to listed test users).
5. **Emails** (strongly recommended): add `RESEND_API_KEY` and `EMAIL_FROM`. This powers booking confirmations **and "Forgot password"** (the link only appears when a key is set). Resend only delivers to other people once you verify your own domain there; until then it sends only to your own address.
6. **Check the live site**: open `/api/health`, `/robots.txt`, `/sitemap.xml`, `/privacy`, then paste your link into WhatsApp or LinkedIn to see the preview card.
7. **Region**: put the Vercel function region next to your Neon region to keep it fast.

What is already handled for public use: link previews (Open Graph and Twitter), `robots.txt`, sitemap, web manifest, privacy and terms pages, security headers, personal booking pages and the dashboard marked `noindex`, skip-to-content link, labelled form fields, and an automated axe-core accessibility check (WCAG 2.1 AA) with no violations on the landing, login, dashboard, settings, availability, insights and booking pages.

Be aware of: there is no email verification at sign-up yet, and rate limits are per serverless instance (swap in Upstash Redis for strict global limits).

## Known limitations

- **No password reset or email verification yet.** Accounts are created with email and password and are usable immediately. A forgotten password cannot be recovered. This is the first thing to add before real public use (Resend is already wired for sending email).
- Sign-up and login rate limits are in memory per serverless instance. Use Upstash Redis for a strict global limit.
- Rate limiting is in memory, so it is per server instance. Use Redis or Upstash in production.
- The webhook SSRF check validates the hostname, not the resolved IP.
- Webhook retries are one immediate re-attempt, not a durable queue.
- Only the host's primary Google Calendar is checked for conflicts.
- The booking, Google and email flows were not exercised against live services while this was built: the logic is unit tested, the app type-checks and builds, and every screen was rendered with sample data, but run through a real sign-in and booking yourself before you demo it.
