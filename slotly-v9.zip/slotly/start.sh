#!/usr/bin/env sh
# One command to run Slotly on Mac or Linux:  sh start.sh
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Install Node.js (LTS) from https://nodejs.org first."; exit 1; }
docker info >/dev/null 2>&1 || { echo "Start Docker first."; exit 1; }
node scripts/init-env.mjs
docker compose up -d --wait db
[ -d node_modules ] || npm install
npx prisma db push --skip-generate
echo "Open http://localhost:3000"
npm run dev
